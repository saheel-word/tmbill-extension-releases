// Reads login credentials from a client / Slack message in ANY layout.
//   extractLoginCreds(text) -> { backoffice: {username, password}, pos: {username, password} }
// Understands: "Username: a" / "User Name - a" / "Login ID = a" / "User: a" / "Username: a Password: b" (one line) /
// "Username / Password : a / b" / value on the next line / *bold*, `code`, bullets, emojis, Slack links.
// Section headers (Back Office / Owner Panel  vs  POS / Front Office / Billing) decide which pair is which;
// without headers the first pair is Back Office and a different second pair is POS.
(function () {
  const U = "user\\s*name|user\\s*id|userid|login\\s*id|login\\s*name|login\\s*user|username|login|user";
  const P = "password|passcode|pass\\s*word|pass|pwd";
  const SEP = "\\s*[:：=]\\s*|\\s+[-–—]\\s+|\\s*[-–—]\\s*(?=\\S)";
  const LABEL = new RegExp("(?:^|[\\s,;|(])((?:pos|front\\s*office|billing|back\\s*office|owner|admin|manager)?\\s*(?:" + U + "|" + P + "))\\s*(?:" + SEP + ")", "gi");
  const COMBO = new RegExp("^\\s*(?:" + U + ")\\s*(?:[/&|,]|and)\\s*(?:" + P + ")\\s*(?:[:：=]|[-–—])\\s*(.+)$", "i");

  function tidy(v) {
    v = String(v == null ? "" : v);
    v = v.replace(/<mailto:([^|>]+)\|[^>]*>/gi, "$1").replace(/<tel:([^|>]+)(?:\|[^>]*)?>/gi, "$1").replace(/<(https?:[^|>]+)(?:\|[^>]*)?>/gi, "$1");
    v = v.replace(/\[([^\]]+)\]\([^)]*\)/g, "$1").replace(/\\([:@_*`~])/g, "$1");
    v = v.replace(/[`*~]/g, "").replace(/^[\s_"'“”‘’<\[({]+|[\s_"'“”‘’>\])}]+$/g, "");
    return v.replace(/[,;.]+$/, "").trim();
  }
  function lineClean(l) {
    return String(l || "").replace(/([A-Za-z])[*_`~]+(?=\s*[:：=])/g, "$1").replace(/(^|[\s|,;(])[*_~]+(?=[A-Za-z][A-Za-z ]*\s*[:：=])/g, "$1").replace(/^[\s•\-–—*>·▪●○■□➤➢✅☑️✔️🔹🔸🔑🔐👤🔒▶️]+/u, "").replace(/\s+/g, " ").trim();
  }
  const isUserKey = (k) => new RegExp("(?:^|\\s)(?:" + U + ")$", "i").test(k.trim());
  const isPassKey = (k) => new RegExp("(?:^|\\s)(?:" + P + ")$", "i").test(k.trim());
  const posKey = (k) => /^(pos|front\s*office|billing)/i.test(k.trim());

  function extractLoginCreds(text) {
    const lines = String(text || "").split(/\r?\n/).map(lineClean).filter(Boolean);
    const pairs = []; // { section, username, password }
    let section = "";
    let cur = null;
    const getPair = (sec) => {
      if (!cur || cur.section !== sec || (cur.username && cur.password)) { cur = { section: sec, username: "", password: "" }; pairs.push(cur); }
      return cur;
    };
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const hasUrl = /https?:\/\//i.test(line);
      const labelled = new RegExp("(?:" + U + "|" + P + ")\\s*(?:[:：=]|\\s[-–—]\\s)", "i").test(line);
      // section header: a short line naming a panel, without a credential on it
      if (!hasUrl && !labelled && line.length <= 70) {
        if (/back\s*office|owner\s*panel|admin\s*panel|manager\s*panel|web\s*panel/i.test(line)) { section = "backoffice"; cur = null; continue; }
        if (/\bpos\b|front\s*office|billing\s*(system|app)|terminal|atlantic/i.test(line)) { section = "pos"; cur = null; continue; }
      }
      // "Username / Password : a / b"
      const cm = line.match(COMBO);
      if (cm) {
        const bits = cm[1].split(/\s*(?:\/|\||,|&)\s*|\s{2,}|\s+and\s+/i).map(tidy).filter(Boolean);
        if (bits.length >= 2) { const p = getPair(section); p.username = bits[0]; p.password = bits[1]; continue; }
      }
      // label: value (possibly several on one line)
      const marks = [];
      LABEL.lastIndex = 0;
      let m;
      while ((m = LABEL.exec(line))) marks.push({ key: m[1], at: m.index + m[0].length - m[0].replace(/^[\s,;|(]/, "").length, end: m.index + m[0].length });
      for (let k = 0; k < marks.length; k++) {
        const mk = marks[k];
        let val = line.slice(mk.end, k + 1 < marks.length ? marks[k + 1].at : undefined);
        if (k + 1 < marks.length) val = val.replace(/[\s,;|/&]+$/, "");
        val = tidy(val);
        if (!val && k === marks.length - 1 && lines[i + 1] && !LABEL.test(lines[i + 1] + " ") ) { val = tidy(lines[i + 1]); i++; }
        LABEL.lastIndex = 0;
        if (!val || /^https?:/i.test(val)) continue;
        const sec = posKey(mk.key) ? "pos" : section;
        if (isUserKey(mk.key.replace(/^(pos|front\s*office|billing|back\s*office|owner|admin|manager)\s*/i, ""))) { const p = getPair(sec); if (p.username) { cur = null; getPair(sec).username = val; } else p.username = val; }
        else if (isPassKey(mk.key)) { const p = getPair(sec); if (p.password) { cur = null; getPair(sec).password = val; } else p.password = val; }
      }
    }
    const full = pairs.filter((p) => p.username && p.password);
    let back = full.find((p) => p.section === "backoffice");
    let pos = full.find((p) => p.section === "pos");
    if (!back) {
      const un = full.filter((p) => p.section === "");
      back = un[0];
      if (!pos && un[1] && un[1].username.toLowerCase() !== un[0].username.toLowerCase()) pos = un[1];
    }
    if (!back) back = pairs.find((p) => p.section !== "pos" && (p.username || p.password)); // half a pair is still useful
    return { backoffice: back ? { username: back.username, password: back.password } : { username: "", password: "" }, pos: pos ? { username: pos.username, password: pos.password } : { username: "", password: "" } };
  }

  const api = { extractLoginCreds };
  if (typeof module !== "undefined") module.exports = api;
  globalThis.extractLoginCreds = extractLoginCreds;
})();
