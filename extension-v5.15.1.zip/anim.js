// Loading screen, click feedback and "working" animations. Pure UI - no effect on the onboarding logic.
(function () {
  const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // 1) Loading screen: shows while the panel starts, then fades out
  const splash = document.getElementById("splash");
  if (splash) {
    const t0 = performance.now();
    const hide = () => {
      splash.classList.add("hide");
      setTimeout(() => splash.remove(), 450);
    };
    const go = () => setTimeout(hide, Math.max(0, (reduce ? 150 : 900) - (performance.now() - t0)));
    if (document.readyState === "complete") go(); else window.addEventListener("load", go);
    setTimeout(hide, 4000); // never block the panel
  }

  // 2) Click ripple on every button
  document.addEventListener("pointerdown", (e) => {
    if (reduce) return;
    const b = e.target.closest && e.target.closest("button, .btn-tile");
    if (!b || b.disabled || b.classList.contains("info-btn") || b.classList.contains("modal-close")) return;
    const r = b.getBoundingClientRect();
    const size = Math.max(r.width, r.height) * 1.6;
    const s = document.createElement("span");
    s.className = "ripple";
    s.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
    if (getComputedStyle(b).position === "static") b.style.position = "relative";
    b.style.overflow = "hidden";
    b.appendChild(s);
    setTimeout(() => s.remove(), 600);
  }, true);

  // 3) "Working" state: spinner on the current step + moving bar while an onboarding / Full Setup run is active
  const startBtn = document.getElementById("startBtn");
  const fsBtn = document.getElementById("fullSetupBtn");
  const bar = document.querySelector(".floating-bar-bottom");
  let lastBusy = false;
  function sync() {
    const busy = !!(startBtn && startBtn.disabled) || !!(fsBtn && fsBtn.dataset.running === "1");
    if (busy === lastBusy) return;
    lastBusy = busy;
    document.body.classList.toggle("is-busy", busy);
    if (bar) bar.classList.toggle("working", busy);
    if (typeof renderChecklist === "function") renderChecklist();
    if (!busy) {
      const st = document.querySelector(".status-bar");
      if (st && !reduce) { st.classList.remove("flash"); void st.offsetWidth; st.classList.add("flash"); }
    }
  }
  if (startBtn) new MutationObserver(sync).observe(startBtn, { attributes: true, attributeFilter: ["disabled"] });
  setInterval(sync, 600);
})();
