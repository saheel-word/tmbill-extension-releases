// Modifier Suite UI (merged). One closed scope so nothing clashes with popup.js; ids are prefixed ms-.
(function () {
"use strict";
const $ = (id) => document.getElementById("ms-" + id);

const loginView = $("login-view");
const appView = $("app-view");
const statusPill = $("status-pill");
const logBox = $("log-box");

function log(text, isError = false) {
  const line = document.createElement("div");
  if (isError) line.className = "err";
  line.textContent = text;
  logBox.appendChild(line);
  logBox.scrollTop = logBox.scrollHeight;
}

/** Shared helper: wraps chrome.runtime.sendMessage in a Promise, throws on
 * {ok:false}. Used by popup.js, modifiers.js, and optiongroups.js (all
 * loaded into the same popup page, so this is just a plain global). */
function sendMsg(type, payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, payload }, (res) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (res && res.ok) resolve(res);
      else reject(new Error(res ? res.error : "Unknown error."));
    });
  });
}

function displayName(o) {
  return o.name || o.store_name || o.outlet_name || o.title || o.menu_name || `#${o.id ?? o.store_id ?? "?"}`;
}

// ---------------- Backoffice session / connection ----------------

function setLoggedInUI(state) {
  const authenticated = !!(state && state.authenticated);
  loginView.hidden = authenticated;
  appView.hidden = !authenticated;
  statusPill.textContent = authenticated ? "Connected" : "Not connected";
  statusPill.className = "pill " + (authenticated ? "pill-on" : "pill-off");
  if (authenticated) $("logged-in-user").textContent = state.username || "Backoffice session";
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "LOG") log(msg.text);
});

async function connectBackoffice() {
  $("connect-btn").disabled = true;
  $("connect-btn").textContent = "Connecting...";
  logBox.innerHTML = "";
  try {
    const res = await sendMsg("CONNECT_BACKOFFICE", {
      baseUrl: $("base-url").value.trim() || "https://backoffice.tmbill.com",
    });
    setLoggedInUI(res.state);
    renderOutletList(res.outlets || []);
    fillSelect($("outlet-select"), res.outlets || [], "store_id", displayName, "-- select outlet --");

    if (res.state.storeId) {
      $("outlet-select").value = String(res.state.storeId);
      await loadMenusForOutlet(res.state.storeId, res.state.menuId);
    }
  } catch (e) {
    setLoggedInUI({ authenticated: false });
    log(e.message, true);
  } finally {
    $("connect-btn").disabled = false;
    $("connect-btn").textContent = "Retry Backoffice connection";
  }
}

// On every extension open, reuse the authenticated Backoffice browser session.
// No TMBill email/password is requested by the extension.
sendMsg("GET_STATE")
  .then(async (res) => {
    setLoggedInUI(res.state);
    if (res.state.authenticated) {
      try {
        const outlets = await sendMsg("FETCH_OUTLETS");
        renderOutletList(outlets.outlets);
        fillSelect($("outlet-select"), outlets.outlets, "store_id", displayName, "-- select outlet --");
        if (res.state.storeId) {
          $("outlet-select").value = String(res.state.storeId);
          await loadMenusForOutlet(res.state.storeId, res.state.menuId);
        }
      } catch {
        await connectBackoffice();
      }
    } else {
      await connectBackoffice();
    }
  })
  .catch((e) => log(e.message, true));

$("connect-btn").addEventListener("click", connectBackoffice);

$("logout-btn").addEventListener("click", async () => {
  // Disconnect only the extension state; keep the user signed in to Backoffice.
  await sendMsg("LOGOUT");
  setLoggedInUI({ authenticated: false });
  $("outlet-list").innerHTML = "";
  $("outlet-select").innerHTML = '<option value="">-- select outlet --</option>';
  $("menu-select").innerHTML = '<option value="">-- select outlet first --</option>';
  logBox.innerHTML = "";
});

// ---------------- Outlet / menu context ----------------

function renderOutletList(outlets) {
  const list = $("outlet-list");
  list.innerHTML = "";
  if (!outlets.length) {
    const li = document.createElement("li");
    li.textContent = "No outlets returned.";
    list.appendChild(li);
    return;
  }
  for (const o of outlets) {
    const li = document.createElement("li");
    li.textContent = `${displayName(o)} (${o.store_id ?? o.id ?? "?"})`;
    list.appendChild(li);
  }
}

function fillSelect(select, items, valueKey, labelFn, placeholder) {
  select.innerHTML = "";
  const opt0 = document.createElement("option");
  opt0.value = "";
  opt0.textContent = placeholder;
  select.appendChild(opt0);
  for (const item of items) {
    const opt = document.createElement("option");
    opt.value = item[valueKey];
    opt.textContent = labelFn(item);
    select.appendChild(opt);
  }
}

async function restoreContextSelects(state) {
  if (state.storeId) {
    // Best-effort: re-fetch outlets so the dropdown has options to restore into.
    try {
      const res = await sendMsg("FETCH_OUTLETS");
      fillSelect($("outlet-select"), res.outlets, "store_id", displayName, "-- fetch outlets --");
      $("outlet-select").value = state.storeId;
      await loadMenusForOutlet(state.storeId, state.menuId);
    } catch {
      /* leave selects at defaults if this fails */
    }
  }
}

async function loadMenusForOutlet(storeId, selectMenuId) {
  const res = await sendMsg("FETCH_OUTLET_MENUS", { storeId });
  fillSelect($("menu-select"), res.menus, "id", (m) => m.menu_name || m.title || `Menu #${m.id}`, "-- select menu --");
  if (selectMenuId) $("menu-select").value = selectMenuId;
}

$("fetch-outlets-btn").addEventListener("click", async () => {
  $("fetch-outlets-btn").disabled = true;
  try {
    const res = await sendMsg("FETCH_OUTLETS");
    log(`Fetched ${res.outlets.length} outlet(s).`);
    renderOutletList(res.outlets);
    fillSelect($("outlet-select"), res.outlets, "store_id", displayName, "-- fetch outlets --");
  } catch (e) {
    log(e.message, true);
  } finally {
    $("fetch-outlets-btn").disabled = false;
  }
});

$("outlet-select").addEventListener("change", async () => {
  const storeId = $("outlet-select").value;
  await sendMsg("SET_CONTEXT", { storeId: storeId || null, menuId: null });
  if (!storeId) {
    $("menu-select").innerHTML = '<option value="">-- select outlet first --</option>';
    return;
  }
  try {
    await loadMenusForOutlet(storeId);
    log(`Context set: outlet ${storeId}.`);
  } catch (e) {
    log(e.message, true);
  }
});

$("menu-select").addEventListener("change", async () => {
  const menuId = $("menu-select").value;
  await sendMsg("SET_CONTEXT", { menuId: menuId || null });
  log(`Context set: menu ${menuId || "(none)"}.`);
});

// ---------------- Tabs ----------------

document.querySelectorAll("#modSuite .tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#modSuite .tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll("#modSuite .tab-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    $(btn.dataset.tab).classList.add("active");
  });
});

;
/**
 * menu_converter.js -- JS port of the desktop suite's menu_converter.py.
 *
 * Lets the extension's Bulk Import (Modifier Groups tab AND Option Groups
 * tab) accept a raw Atlantic/TMBill-format full menu export (30-column,
 * Item Type 0=parent / 1=variant) directly -- auto-detected and converted
 * in-memory into the modifiers_input / option_group_input row shape those
 * bulk importers already understand. No manual "convert this menu into a
 * modifiers sheet first" step needed.
 *
 * Detection: a raw menu export has Item Type + Category + a price column
 * (Base Item Price / Sale Price / MRP / ...), but NO "Modifier Group" or
 * "Option Group" column. A proper bulk-import file always has one of those
 * (required by bulk_modifiers.js / bulk_optiongroups.js's own column
 * checks), so it's never misdetected as raw.
 *
 * Conversion rules (identical to menu_converter.py):
 *   1. SIZE/VARIANT groups -- each parent (Item Type=0) immediately
 *      followed by one or more variant rows (Item Type=1) becomes one
 *      Modifier/Option Group named after the parent, one row per variant,
 *      mandatory single-choice (Min=1, Max=1). Parents with no variants and
 *      no addon sentence are single-price items and are skipped.
 *   2. ADD-ON groups -- a plain-English sentence in any row's own
 *      Description cell, e.g. "addon for Veg Sandwich, Corn Sandwich
 *      category Sandwiches min 0 max 1", turns that row into a shared
 *      add-on applied to the named item(s)/category. "group <name>" merges
 *      several addon rows (e.g. every topping) into one multi-select group.
 */

// ---- Column detection (mirrors menu_converter.py's alias tables) ----
const MC_PRICE_COLUMN_ALIASES = ["Base Item Price", "Sale Price", "MRP", "Price", "Item Price", "Base Price", "Rate"];
const MC_COLUMN_ALIASES = {
  "Title": ["Title", "Item Name", "Name", "Product Name"],
  "Item Type": ["Item Type", "Type", "ItemType"],
  "Short Code": ["Short Code", "SKU", "Item Code", "Code", "ShortCode"],
  "Category": ["Category", "Product Category", "Product Group"],
  "Description": ["Description", "Desc", "Notes", "Remarks"],
};
const MC_MODIFIERS_INPUT_MARKER_COLUMNS = ["modifier group", "option group"];

function mcNorm(s) {
  return String(s == null ? "" : s).trim().toLowerCase();
}
function mcIsBlank(v) {
  if (v === null || v === undefined) return true;
  if (typeof v === "number") return Number.isNaN(v);
  if (typeof v === "string") return v.trim() === "";
  return false;
}
function mcToStr(v, dflt = "") {
  return mcIsBlank(v) ? dflt : String(v).trim();
}
function mcToNum(v, dflt = 0) {
  if (mcIsBlank(v)) return dflt;
  const n = Number(v);
  return Number.isNaN(n) ? dflt : n;
}

function mcBuildColumnMap(columns) {
  const lowerToActual = {};
  for (const c of columns) lowerToActual[mcNorm(c)] = c;
  const colMap = {};
  for (const alias of MC_PRICE_COLUMN_ALIASES) {
    const actual = lowerToActual[mcNorm(alias)];
    if (actual !== undefined) {
      colMap["Base Item Price"] = actual;
      break;
    }
  }
  for (const [canonical, aliases] of Object.entries(MC_COLUMN_ALIASES)) {
    for (const alias of aliases) {
      const actual = lowerToActual[mcNorm(alias)];
      if (actual !== undefined) {
        colMap[canonical] = actual;
        break;
      }
    }
  }
  return colMap;
}

/** True if `columns` looks like a raw full-menu export rather than an
 * already-prepared modifiers_input / option_group_input workbook. */
function looksLikeRawMenu(columns) {
  const colMap = mcBuildColumnMap(columns);
  const hasSignature = !!(colMap["Item Type"] && colMap["Category"] && colMap["Base Item Price"]);
  const lowerSet = new Set(columns.map(mcNorm));
  const hasMarker = MC_MODIFIERS_INPUT_MARKER_COLUMNS.some((m) => lowerSet.has(m));
  return hasSignature && !hasMarker;
}

// ---- Add-on sentence parsing (mirrors _parse_addon_sentence) ----
const MC_ADDON_KEYWORD_ALIASES = {
  addon: "addon", add: "addon", adon: "addon", "add-on": "addon",
  for: "for", item: "for", items: "for",
  category: "category", categories: "category", cat: "category", cats: "category",
  min: "min", minimum: "min", mini: "min",
  max: "max", maximum: "max", maxi: "max",
  mandatory: "mandatory", compulsory: "mandatory", required: "mandatory", must: "mandatory",
  optional: "optional",
  group: "group", grp: "group", groupname: "group", grouped: "group",
};
const MC_ADDON_KEYWORD_RE = new RegExp(
  "\\b(" + Object.keys(MC_ADDON_KEYWORD_ALIASES).sort((a, b) => b.length - a.length).join("|") + ")\\b",
  "gi"
);
const MC_ITEM_SPLIT_RE = /\s*(?:,|&|\/|;|\n|\r|\band\b)\s*/gi;
const MC_WORD_NUMBERS = {
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  none: 0, single: 1,
};

function mcSplitList(chunk) {
  return chunk.split(MC_ITEM_SPLIT_RE).map((s) => s.trim()).filter(Boolean);
}

function mcFirstInt(values, dflt) {
  for (const v of values) {
    const digits = v.match(/(\d+)/);
    if (digits) return parseInt(digits[1], 10);
    for (const [word, num] of Object.entries(MC_WORD_NUMBERS)) {
      if (new RegExp(`\\b${word}\\b`, "i").test(v)) return num;
    }
  }
  return dflt;
}

/** Parses a plain-English add-on sentence out of a Description cell.
 * Returns null if the text has no "addon" trigger word anywhere. */
function parseAddonSentence(description) {
  const text = String(description == null ? "" : description).trim();
  if (!text) return null;

  MC_ADDON_KEYWORD_RE.lastIndex = 0;
  const matches = [...text.matchAll(MC_ADDON_KEYWORD_RE)];
  const canonical = matches.map((m) => [MC_ADDON_KEYWORD_ALIASES[m[1].toLowerCase()], m]);
  if (!canonical.some(([key]) => key === "addon")) return null;

  const segments = {};
  const keysPresent = new Set(canonical.map(([key]) => key));
  for (let i = 0; i < canonical.length; i++) {
    const [key, m] = canonical[i];
    const valueStart = m.index + m[0].length;
    const valueEnd = i + 1 < canonical.length ? canonical[i + 1][1].index : text.length;
    let value = text.slice(valueStart, valueEnd);
    value = value.replace(/^[\s,;:\-=]+|[\s,;:\-=]+$/g, "");
    if (value) {
      if (!segments[key]) segments[key] = [];
      segments[key].push(value);
    }
  }

  let itemNames = [];
  for (const chunk of segments["for"] || []) itemNames.push(...mcSplitList(chunk));

  let categories = [];
  for (const chunk of segments["category"] || []) categories.push(...mcSplitList(chunk));

  if (itemNames.length === 0 && categories.length === 0) {
    for (const chunk of segments["addon"] || []) itemNames.push(...mcSplitList(chunk));
  }

  let minValue = mcFirstInt(segments["min"] || [], 0);
  let maxValue = mcFirstInt(segments["max"] || [], 1);
  if (keysPresent.has("mandatory") && minValue < 1) minValue = 1;
  if (keysPresent.has("optional") && !segments["min"]) minValue = 0;
  if (minValue > maxValue) {
    const t = minValue;
    minValue = maxValue;
    maxValue = t;
  }

  const groupChunks = segments["group"] || [];
  const groupName = groupChunks.length ? groupChunks[0].trim() : null;

  return { items: itemNames, categories, min: minValue, max: maxValue, group: groupName };
}

// ---- Parent/variant row detection ----
const MC_PARENT_VALUES = new Set(["0", "0.0", "parent", "p", "main", "master"]);
const MC_VARIANT_VALUES = new Set(["1", "1.0", "variant", "v", "child", "c", "size"]);
function mcIsParentRow(v) {
  return MC_PARENT_VALUES.has(String(v == null ? "" : v).trim().toLowerCase());
}
function mcIsVariantRow(v) {
  return MC_VARIANT_VALUES.has(String(v == null ? "" : v).trim().toLowerCase());
}

function mcNormalizeRows(rawRows, columns) {
  const colMap = mcBuildColumnMap(columns);
  const required = ["Title", "Item Type", "Base Item Price", "Short Code"];
  const missing = required.filter((k) => !colMap[k]);
  if (missing.length) {
    throw new Error(
      `Looks like a menu export but is missing column(s): ${missing.join(", ")}; cannot auto-convert. Expected an Atlantic-format export.`
    );
  }
  const hasDescriptionCol = !!colMap["Description"];
  const normalizedRows = rawRows.map((raw) => ({
    Title: mcToStr(raw[colMap["Title"]]),
    "Item Type": raw[colMap["Item Type"]],
    "Short Code": mcToStr(raw[colMap["Short Code"]]),
    Category: colMap["Category"] ? mcToStr(raw[colMap["Category"]]) : "",
    Description: hasDescriptionCol ? raw[colMap["Description"]] : null,
    "Base Item Price": raw[colMap["Base Item Price"]],
  }));
  return { normalizedRows, hasDescriptionCol };
}

/** Core grouping/addon-resolution pass -- shared by both the Modifier and
 * Option Group formatters below. */
function mcBuildConversionEvents(normalizedRows, hasDescriptionCol) {
  // nameLookup / categoryLookup values are {title, shortCode} refs, not bare
  // strings -- this lets downstream code prefer the unique Short Code over
  // the Title when several items share the same name (see mcFormatAs*Rows).
  const nameLookup = {};
  const categoryLookup = {};
  for (const row of normalizedRows) {
    const title = mcToStr(row.Title);
    if (!title) continue;
    const shortCode = mcToStr(row["Short Code"]);
    const ref = { title, shortCode };
    nameLookup[title.toLowerCase()] = ref;
    if (shortCode) nameLookup[shortCode.toLowerCase()] = ref;
    if (mcIsParentRow(row["Item Type"])) {
      const category = mcToStr(row.Category);
      if (category) {
        if (!categoryLookup[category.toLowerCase()]) categoryLookup[category.toLowerCase()] = [];
        categoryLookup[category.toLowerCase()].push(ref);
      }
    }
  }

  function resolveTargets(addon, ownTitle) {
    const resolved = [];
    for (const name of addon.items) {
      const match = nameLookup[name.toLowerCase()];
      if (match) resolved.push(match);
    }
    for (const categoryName of addon.categories) {
      let members = categoryLookup[categoryName.toLowerCase()] || [];
      members = members.filter((m) => m.title.toLowerCase() !== ownTitle.toLowerCase());
      resolved.push(...members);
    }
    const seen = new Set();
    const deduped = [];
    for (const ref of resolved) {
      const key = ref.title.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        deduped.push(ref);
      }
    }
    return deduped;
  }

  // ---- Parent index by Short Code (for the short-code-suffix matching
  // strategy below -- built once, independent of row order). ----
  const parentsByShortCode = new Map(); // lowercased short code -> parent row
  for (const row of normalizedRows) {
    if (mcIsParentRow(row["Item Type"])) {
      const sc = mcToStr(row["Short Code"]);
      if (sc) parentsByShortCode.set(sc.toLowerCase(), row);
    }
  }
  /** TMBill exports come in two shapes:
   *   (a) interleaved -- each parent is immediately followed by its own
   *       variant rows (old assumption, still the common case).
   *   (b) block -- ALL parent rows first, then ALL variant rows appended
   *       together at the bottom of the sheet, correlated to their parent
   *       only via Short Code convention (parent "SZ38" -> variants
   *       "SZ38A"/"SZ38B", i.e. parent code + a trailing letter suffix).
   * Trusting position alone on a (b)-shaped file would silently attach
   * every trailing variant row to whichever parent happened to be LAST in
   * the sheet -- one giant wrong group -- instead of skipping them, which
   * is worse than doing nothing. So short-code-suffix matching is tried
   * FIRST for every variant row; position is only used as a fallback for
   * rows with no short code or a non-conforming one. */
  function deriveParentByShortCodeSuffix(variantShortCode) {
    const sc = mcToStr(variantShortCode);
    if (!sc) return null;
    for (const suffixLen of [1, 2]) {
      if (sc.length <= suffixLen) continue;
      const prefix = sc.slice(0, -suffixLen);
      const suffix = sc.slice(-suffixLen);
      if (!/^[A-Za-z]+$/.test(suffix)) continue;
      const match = parentsByShortCode.get(prefix.toLowerCase());
      if (match) return match;
    }
    return null;
  }

  const variantGroups = [];
  const addonEntries = [];
  const skippedNoVariant = [];
  const seenAddonRows = new Set();
  let currentParent = null;
  let currentVariants = [];

  // Per-parent accumulator for short-code-matched variants, keyed by the
  // parent's own identity so rows scattered anywhere in the sheet still
  // land in the right group. Combined with the positional groups below.
  const scGroupsByParentKey = new Map(); // key -> { parentRow, variants: [] }
  function parentKey(parentRow) {
    const sc = mcToStr(parentRow["Short Code"]);
    return sc ? `sc:${sc.toLowerCase()}` : `title:${mcToStr(parentRow.Title).toLowerCase()}`;
  }

  function flush() {
    if (currentParent === null) return;
    if (!currentVariants.length) return; // no positional variants -- short-code group (if any) is added separately below
    const key = parentKey(currentParent);
    let entry = scGroupsByParentKey.get(key);
    if (!entry) {
      entry = { parentRow: currentParent, variants: [] };
      scGroupsByParentKey.set(key, entry);
    }
    entry.variants.push(...currentVariants);
  }

  for (const row of normalizedRows) {
    const itemType = row["Item Type"];
    const addon = hasDescriptionCol ? parseAddonSentence(row.Description) : null;

    if (mcIsParentRow(itemType)) {
      flush();
      currentParent = row;
      currentVariants = [];
      // Make sure every parent gets an entry (even with zero variants so
      // far) so skippedNoVariant reporting below is accurate.
      const key = parentKey(row);
      if (!scGroupsByParentKey.has(key)) scGroupsByParentKey.set(key, { parentRow: row, variants: [] });
    } else if (mcIsVariantRow(itemType) && !addon) {
      // Only collect as a plain size/variant if it's NOT an addon row --
      // an addon item is often entered as Item Type=1 too.
      const scParent = deriveParentByShortCodeSuffix(row["Short Code"]);
      if (scParent) {
        const key = parentKey(scParent);
        let entry = scGroupsByParentKey.get(key);
        if (!entry) {
          entry = { parentRow: scParent, variants: [] };
          scGroupsByParentKey.set(key, entry);
        }
        entry.variants.push(row);
      } else if (currentParent !== null) {
        // No usable short code to match by -- fall back to positional
        // adjacency (old behaviour) so files without the suffix
        // convention keep working exactly as before.
        currentVariants.push(row);
      }
    }

    if (addon) {
      const ownTitle = mcToStr(row.Title);
      const ownShortCode = mcToStr(row["Short Code"]);
      const ownPrice = mcToNum(row["Base Item Price"], 0);
      const rawGroup = addon.group;
      const groupName = rawGroup && rawGroup.trim() ? rawGroup.trim() : ownTitle;
      const singleSelection = rawGroup && rawGroup.trim() ? 0 : 1;
      const targets = resolveTargets(addon, ownTitle);
      for (const target of targets) {
        const dedupeKey = `${target.title.toLowerCase()}||${groupName.toLowerCase()}||${ownTitle.toLowerCase()}`;
        if (seenAddonRows.has(dedupeKey)) continue;
        seenAddonRows.add(dedupeKey);
        addonEntries.push({
          targetTitle: target.title,
          targetShortCode: target.shortCode,
          groupName,
          modifierTitle: ownTitle,
          price: ownPrice,
          shortCode: ownShortCode,
          min: addon.min,
          max: addon.max,
          singleSelection,
        });
      }
    }
  }
  flush();

  for (const { parentRow, variants } of scGroupsByParentKey.values()) {
    if (!variants.length) {
      skippedNoVariant.push(mcToStr(parentRow.Title));
      continue;
    }
    variantGroups.push({
      parentTitle: mcToStr(parentRow.Title),
      parentShortCode: mcToStr(parentRow["Short Code"]),
      variants: variants.map((v) => ({
        title: mcToStr(v.Title),
        shortCode: mcToStr(v["Short Code"]),
        price: mcToNum(v["Base Item Price"], 0),
      })),
    });
  }

  return { variantGroups, addonEntries, skippedNoVariant };
}

function mcFormatAsModifierRows(events) {
  // Prefer the item's own Short Code over its Title when identifying which
  // item a modifier group belongs to: menu titles ("Coke", "Small", ...)
  // routinely repeat across different items/dishes, but Short Code is
  // unique per item, so it's the only safe key once the bulk importer
  // resolves "Item Name" against the live menu (see bulk_modifiers.js's
  // itemsByShortCode fallback).
  const rows = [];
  for (const g of events.variantGroups) {
    const itemIdentifier = g.parentShortCode || g.parentTitle;
    g.variants.forEach((v, idx) => {
      rows.push({
        "Item Name": itemIdentifier,
        "Modifier Group": g.parentTitle,
        "Modifier Name": v.title,
        "Price": v.price,
        "SKU": v.shortCode,
        "Short Code": v.shortCode,
        "Status": 1,
        "Default Qty": 1,
        "Group Max": 1,
        "Group Min": 1,
        "Group Max Single Selection": 1,
        "Modifier Rank": idx + 1,
      });
    });
  }
  for (const a of events.addonEntries) {
    rows.push({
      "Item Name": a.targetShortCode || a.targetTitle,
      "Modifier Group": a.groupName,
      "Modifier Name": a.modifierTitle,
      "Price": a.price,
      "SKU": a.shortCode,
      "Short Code": a.shortCode,
      "Status": 1,
      "Default Qty": 1,
      "Group Max": a.max,
      "Group Min": a.min,
      "Group Max Single Selection": a.singleSelection,
      "Modifier Rank": 1,
    });
  }
  return rows;
}

function mcFormatAsOptionGroupRows(events) {
  // Same Short-Code-over-Title preference as mcFormatAsModifierRows above.
  const rows = [];
  for (const g of events.variantGroups) {
    const itemIdentifier = g.parentShortCode || g.parentTitle;
    g.variants.forEach((v, idx) => {
      rows.push({
        "Item Name": itemIdentifier,
        "Option Group": g.parentTitle,
        "Option Name": v.title,
        "Price": v.price,
        "Short Code": v.shortCode,
        "Min Selectable": 1,
        "Max Selectable": 1,
        "Is Addon": 0,
        "Status": 1,
        "Sort Rank": idx + 1,
      });
    });
  }
  for (const a of events.addonEntries) {
    rows.push({
      "Item Name": a.targetShortCode || a.targetTitle,
      "Option Group": a.groupName,
      "Option Name": a.modifierTitle,
      "Price": a.price,
      "Short Code": a.shortCode,
      "Min Selectable": a.min,
      "Max Selectable": a.max,
      "Is Addon": 1,
      "Status": 1,
      "Sort Rank": 1,
    });
  }
  return rows;
}

/** Converts a parsed raw-menu workbook (rows + columns, as returned by
 * readWorkbookFile) into the Modifier bulk-import row shape. */
function convertRawMenuToModifierRows(rawRows, columns) {
  const { normalizedRows, hasDescriptionCol } = mcNormalizeRows(rawRows, columns);
  const events = mcBuildConversionEvents(normalizedRows, hasDescriptionCol);
  const rows = mcFormatAsModifierRows(events);
  const outColumns = [
    "Item Name", "Modifier Group", "Modifier Name", "Price", "SKU", "Short Code",
    "Status", "Default Qty", "Group Max", "Group Min", "Group Max Single Selection", "Modifier Rank",
  ];
  return {
    rows,
    columns: outColumns,
    skippedNoVariant: events.skippedNoVariant,
    addonCount: events.addonEntries.length,
    groupCount: new Set(rows.map((r) => `${r["Item Name"]}||${r["Modifier Group"]}`)).size,
  };
}

/** Same as above, but in the Option Group bulk-import row shape. */
function convertRawMenuToOptionGroupRows(rawRows, columns) {
  const { normalizedRows, hasDescriptionCol } = mcNormalizeRows(rawRows, columns);
  const events = mcBuildConversionEvents(normalizedRows, hasDescriptionCol);
  const rows = mcFormatAsOptionGroupRows(events);
  const outColumns = [
    "Item Name", "Option Group", "Option Name", "Price", "Short Code",
    "Min Selectable", "Max Selectable", "Is Addon", "Status", "Sort Rank",
  ];
  return {
    rows,
    columns: outColumns,
    skippedNoVariant: events.skippedNoVariant,
    addonCount: events.addonEntries.length,
    groupCount: new Set(rows.map((r) => `${r["Item Name"]}||${r["Option Group"]}`)).size,
  };
}

;
// Uses the shared $, log, sendMsg, fillSelect, displayName helpers defined
// in popup.js (loaded first, same popup page/global scope).

function currentContext() {
  return {
    storeId: $("outlet-select").value || null,
    menuId: $("menu-select").value || null,
  };
}

function renderDeletableList(ul, items, labelFn, onDelete) {
  ul.innerHTML = "";
  if (!items.length) {
    const li = document.createElement("li");
    li.textContent = "Nothing found.";
    ul.appendChild(li);
    return;
  }
  for (const item of items) {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = labelFn(item);
    const btn = document.createElement("button");
    btn.textContent = "Delete";
    btn.addEventListener("click", () => onDelete(item, li));
    li.appendChild(span);
    li.appendChild(btn);
    ul.appendChild(li);
  }
}

// ---------------- Modifier Groups ----------------

$("mg-fetch-btn").addEventListener("click", async () => {
  const { storeId, menuId } = currentContext();
  if (!storeId) return log("Pick an outlet first.", true);
  $("mg-fetch-btn").disabled = true;
  try {
    const res = await sendMsg("MG_LIST", { storeId, menuId });
    log(`Fetched ${res.groups.length} modifier group(s).`);
    renderDeletableList(
      $("mg-list"),
      res.groups,
      (g) => `${g.title || g.name} (#${g.id})`,
      async (g, li) => {
        try {
          await sendMsg("MG_DELETE", { groupId: g.id });
          log(`Deleted modifier group #${g.id}.`);
          li.remove();
        } catch (e) {
          log(e.message, true);
        }
      }
    );
  } catch (e) {
    log(e.message, true);
  } finally {
    $("mg-fetch-btn").disabled = false;
  }
});

$("mg-load-items-btn").addEventListener("click", async () => {
  const { menuId } = currentContext();
  if (!menuId) return log("Pick a menu first.", true);
  try {
    const res = await sendMsg("FETCH_OUTLET_MENU_LIST", { menuId });
    fillSelect($("mg-item-select"), res.items, "id", (i) => i.title || i.name || `Item #${i.id}`, "-- optional: pick from menu --");
    log(`Loaded ${res.items.length} menu item(s).`);
  } catch (e) {
    log(e.message, true);
  }
});

$("mg-item-select").addEventListener("change", () => {
  const val = $("mg-item-select").value;
  if (val) $("mg-gid").value = val;
});

$("mg-create-btn").addEventListener("click", async () => {
  const { storeId, menuId } = currentContext();
  if (!storeId || !menuId) return log("Pick an outlet and menu first.", true);
  const gid = $("mg-gid").value;
  const title = $("mg-title").value.trim();
  if (!gid || !title) return log("Parent item id and title are required.", true);

  // Payload shape matches modifier_group.py's build_payload() exactly.
  const payload = {
    id: null,
    gid: Number(gid),
    tmpos_id: "",
    store_id: storeId,
    menu_id: Number(menuId),
    title,
    subtitle: $("mg-subtitle").value.trim(),
    description: "",
    extra_details: {
      alternative_title: "",
      modifiers: { alignment: "horizontal" },
      enable_for_print: 1,
    },
    max: Number($("mg-max").value || 1),
    max_single_selection: Number($("mg-max-single").value || 1),
    min: Number($("mg-min").value || 0),
    rank: Number($("mg-rank").value || 1),
    status: Number($("mg-status").value),
    tags: null,
    type: Number($("mg-type").value),
    visible_for_coc: 1,
    coc: 1,
  };

  $("mg-create-btn").disabled = true;
  try {
    await sendMsg("MG_CREATE", { payload });
    log(`Created modifier group "${title}".`);
    $("mg-fetch-btn").click();
  } catch (e) {
    log(e.message, true);
  } finally {
    $("mg-create-btn").disabled = false;
  }
});

// ---------------- Modifiers (within a group) ----------------

$("mod-fetch-btn").addEventListener("click", async () => {
  const groupId = $("mod-group-id").value;
  if (!groupId) return log("Enter a group id first.", true);
  $("mod-fetch-btn").disabled = true;
  try {
    const res = await sendMsg("MOD_LIST", { groupId });
    log(`Fetched ${res.modifiers.length} modifier(s) for group #${groupId}.`);
    renderDeletableList(
      $("mod-list"),
      res.modifiers,
      (m) => `${m.title || m.name} (#${m.id})`,
      async (m, li) => {
        try {
          await sendMsg("MOD_DELETE", { modifierId: m.id });
          log(`Deleted modifier #${m.id}.`);
          li.remove();
        } catch (e) {
          log(e.message, true);
        }
      }
    );
  } catch (e) {
    log(e.message, true);
  } finally {
    $("mod-fetch-btn").disabled = false;
  }
});

$("mod-create-btn").addEventListener("click", async () => {
  const { storeId, menuId } = currentContext();
  const groupId = $("mod-group-id").value;
  const itemId = $("mod-item-id").value;
  const title = $("mod-title").value.trim();
  if (!storeId || !menuId) return log("Pick an outlet and menu first.", true);
  if (!groupId || !itemId || !title) return log("Group id, item id, and title are required.", true);

  // Payload shape matches modifier.py's build_payload() exactly.
  const payload = {
    id: null,
    unique_id: "",
    tmpos_id: "",
    store_id: storeId,
    menu_id: Number(menuId),
    group_id: Number(groupId),
    item_id: Number(itemId),
    short_code: $("mod-short-code").value.trim(),
    title,
    subtitle: $("mod-subtitle").value.trim(),
    description: null,
    price: Number($("mod-price").value || 0),
    defaultQty: Number($("mod-default-qty").value || 0),
    default_selected: 0,
    status: Number($("mod-status").value),
    sku: "",
    rank: Number($("mod-rank").value || 1),
    min: 0,
    max: 1,
    free: 0,
    extra: 0,
    has_nested_mg: 0,
    has_customisation: 0,
    tags: null,
    extra_details: { multiplier: "", alternative_title: "" },
  };

  $("mod-create-btn").disabled = true;
  try {
    await sendMsg("MOD_CREATE", { payload });
    log(`Created modifier "${title}" in group #${groupId}.`);
    $("mod-fetch-btn").click();
  } catch (e) {
    log(e.message, true);
  } finally {
    $("mod-create-btn").disabled = false;
  }
});

;
/**
 * bulk_modifiers.js -- Excel-driven bulk creation of Modifier Groups +
 * Modifiers, ported from the desktop suite's excel_reader.py / main.py /
 * modifier_group.py / modifier.py / mapping.py.
 *
 * Scope of this port (MVP): the core happy-path pipeline --
 *   read Excel -> group by (Item Name, Modifier Group) -> resolve item ->
 *   get-or-create group -> create/skip-duplicate each modifier ->
 *   associate group with its parent item.
 * NOT ported (yet): session-expiry re-login/resume, retry passes, the
 * cross-outlet BulkRunGuard rate-limit coordination shared across the
 * desktop tool's processes. This extension applies its own conservative
 * pacing instead (see RATE_LIMIT below) since it can't see that state.
 */

// ---- Column aliases (mirrors excel_reader.py's _COLUMN_ALIASES) ----
const COLUMN_ALIASES = {
  item_name: ["item name", "item", "menu item", "item_name", "item sku", "item title"],
  modifier_group: ["modifier group", "modifier_group", "group", "group title", "group name"],
  modifier_group_subtitle: ["modifier group subtitle", "group subtitle"],
  modifier_name: ["modifier name", "modifier_name", "modifier", "option name", "title"],
  modifier_subtitle: ["modifier subtitle", "option subtitle", "subtitle"],
  price: ["price", "amount", "rate"],
  sku: ["sku", "modifier sku"],
  short_code: ["short code", "short_code", "shortcode", "code"],
  status: ["status", "active"],
  default_qty: ["default qty", "default_qty", "default quantity", "qty"],
  group_max: ["group max", "max"],
  group_min: ["group min", "min"],
  group_max_single_selection: ["group max single selection", "max single selection", "max_single_selection"],
  group_rank: ["group rank"],
  group_type: ["group type"],
  group_visible_for_coc: ["group visible for coc", "visible for coc", "visible_for_coc"],
  modifier_rank: ["modifier rank", "rank"],
  modifier_type: ["modifier type", "type"],
};

function normHeader(h) {
  return String(h).trim().toLowerCase().replace(/_/g, " ").replace(/\s+/g, " ").trim();
}

function buildColumnMap(columns) {
  const normToActual = {};
  for (const c of columns) normToActual[normHeader(c)] = c;
  const resolved = {};
  for (const [canonical, aliases] of Object.entries(COLUMN_ALIASES)) {
    for (const alias of aliases) {
      if (alias in normToActual) {
        resolved[canonical] = normToActual[alias];
        break;
      }
    }
  }
  return resolved;
}

function isBlank(v) {
  if (v === null || v === undefined) return true;
  if (typeof v === "number") return Number.isNaN(v);
  if (typeof v === "string") return v.trim() === "";
  return false;
}
function toStr(v, dflt = "") {
  return isBlank(v) ? dflt : String(v).trim();
}
function toFloat(v, field, rowNum, dflt) {
  if (isBlank(v)) {
    if (dflt !== undefined) return dflt;
    throw new Error(`Row ${rowNum}: '${field}' is required but blank.`);
  }
  const n = Number(v);
  if (Number.isNaN(n)) throw new Error(`Row ${rowNum}: '${field}' value '${v}' is not numeric.`);
  return n;
}
function toInt(v, field, rowNum, dflt) {
  if (isBlank(v)) {
    if (dflt !== undefined) return dflt;
    throw new Error(`Row ${rowNum}: '${field}' is required but blank.`);
  }
  const n = Number(v);
  if (Number.isNaN(n)) throw new Error(`Row ${rowNum}: '${field}' value '${v}' is not an integer.`);
  return Math.trunc(n);
}
function normalizeStatus(v, rowNum, dflt = 1) {
  if (isBlank(v)) return dflt;
  const text = String(v).trim().toLowerCase();
  if (["1", "active", "true", "yes", "enabled"].includes(text)) return 1;
  if (["0", "inactive", "false", "no", "disabled"].includes(text)) return 0;
  if (/^-?\d+(\.\d+)?$/.test(text)) return Number(text) !== 0 ? 1 : 0;
  throw new Error(`Row ${rowNum}: 'Status' value '${v}' is not recognized.`);
}

/** Reads rows from a parsed worksheet (array of plain objects, header keys
 * as-is from the sheet) into validated row objects + per-row errors. */
function readRows(rawRows, columns) {
  const colmap = buildColumnMap(columns);
  const missing = ["modifier_group", "modifier_name", "price", "sku", "short_code"].filter((f) => !(f in colmap));
  if (missing.length) {
    throw new Error(`Input Excel is missing required column(s): ${missing.join(", ")}. Found columns: ${columns.join(", ")}`);
  }

  const validRows = [];
  const validationErrors = [];
  let skippedBlank = 0;
  const rankCounters = new Map();

  rawRows.forEach((raw, idx) => {
    const excelRowNumber = idx + 2;
    const get = (field) => (colmap[field] !== undefined ? raw[colmap[field]] : undefined);

    const blankCheck = ["item_name", "modifier_group", "modifier_name"].every((f) => isBlank(get(f)));
    if (blankCheck) {
      skippedBlank++;
      return;
    }

    try {
      const itemName = toStr(get("item_name"));
      if (!itemName) throw new Error(`Row ${excelRowNumber}: 'Item Name' is required but blank.`);
      const modifierGroup = toStr(get("modifier_group"));
      if (!modifierGroup) throw new Error(`Row ${excelRowNumber}: 'Modifier Group' is required but blank.`);
      const modifierName = toStr(get("modifier_name"));
      if (!modifierName) throw new Error(`Row ${excelRowNumber}: 'Modifier Name' is required but blank.`);

      const modifierGroupSubtitle = toStr(get("modifier_group_subtitle"), modifierGroup) || modifierGroup;
      const modifierSubtitle = toStr(get("modifier_subtitle"), modifierName) || modifierName;

      const price = toFloat(get("price"), "Price", excelRowNumber);
      const sku = toStr(get("sku"));
      if (!sku) throw new Error(`Row ${excelRowNumber}: 'SKU' is required but blank.`);
      const shortCode = toStr(get("short_code"));
      if (!shortCode) throw new Error(`Row ${excelRowNumber}: 'Short Code' is required but blank.`);

      const status = normalizeStatus(get("status"), excelRowNumber, 1);
      const defaultQty = toInt(get("default_qty"), "Default Qty", excelRowNumber, 1);
      const groupMax = toInt(get("group_max"), "Group Max", excelRowNumber, 1);
      const groupMin = toInt(get("group_min"), "Group Min", excelRowNumber, 0);
      const groupMaxSingle = toInt(get("group_max_single_selection"), "Group Max Single Selection", excelRowNumber, 1);
      const groupRank = toInt(get("group_rank"), "Group Rank", excelRowNumber, 0);
      const groupType = toInt(get("group_type"), "Group Type", excelRowNumber, 0);
      const groupVisibleForCoc = toInt(get("group_visible_for_coc"), "Group Visible For COC", excelRowNumber, 0);
      const modifierType = toInt(get("modifier_type"), "Modifier Type", excelRowNumber, 0);

      const rankKey = `${itemName.toLowerCase()}\u0001${modifierGroup.toLowerCase()}`;
      const autoRank = (rankCounters.get(rankKey) || 0) + 1;
      rankCounters.set(rankKey, autoRank);
      const modifierRank = toInt(get("modifier_rank"), "Modifier Rank", excelRowNumber, autoRank);

      validRows.push({
        rowNumber: excelRowNumber,
        itemName,
        modifierGroup,
        modifierGroupSubtitle,
        modifierName,
        modifierSubtitle,
        price,
        sku,
        shortCode,
        status,
        defaultQty,
        groupMax,
        groupMin,
        groupMaxSingle,
        groupRank,
        groupType,
        groupVisibleForCoc,
        modifierRank,
        modifierType,
        error: null,
        stageReached: null,
      });
    } catch (e) {
      validationErrors.push([excelRowNumber, e.message]);
    }
  });

  return { validRows, validationErrors, skippedBlank };
}

/** Groups validated rows by (item_name, modifier_group), preserving order. */
function groupRows(rows) {
  const grouped = new Map();
  for (const row of rows) {
    const key = `${row.itemName.trim().toLowerCase()}\u0001${row.modifierGroup.trim().toLowerCase()}`;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  }
  return grouped;
}

/** Collapses ALL whitespace (not just leading/trailing) and lowercases, so
 * '300 ML', '300ML', '300 Ml', '300Ml' etc. all normalize to the same key.
 * This is intentionally more aggressive than trim()+toLowerCase() alone,
 * which only strips edge whitespace and left internally-inconsistent
 * spacing (e.g. bulk-file '300ML' vs TMBill's stored '300 ML') unmatched. */
function collapseKey(v) {
  return String(v || "").trim().toLowerCase().replace(/\s+/g, "");
}

/** Same short-code-suffix derivation as menu_converter.js's
 * deriveParentByShortCodeSuffix -- kept as an independent copy here since
 * this file must also work standalone (menu_converter.js is optional/lazy
 * loaded). Given a variant's short code like 'SZ38A', tries stripping a
 * 1- or 2-letter trailing suffix ('A', 'BB', ...) and looks up the
 * remainder ('SZ38') against parentsByShortCode. */
function ibDeriveParentByShortCodeSuffix(variantShortCode, parentsByShortCode) {
  const sc = String(variantShortCode || "").trim();
  if (!sc) return null;
  for (const suffixLen of [1, 2]) {
    if (sc.length <= suffixLen) continue;
    const prefix = sc.slice(0, -suffixLen);
    const suffix = sc.slice(-suffixLen);
    if (!/^[A-Za-z]+$/.test(suffix)) continue;
    const match = parentsByShortCode.get(prefix.toLowerCase());
    if (match) return match;
  }
  return null;
}

// ---- Item index (mirrors modifier_group.py's ItemIndex) ----
function buildItemIndex(outletMenuListItems, menuId) {
  const itemsByName = new Map();
  const itemsByShortCode = new Map();
  const variantsByShortCode = new Map();
  const variantsByTitle = new Map();
  const knownItemIds = new Set();

  // ---- Pass 1: register every parent (item_type=0) up front, independent
  // of ordering, so variant matching in pass 2 doesn't depend on parents
  // having already been seen positionally. ----
  const entries = [];
  for (const entry of outletMenuListItems) {
    if (!entry || typeof entry !== "object") continue;
    const rawId = entry.item_id !== undefined ? entry.item_id : entry.id;
    const itemId = Number(rawId);
    if (Number.isNaN(itemId)) continue;
    entries.push({ entry, itemId });

    if (entry.item_type === 0) {
      const title = entry.title || entry.name || "";
      const parent = {
        itemId,
        menuId,
        name: String(title),
        shortCode: String(entry.short_code || ""),
        variants: new Map(),
        variantsCollapsed: new Map(),
        existingGroups: new Map(),
      };
      knownItemIds.add(itemId);
      if (title) itemsByName.set(String(title).trim().toLowerCase(), parent);
      if (entry.short_code) itemsByShortCode.set(String(entry.short_code).trim().toLowerCase(), parent);
    }
  }

  // ---- Pass 2: attach every variant (item_type=1) to its parent. ----
  // TMBill's outlet-menu-list API can return items either (a) interleaved
  // -- each parent immediately followed by its own variants -- or (b) in
  // blocks -- all parents first, then all variants appended at the bottom,
  // correlated to their parent only via the Short Code suffix convention
  // (parent 'SZ38' -> variants 'SZ38A'/'SZ38B'). Trusting position alone
  // on a (b)-shaped response silently drops or misattaches every variant
  // (currentParent is null or stale), which is exactly why some parents'
  // modifier groups were failing to create despite the variant clearly
  // existing under the right short code. Short-code-suffix matching is
  // tried FIRST for every variant; position is only used as a fallback
  // for variants with no short code or a non-conforming one.
  let currentParent = null;
  for (const { entry, itemId } of entries) {
    const itemType = entry.item_type;
    const title = entry.title || entry.name || "";

    if (itemType === 0) {
      currentParent = itemsByShortCode.get(String(entry.short_code || "").trim().toLowerCase())
        || itemsByName.get(String(title).trim().toLowerCase())
        || null;
      continue;
    }
    if (itemType !== 1) continue;

    const scMatchedParent = ibDeriveParentByShortCodeSuffix(entry.short_code, itemsByShortCode);
    const parent = scMatchedParent || currentParent;
    if (!parent) continue; // no short-code match and no positional parent yet -- nothing to attach to

    const salePrice = Number(entry.sale_price || 0) || 0;
    const variant = { itemId, title: String(title), shortCode: String(entry.short_code || ""), salePrice };
    knownItemIds.add(itemId);
    if (title) {
      parent.variants.set(String(title).trim().toLowerCase(), variant);
      // Fallback index for whitespace-insensitive matching (e.g. '300ML' -> '300 ML').
      // Only keep the first match per collapsed key; if two distinct variants under
      // the same parent collapse to the same key (rare), leave collapsed lookup
      // ambiguous by not overwriting, so the exact-match path is required instead.
      const ck = collapseKey(title);
      if (!parent.variantsCollapsed.has(ck)) {
        parent.variantsCollapsed.set(ck, variant);
      } else if (parent.variantsCollapsed.get(ck) !== variant) {
        parent.variantsCollapsed.set(ck, null); // mark ambiguous
      }
    }
    if (entry.short_code) variantsByShortCode.set(String(entry.short_code).trim().toLowerCase(), variant);
    if (title) {
      const key = String(title).trim().toLowerCase();
      if (!variantsByTitle.has(key)) variantsByTitle.set(key, []);
      variantsByTitle.get(key).push(variant);
    }
  }

  return {
    itemsByName,
    itemsByShortCode,
    variantsByShortCode,
    variantsByTitle,
    knownItemIds,
    resolveItem(itemName) {
      const key = itemName.trim().toLowerCase();
      return itemsByName.get(key) || itemsByShortCode.get(key) || null;
    },
    findStandaloneItem(name) {
      const key = name.trim().toLowerCase();
      const parent = itemsByName.get(key) || itemsByShortCode.get(key);
      if (parent) return { itemId: parent.itemId, title: parent.name, shortCode: parent.shortCode, salePrice: 0 };
      const variant = variantsByShortCode.get(key);
      if (variant) return variant;
      const candidates = variantsByTitle.get(key) || [];
      if (candidates.length === 1) return candidates[0];
      return null; // not found, or ambiguous (2+ matches) -- same as Python: not used
    },
  };
}

function collectAllItemIds(node, out) {
  if (Array.isArray(node)) {
    for (const v of node) collectAllItemIds(v, out);
  } else if (node && typeof node === "object") {
    if (node.item_id !== undefined && node.item_id !== null) {
      const n = Number(node.item_id);
      if (!Number.isNaN(n)) out.add(n);
    }
    for (const v of Object.values(node)) collectAllItemIds(v, out);
  }
}

function collectGroupCandidates(node, out) {
  if (Array.isArray(node)) {
    for (const e of node) collectGroupCandidates(e, out);
  } else if (node && typeof node === "object") {
    const groupId = node.id !== undefined ? node.id : node.group_id;
    const title = node.title || node.name;
    if (groupId !== undefined && groupId !== null && title) {
      const key = String(title).trim().toLowerCase();
      const id = Number(groupId);
      if (!Number.isNaN(id)) {
        if (!out.has(key)) out.set(key, []);
        out.get(key).push(id);
      }
    }
    for (const v of Object.values(node)) collectGroupCandidates(v, out);
  }
}

// ---- Conservative self-contained pacing (this extension can't see the
// desktop suite's shared BulkRunGuard, so it applies its own fixed pause:
// a short gap between every write call, and a longer pause every 10). ----
const RATE_LIMIT = { everyN: 10, longPauseMs: 20000, shortPauseMs: 500 };
let writeCallCount = 0;
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
async function paceWriteCall(onStep) {
  writeCallCount++;
  if (writeCallCount % RATE_LIMIT.everyN === 0) {
    onStep(`Pacing pause: ${RATE_LIMIT.longPauseMs / 1000}s after ${writeCallCount} write calls (avoiding rate limits)...`);
    await sleep(RATE_LIMIT.longPauseMs);
  } else {
    await sleep(RATE_LIMIT.shortPauseMs);
  }
}

// ---- Modifier Group payload (mirrors modifier_group.py build_payload) ----
function buildGroupPayload(row, item, storeId) {
  const isShared = row.modifierGroup.trim().toLowerCase() !== item.name.trim().toLowerCase();
  let groupTypeValue = row.groupType;
  if (groupTypeValue === 0) groupTypeValue = isShared ? 1 : 0;
  return {
    id: null,
    gid: item.itemId,
    tmpos_id: "",
    store_id: storeId,
    menu_id: item.menuId,
    title: row.modifierGroup,
    subtitle: row.modifierGroupSubtitle,
    description: "",
    extra_details: { alternative_title: "", modifiers: { alignment: "horizontal" }, enable_for_print: 1 },
    max: row.groupMax,
    max_single_selection: row.groupMaxSingle,
    min: row.groupMin,
    rank: row.groupRank,
    status: row.status,
    tags: null,
    type: groupTypeValue,
    visible_for_coc: row.groupVisibleForCoc,
    coc: row.groupVisibleForCoc,
  };
}

function extractCreatedId(response) {
  if (response && typeof response === "object") {
    for (const key of ["id", "group_id", "modifier_id"]) {
      if (response[key] !== undefined && response[key] !== null) return Number(response[key]);
    }
    if (response.result && typeof response.result === "object") return extractCreatedId(response.result);
    if (response.data && typeof response.data === "object") return extractCreatedId(response.data);
  }
  return null;
}

async function groupBelongsToItem(groupId, itemId, storeId, onStep) {
  try {
    const res = await sendMsg("MAPPING_FETCH", { groupId, storeId });
    const ids = new Set();
    collectAllItemIds(res.mapping, ids);
    return ids.has(itemId);
  } catch (e) {
    onStep(`  (mapping check failed for group_id=${groupId}: ${e.message}; treating as not confirmed)`);
    return false;
  }
}

async function getOrCreateGroup(row, item, candidateGroupIds, storeId, sharedGroupCache, knownItemIds, onStep) {
  const titleKey = row.modifierGroup.trim().toLowerCase();
  const itemKey = item.name.trim().toLowerCase();
  const isShared = titleKey !== itemKey;

  if (!isShared) {
    const cached = item.existingGroups.get(titleKey);
    if (cached !== undefined) return { groupId: cached, created: false };

    for (const candidateId of candidateGroupIds || []) {
      if (await groupBelongsToItem(candidateId, item.itemId, storeId, onStep)) {
        item.existingGroups.set(titleKey, candidateId);
        onStep(`  Reusing modifier group '${row.modifierGroup}' (group_id=${candidateId}) for item '${item.name}'.`);
        return { groupId: candidateId, created: false };
      }
    }
    await paceWriteCall(onStep);
    const payload = buildGroupPayload(row, item, storeId);
    const res = await sendMsg("MG_CREATE", { payload });
    const groupId = extractCreatedId(res.result);
    if (groupId === null) throw new Error(`Modifier group creation for '${row.modifierGroup}' did not return an id.`);
    item.existingGroups.set(titleKey, groupId);
    onStep(`  Created modifier group '${row.modifierGroup}' -> group_id=${groupId}.`);
    return { groupId, created: true };
  }

  // Shared/add-on group path
  if (sharedGroupCache.has(titleKey)) {
    return { groupId: sharedGroupCache.get(titleKey), created: false };
  }
  for (const candidateId of candidateGroupIds || []) {
    try {
      const res = await sendMsg("MAPPING_FETCH", { groupId: candidateId, storeId });
      const ids = new Set();
      collectAllItemIds(res.mapping, ids);
      const confirmed = [...ids].some((id) => knownItemIds.has(id));
      if (confirmed) {
        sharedGroupCache.set(titleKey, candidateId);
        onStep(`  Reusing shared/add-on group '${row.modifierGroup}' (group_id=${candidateId}, confirmed in this menu).`);
        return { groupId: candidateId, created: false };
      }
    } catch {
      /* try next candidate */
    }
  }
  await paceWriteCall(onStep);
  const payload = buildGroupPayload(row, item, storeId);
  const res = await sendMsg("MG_CREATE", { payload });
  const groupId = extractCreatedId(res.result);
  if (groupId === null) throw new Error(`Modifier group creation for '${row.modifierGroup}' did not return an id.`);
  sharedGroupCache.set(titleKey, groupId);
  onStep(`  Created shared/add-on modifier group '${row.modifierGroup}' -> group_id=${groupId}.`);
  return { groupId, created: true };
}

// ---- Existing-modifier duplicate index (mirrors modifier.py ExistingModifierIndex) ----
function buildExistingModifierIndex(raw) {
  const byShortCode = new Map();
  const byNamePrice = new Map();
  function normText(v) {
    return String(v || "").trim().toLowerCase();
  }
  function normPrice(v) {
    const n = Number(v);
    return Number.isNaN(n) ? null : Math.round(n * 100) / 100;
  }
  function walk(node) {
    if (Array.isArray(node)) {
      node.forEach(walk);
    } else if (node && typeof node === "object") {
      const title = node.title || node.name;
      const shortCode = node.short_code;
      const price = node.price;
      const modifierId = node.id !== undefined ? node.id : node.modifier_id;
      if (title !== undefined && title !== null && (shortCode !== undefined || price !== undefined)) {
        const mid = modifierId !== undefined && modifierId !== null ? Number(modifierId) : null;
        if (shortCode) byShortCode.set(normText(shortCode), mid);
        byNamePrice.set(`${normText(title)}\u0001${normPrice(price)}`, mid);
      }
      Object.values(node).forEach(walk);
    }
  }
  walk(raw);
  return {
    findDuplicateId(row) {
      const scKey = normText(row.shortCode);
      if (scKey && byShortCode.has(scKey)) return { isDuplicate: true, existingId: byShortCode.get(scKey) };
      const npKey = `${normText(row.modifierName)}\u0001${normPrice(row.price)}`;
      if (byNamePrice.has(npKey)) return { isDuplicate: true, existingId: byNamePrice.get(npKey) };
      return { isDuplicate: false, existingId: null };
    },
  };
}

function resolveUnderlyingItem(row, item, itemIndex) {
  const isShared = row.modifierGroup.trim().toLowerCase() !== item.name.trim().toLowerCase();
  if (!isShared) {
    const key = row.modifierName.trim().toLowerCase();
    let variant = item.variants.get(key);
    if (!variant) {
      // Exact match failed -- retry ignoring internal spacing differences
      // ('300ML'/'300 Ml'/'300Ml' all resolving to TMBill's stored '300 ML').
      const collapsed = item.variantsCollapsed.get(collapseKey(row.modifierName));
      if (collapsed) variant = collapsed;
    }
    if (!variant) {
      throw new Error(
        `'${row.modifierName}' was not found as an existing size/variant item under '${item.name}'. ` +
          `Create the variant item in TMBill first, or fix the 'Modifier Name' spelling.`
      );
    }
    return variant;
  }
  const addon = itemIndex.findStandaloneItem(row.modifierName);
  if (!addon) {
    throw new Error(
      `'${row.modifierName}' (shared/add-on modifier for group '${row.modifierGroup}') was not found anywhere ` +
        `in the store menu. For shared add-ons, 'Modifier Name' must exactly match an existing item's title.`
    );
  }
  return addon;
}

/** Dry-run pass over ALL grouped rows against the live itemIndex, with NO
 * API writes -- lets the popup show a clear "these items don't exist in
 * TMBill yet" warning BEFORE the run starts, instead of the user only
 * discovering per-row failures buried in the end-of-run failed_records
 * download. Mirrors exactly the same resolveItem/resolveUnderlyingItem
 * calls the real run uses, so what it reports here is guaranteed to match
 * what would actually fail. */
function preflightCheckMissingItems(grouped, itemIndex) {
  const missingParents = new Set(); // item names not found in live menu at all
  const missingVariants = []; // { itemName, modifierGroup, modifierName } -- parent exists, variant/addon doesn't
  let resolvableGroups = 0;

  for (const [, groupRowsArr] of grouped) {
    const first = groupRowsArr[0];
    const item = itemIndex.resolveItem(first.itemName);
    if (!item) {
      missingParents.add(first.itemName);
      continue;
    }
    let anyResolvable = false;
    for (const row of groupRowsArr) {
      try {
        resolveUnderlyingItem(row, item, itemIndex);
        anyResolvable = true;
      } catch (e) {
        missingVariants.push({
          itemName: row.itemName,
          modifierGroup: row.modifierGroup,
          modifierName: row.modifierName,
        });
      }
    }
    if (anyResolvable) resolvableGroups++;
  }

  return { missingParents: [...missingParents], missingVariants, resolvableGroups };
}

/** Renders the preflight warning panel into `container`. Returns nothing --
 * this never blocks the run (existing rows still get processed normally),
 * it only makes the "item not created in TMBill yet" gap visible upfront. */
function renderPreflightWarning(container, preflight) {
  const totalMissing = preflight.missingParents.length + preflight.missingVariants.length;
  if (!totalMissing) return;

  const box = document.createElement("div");
  box.className = "err";
  const heading = document.createElement("p");
  heading.textContent =
    `⚠ ${totalMissing} item/variant TMBill च्या live menu मध्ये सापडले नाहीत -- ` +
    `त्यांचे modifier तयार होणार नाहीत (skip होतील). ` +
    `TMBill मध्ये create-item API नसल्यामुळे हा extension ते स्वतः तयार करू शकत नाही -- ` +
    `आधी backoffice मधून/नेहमीच्या पद्धतीने हे items तयार करा, मग हीच file परत bulk import मध्ये चालवा:`;
  box.appendChild(heading);

  if (preflight.missingParents.length) {
    const p = document.createElement("p");
    p.textContent = `Parent item सापडला नाही (${preflight.missingParents.length}):`;
    box.appendChild(p);
    const ul = document.createElement("ul");
    for (const name of preflight.missingParents.slice(0, 30)) {
      const li = document.createElement("li");
      li.textContent = name;
      ul.appendChild(li);
    }
    if (preflight.missingParents.length > 30) {
      const li = document.createElement("li");
      li.textContent = `...आणि ${preflight.missingParents.length - 30} more.`;
      ul.appendChild(li);
    }
    box.appendChild(ul);
  }

  if (preflight.missingVariants.length) {
    const p = document.createElement("p");
    p.textContent = `Parent सापडला, पण variant/addon सापडला नाही (${preflight.missingVariants.length}):`;
    box.appendChild(p);
    const ul = document.createElement("ul");
    for (const m of preflight.missingVariants.slice(0, 30)) {
      const li = document.createElement("li");
      li.textContent = `${m.itemName} -> ${m.modifierName} (group: ${m.modifierGroup})`;
      ul.appendChild(li);
    }
    if (preflight.missingVariants.length > 30) {
      const li = document.createElement("li");
      li.textContent = `...आणि ${preflight.missingVariants.length - 30} more.`;
      ul.appendChild(li);
    }
    box.appendChild(ul);
  }

  container.appendChild(box);
}

function buildModifierPayload(row, item, groupId, variantItemId, storeId) {
  return {
    id: null,
    unique_id: "",
    tmpos_id: "",
    store_id: storeId,
    menu_id: item.menuId,
    group_id: groupId,
    item_id: variantItemId,
    short_code: row.shortCode,
    title: row.modifierName,
    subtitle: row.modifierSubtitle,
    description: null,
    price: row.price,
    defaultQty: row.defaultQty,
    default_selected: 0,
    status: row.status,
    sku: row.sku,
    rank: row.modifierRank,
    min: 0,
    max: 1,
    free: 0,
    extra: 0,
    has_nested_mg: 0,
    has_customisation: 0,
    tags: null,
    extra_details: { multiplier: "", alternative_title: "" },
  };
}

function buildMappingPayload(item, groupId, storeId, rank) {
  return {
    id: null,
    store_id: storeId,
    menu_id: item.menuId,
    group_id: groupId,
    rank: rank || 1,
    extra_details: { multiplier: "" },
    items: [{ item_id: item.itemId, short_code: item.shortCode, item_name: item.name }],
  };
}

async function isAlreadyMapped(groupId, itemId, storeId, onStep) {
  try {
    const res = await sendMsg("MAPPING_FETCH", { groupId, storeId });
    // Real mapping rows carry BOTH group_id and item_id on the same record.
    function contains(node) {
      if (Array.isArray(node)) return node.some(contains);
      if (node && typeof node === "object") {
        if (node.group_id !== undefined && node.group_id !== null && Number(node.item_id) === itemId) return true;
        return Object.values(node).some(contains);
      }
      return false;
    }
    return contains(res.mapping);
  } catch (e) {
    onStep(`  (mapping check failed: ${e.message}; proceeding to associate)`);
    return false;
  }
}

// ---- Main pipeline ----
async function runBulkModifierImport({ rows, itemIndex, storeId, menuId, groupCandidatesByTitle, onStep, onProgress }) {
  const summary = {
    groupsCreated: 0,
    groupsReused: 0,
    groupsFailed: 0,
    groupsMapped: 0,
    modifiersCreated: 0,
    modifiersDuplicateSkipped: 0,
    modifiersFailed: 0,
    successes: [],
    failures: [],
  };
  const sharedGroupCache = new Map();
  const grouped = groupRows(rows);
  const modifierListCache = new Map(); // groupId -> ExistingModifierIndex

  let groupsDone = 0;
  const totalGroups = grouped.size;

  for (const [, groupRowsArr] of grouped) {
    groupsDone++;
    const first = groupRowsArr[0];
    onStep(`[${groupsDone}/${totalGroups}] Group '${first.modifierGroup}' under item '${first.itemName}' (${groupRowsArr.length} row(s))`);
    if (onProgress) onProgress(groupsDone, totalGroups);

    const item = itemIndex.resolveItem(first.itemName);
    if (!item) {
      for (const row of groupRowsArr) {
        row.error = `Menu item '${first.itemName}' was not found under menu_id=${menuId}.`;
        row.stageReached = "item_lookup";
        summary.failures.push(row);
      }
      summary.groupsFailed++;
      onStep(`  FAILED: item '${first.itemName}' not found in this menu.`, true);
      continue;
    }

    // Pre-check: which rows can actually resolve to an existing variant/item?
    const resolvable = [];
    const unresolvable = [];
    for (const row of groupRowsArr) {
      try {
        resolveUnderlyingItem(row, item, itemIndex);
        resolvable.push(row);
      } catch (e) {
        row.error = e.message;
        row.stageReached = "item_lookup";
        unresolvable.push(row);
      }
    }
    if (!resolvable.length) {
      for (const row of unresolvable) summary.failures.push(row);
      summary.groupsFailed++;
      onStep(`  FAILED: none of ${groupRowsArr.length} row(s) resolved to an existing item/variant -- skipping group creation. First reason: ${unresolvable[0].error}`, true);
      continue;
    }
    if (unresolvable.length) {
      onStep(`  WARNING: ${unresolvable.length}/${groupRowsArr.length} row(s) won't resolve and will be skipped.`, true);
    }

    const titleKey = first.modifierGroup.trim().toLowerCase();
    const candidateGroupIds = groupCandidatesByTitle.get(titleKey) || [];

    let groupId, created;
    try {
      ({ groupId, created } = await getOrCreateGroup(first, item, candidateGroupIds, storeId, sharedGroupCache, itemIndex.knownItemIds, onStep));
      if (created) summary.groupsCreated++;
      else summary.groupsReused++;
    } catch (e) {
      for (const row of groupRowsArr) {
        row.error = `Group creation failed: ${e.message}`;
        row.stageReached = "group_create";
        summary.failures.push(row);
      }
      summary.groupsFailed++;
      onStep(`  FAILED: group creation error: ${e.message}`, true);
      continue;
    }

    for (const row of unresolvable) {
      row.groupId = groupId;
      row.itemId = item.itemId;
      summary.failures.push(row);
    }

    if (!modifierListCache.has(groupId)) {
      try {
        const res = await sendMsg("MOD_LIST", { groupId });
        modifierListCache.set(groupId, buildExistingModifierIndex(res.modifiers));
      } catch {
        modifierListCache.set(groupId, buildExistingModifierIndex(null));
      }
    }
    const existingIdx = modifierListCache.get(groupId);

    let groupHadSuccess = false;
    for (const row of resolvable) {
      row.groupId = groupId;
      row.itemId = item.itemId;
      const variant = resolveUnderlyingItem(row, item, itemIndex); // already validated above
      const dup = existingIdx.findDuplicateId(row);
      if (dup.isDuplicate) {
        row.modifierId = dup.existingId;
        row.stageReached = "modifier_duplicate_skipped";
        summary.modifiersDuplicateSkipped++;
        summary.successes.push(row);
        groupHadSuccess = true;
        onStep(`  Modifier '${row.modifierName}' already exists -- skipped duplicate.`);
        continue;
      }
      try {
        await paceWriteCall(onStep);
        const payload = buildModifierPayload(row, item, groupId, variant.itemId, storeId);
        const res = await sendMsg("MOD_CREATE", { payload });
        row.modifierId = extractCreatedId(res.result);
        row.stageReached = "modifier_create";
        summary.modifiersCreated++;
        summary.successes.push(row);
        groupHadSuccess = true;
        onStep(`  Created modifier '${row.modifierName}' (SKU=${row.sku}).`);
      } catch (e) {
        row.error = `Modifier creation failed: ${e.message}`;
        row.stageReached = "modifier_create";
        summary.modifiersFailed++;
        summary.failures.push(row);
        onStep(`  FAILED modifier '${row.modifierName}': ${e.message}`, true);
      }
    }

    if (groupHadSuccess) {
      try {
        const alreadyMapped = await isAlreadyMapped(groupId, item.itemId, storeId, onStep);
        if (!alreadyMapped) {
          await paceWriteCall(onStep);
          const payload = buildMappingPayload(item, groupId, storeId, first.groupRank || 1);
          await sendMsg("MAPPING_CREATE", { payload });
          onStep(`  Associated group_id=${groupId} with item '${item.name}'.`);
        } else {
          onStep(`  group_id=${groupId} already associated with '${item.name}'; skipped.`);
        }
        summary.groupsMapped++;
      } catch (e) {
        onStep(`  WARNING: association of group_id=${groupId} with '${item.name}' failed: ${e.message}`, true);
      }
    }
  }

  return summary;
}

// ---- UI wiring ----
let bulkParsedRows = null;
let bulkLastSummary = null;

function bulkLog(text, isError = false) {
  log(`[bulk] ${text}`, isError);
}

/** Shared safety check (used by both bulk_modifiers.js and
 * bulk_optiongroups.js): since the login session persists across popup
 * opens until an explicit "Log out" (see chrome.storage.session in
 * background.js), a stale session from an earlier client can silently
 * still be active. Forces an explicit confirm of account/outlet/menu
 * right before any bulk write run. */
function confirmBulkRunContext(stateRes) {
  const outletSelect = $("outlet-select");
  const menuSelect = $("menu-select");
  const outletLabel =
    outletSelect && outletSelect.selectedOptions[0] ? outletSelect.selectedOptions[0].textContent : stateRes.state.storeId;
  const menuLabel =
    menuSelect && menuSelect.selectedOptions[0] ? menuSelect.selectedOptions[0].textContent : stateRes.state.menuId;
  const msg =
    `तुम्ही आत्ता या खात्यावर bulk import करणार आहात:\n\n` +
    `Logged in as: ${stateRes.state.username}\n` +
    `Outlet: ${outletLabel}\n` +
    `Menu: ${menuLabel}\n\n` +
    `हे बरोबर आहे का? चुकीचं असेल तर आधी "Log out" करून बरोबर account ने परत login करा.\n\n` +
    `पुढे जाण्यासाठी OK दाबा, थांबण्यासाठी Cancel.`;
  return window.confirm(msg);
}

async function readWorkbookFile(file) {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const sheetName = wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, { defval: null, raw: true });
  const columns = rows.length ? Object.keys(rows[0]) : (XLSX.utils.sheet_to_json(sheet, { header: 1 })[0] || []);
  return { rows, columns };
}

{
  const fileInput = $("bulk-mod-file");
  const parseBtn = $("bulk-mod-parse-btn");
  const runBtn = $("bulk-mod-run-btn");
  const downloadBtn = $("bulk-mod-download-btn");
  const preview = $("bulk-mod-preview");
  const progress = $("bulk-mod-progress");
  const summaryEl = $("bulk-mod-summary");

  parseBtn.addEventListener("click", async () => {
    const file = fileInput.files[0];
    if (!file) {
      bulkLog("Choose an .xlsx file first.", true);
      return;
    }
    try {
      let { rows: rawRows, columns } = await readWorkbookFile(file);
      if (typeof looksLikeRawMenu === "function" && looksLikeRawMenu(columns)) {
        bulkLog(`'${file.name}' raw Atlantic menu export दिसतंय (Modifier Group column नाही) -- auto-convert करत आहे...`);
        const converted = convertRawMenuToModifierRows(rawRows, columns);
        rawRows = converted.rows;
        columns = converted.columns;
        let msg = `Auto-convert पूर्ण: ${converted.groupCount} group(s), ${converted.addonCount} addon-sentence row(s) added`;
        if (converted.skippedNoVariant.length) {
          msg += `; ${converted.skippedNoVariant.length} single-price item(s) skipped (no variant, no addon sentence).`;
        } else {
          msg += ".";
        }
        bulkLog(msg);
      }
      const { validRows, validationErrors, skippedBlank } = readRows(rawRows, columns);
      bulkParsedRows = validRows;
      preview.innerHTML = "";
      const summaryLine = document.createElement("p");
      summaryLine.textContent =
        `Parsed ${validRows.length} valid row(s), ${validationErrors.length} error(s), ${skippedBlank} blank row(s) skipped.`;
      preview.appendChild(summaryLine);
      if (validationErrors.length) {
        const ul = document.createElement("ul");
        for (const [rowNum, msg] of validationErrors.slice(0, 20)) {
          const li = document.createElement("li");
          li.className = "err";
          li.textContent = `Row ${rowNum}: ${msg}`;
          ul.appendChild(li);
        }
        if (validationErrors.length > 20) {
          const li = document.createElement("li");
          li.textContent = `...and ${validationErrors.length - 20} more.`;
          ul.appendChild(li);
        }
        preview.appendChild(ul);
      }
      const groups = groupRows(validRows);
      const groupsLine = document.createElement("p");
      groupsLine.textContent = `Groups by (Item, Modifier Group): ${groups.size}`;
      preview.appendChild(groupsLine);
      runBtn.disabled = validRows.length === 0;
      downloadBtn.hidden = true;
      bulkLog(`Parsed '${file.name}': ${validRows.length} valid row(s) across ${groups.size} group(s).`);
    } catch (e) {
      bulkLog(e.message, true);
      runBtn.disabled = true;
    }
  });

  runBtn.addEventListener("click", async () => {
    if (!bulkParsedRows || !bulkParsedRows.length) return;
    const stateRes = await sendMsg("GET_STATE");
    const storeId = stateRes.state.storeId;
    const menuId = stateRes.state.menuId;
    if (!storeId || !menuId) {
      bulkLog("Select an Outlet and Menu at the top of the popup first.", true);
      return;
    }
    if (!confirmBulkRunContext(stateRes)) {
      bulkLog("Import cancelled -- account/outlet/menu not confirmed.", true);
      return;
    }

    runBtn.disabled = true;
    parseBtn.disabled = true;
    progress.textContent = "Loading menu items and existing modifier groups...";
    summaryEl.innerHTML = "";

    try {
      const [itemsRes, groupsRes] = await Promise.all([
        sendMsg("FETCH_OUTLET_MENU_LIST", { menuId }),
        sendMsg("MG_LIST", { storeId, menuId }),
      ]);
      const itemIndex = buildItemIndex(itemsRes.items, menuId);
      const groupCandidatesByTitle = new Map();
      collectGroupCandidates(groupsRes.groups, groupCandidatesByTitle);
      bulkLog(`Item index built: ${itemIndex.itemsByName.size} parent item(s). ${groupCandidatesByTitle.size} existing group title(s) known.`);

      const grouped = groupRows(bulkParsedRows);
      const preflight = preflightCheckMissingItems(grouped, itemIndex);
      renderPreflightWarning(preview, preflight);
      if (preflight.missingParents.length || preflight.missingVariants.length) {
        bulkLog(
          `Preflight: ${preflight.missingParents.length} parent item(s) + ${preflight.missingVariants.length} variant/addon row(s) not found in TMBill yet -- ते skip होतील, उरलेले normal चालतील.`,
          true
        );
      }

      writeCallCount = 0;
      const summary = await runBulkModifierImport({
        rows: bulkParsedRows,
        itemIndex,
        storeId,
        menuId,
        groupCandidatesByTitle,
        onStep: (text, isError) => bulkLog(text, isError),
        onProgress: (done, total) => {
          progress.textContent = `Processing group ${done}/${total}...`;
        },
      });
      bulkLastSummary = summary;
      progress.textContent = "Done.";

      const resultsHeading = document.createElement("p");
      resultsHeading.textContent = "Run results:";
      summaryEl.appendChild(resultsHeading);
      const lines = [
        `Groups created: ${summary.groupsCreated}`,
        `Groups reused: ${summary.groupsReused}`,
        `Groups failed: ${summary.groupsFailed}`,
        `Groups associated: ${summary.groupsMapped}`,
        `Modifiers created: ${summary.modifiersCreated}`,
        `Modifiers skipped (already existed): ${summary.modifiersDuplicateSkipped}`,
        `Modifiers failed: ${summary.modifiersFailed}`,
        `Total row failures: ${summary.failures.length}`,
      ];
      for (const line of lines) {
        const li = document.createElement("li");
        li.textContent = line;
        summaryEl.appendChild(li);
      }
      downloadBtn.hidden = false;
      bulkLog(`Import finished. ${summary.successes.length} row(s) succeeded, ${summary.failures.length} row(s) failed.`);
    } catch (e) {
      bulkLog(`Import aborted: ${e.message}`, true);
      progress.textContent = "Aborted.";
    } finally {
      runBtn.disabled = false;
      parseBtn.disabled = false;
    }
  });

  downloadBtn.addEventListener("click", () => {
    if (!bulkLastSummary) return;
    const successRows = bulkLastSummary.successes.map((r) => ({
      "Row Number": r.rowNumber,
      "Item Name": r.itemName,
      "Modifier Group": r.modifierGroup,
      "Modifier Name": r.modifierName,
      SKU: r.sku,
      "Group ID": r.groupId,
      "Modifier ID": r.modifierId,
      Stage: r.stageReached,
    }));
    const failureRows = bulkLastSummary.failures.map((r) => ({
      "Row Number": r.rowNumber,
      "Item Name": r.itemName,
      "Modifier Group": r.modifierGroup,
      "Modifier Name": r.modifierName,
      SKU: r.sku,
      Stage: r.stageReached,
      Error: r.error,
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(successRows), "success_report");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(failureRows), "failed_records");
    XLSX.writeFile(wb, `tmbill_bulk_modifiers_result_${Date.now()}.xlsx`);
  });
}

;
// Uses $, log, sendMsg, fillSelect, displayName from popup.js and
// renderDeletableList/currentContext from modifiers.js (same page/scope).

let ogTemplate = null; // last-fetched {SubOptions, NotInSubOptions, menu_items}
let ogPoolItems = []; // last-fetched outlet-menu-child items (suboption pool)
const ogSelectedIds = new Set();

$("og-fetch-btn").addEventListener("click", async () => {
  const { storeId } = currentContext();
  if (!storeId) return log("Pick an outlet first.", true);
  $("og-fetch-btn").disabled = true;
  try {
    const res = await sendMsg("OG_LIST", { storeId });
    log(`Fetched ${res.groups.length} option group(s).`);
    renderDeletableList(
      $("og-list"),
      res.groups,
      (g) => `${g.title || g.name} (#${g.id})`,
      async (g, li) => {
        try {
          await sendMsg("OG_DELETE", { groupId: g.id });
          log(`Deleted option group #${g.id}.`);
          li.remove();
        } catch (e) {
          log(e.message, true);
        }
      }
    );
  } catch (e) {
    log(e.message, true);
  } finally {
    $("og-fetch-btn").disabled = false;
  }
});

function renderSuboptionPool() {
  const ul = $("og-suboption-pool");
  ul.innerHTML = "";
  if (!ogPoolItems.length) {
    const li = document.createElement("li");
    li.textContent = "Load menu items first.";
    ul.appendChild(li);
    return;
  }
  for (const item of ogPoolItems) {
    const li = document.createElement("li");
    li.className = "pool-item" + (ogSelectedIds.has(item.item_id) ? " selected" : "");
    const priceLabel = item.sale_price !== undefined ? ` -- ${item.sale_price}` : "";
    li.textContent = `${item.title || item.name}${priceLabel}`;
    li.addEventListener("click", () => {
      if (ogSelectedIds.has(item.item_id)) ogSelectedIds.delete(item.item_id);
      else ogSelectedIds.add(item.item_id);
      renderSuboptionPool();
    });
    ul.appendChild(li);
  }
}

$("og-load-btn").addEventListener("click", async () => {
  const { storeId, menuId } = currentContext();
  if (!storeId || !menuId) return log("Pick an outlet and menu first.", true);
  $("og-load-btn").disabled = true;
  try {
    const [templateRes, childRes] = await Promise.all([
      sendMsg("OG_TEMPLATE", { storeId, menuId }),
      sendMsg("OG_MENU_CHILD", { menuId }),
    ]);
    ogTemplate = templateRes.template || {};
    ogPoolItems = childRes.items || [];
    ogSelectedIds.clear();

    const menuItems = ogTemplate.menu_items || [];
    fillSelect($("og-parent-item"), menuItems, "item_id", (i) => i.title || i.name || `Item #${i.item_id}`, "-- load items first --");
    renderSuboptionPool();
    log(`Loaded ${menuItems.length} menu item(s) and ${ogPoolItems.length} option-pool item(s).`);
  } catch (e) {
    log(e.message, true);
  } finally {
    $("og-load-btn").disabled = false;
  }
});

$("og-create-btn").addEventListener("click", async () => {
  const { storeId, menuId } = currentContext();
  const parentItemId = $("og-parent-item").value;
  const title = $("og-title").value.trim();
  if (!storeId || !menuId) return log("Pick an outlet and menu first.", true);
  if (!parentItemId || !title) return log("Applies-to item and title are required.", true);
  if (!ogSelectedIds.size) return log("Pick at least one sub-option item.", true);

  const subOptions = ogPoolItems
    .filter((item) => ogSelectedIds.has(item.item_id))
    .map((item, idx) => ({
      id: `tmp_${Date.now()}_${idx}`,
      title: item.title || item.name,
      price: item.sale_price ?? 0,
      description: null,
      item_id: item.item_id,
      available: 1,
      is_active: 1,
      short_code: item.item_info?.short_code || item.short_code || "",
      tmpos_id: "",
      isModified: 1,
    }));

  // Payload shape matches option_group.py's build_payload() exactly --
  // NotInSubOptions must be echoed back unchanged from the template fetch.
  const payload = {
    id: null,
    title,
    store_id: storeId,
    description: "",
    min_selectable: String($("og-min").value || 0),
    max_selectable: String($("og-max").value || 1),
    is_addon: String($("og-is-addon").value),
    active: String($("og-status").value),
    item_ref_ids: "",
    a: [],
    b: [],
    NotInSubOptions: (ogTemplate && ogTemplate.NotInSubOptions) || [],
    SubOptions: subOptions,
    sorting: Number($("og-sort").value || 1),
    menu_id: Number(menuId),
    selectedItem: [],
    SaleItems: [],
    applicable_on_item: [Number(parentItemId)],
  };

  $("og-create-btn").disabled = true;
  try {
    await sendMsg("OG_CREATE", { payload });
    log(`Created option group "${title}" with ${subOptions.length} sub-option(s).`);
    $("og-fetch-btn").click();
  } catch (e) {
    log(e.message, true);
  } finally {
    $("og-create-btn").disabled = false;
  }
});

;
/**
 * bulk_optiongroups.js -- Excel-driven bulk creation of Option Groups,
 * ported from the desktop suite's option_group.py / option_group_main.py.
 *
 * Key difference from Modifier Groups: an Option Group's create payload is
 * fully self-contained (SubOptions + applicable_on_item embedded directly)
 * -- there's no separate "associate" call. Duplicate detection is by exact
 * (title, menu_id) match against every existing option group store-wide
 * (skip, don't recreate -- no confirmed update payload shape exists).
 */

const OG_COLUMN_ALIASES = {
  item_name: ["item name", "item", "menu item", "item_name", "item title"],
  option_group: ["option group", "option_group", "group", "group title", "group name"],
  option_name: ["option name", "option_name", "modifier name", "sub option", "suboption", "title"],
  price: ["price", "amount", "rate"],
  short_code: ["short code", "short_code", "shortcode", "code"],
  min_selectable: ["min selectable", "min_selectable", "group min", "min"],
  max_selectable: ["max selectable", "max_selectable", "group max", "max"],
  is_addon: ["is addon", "is_addon", "addon"],
  status: ["status", "active"],
  sort_rank: ["sort rank", "sorting", "rank"],
};

function ogNormHeader(h) {
  return String(h).trim().toLowerCase().replace(/_/g, " ").replace(/\s+/g, " ").trim();
}
function ogBuildColumnMap(columns) {
  const normToActual = {};
  for (const c of columns) normToActual[ogNormHeader(c)] = c;
  const resolved = {};
  for (const [canonical, aliases] of Object.entries(OG_COLUMN_ALIASES)) {
    for (const alias of aliases) {
      if (alias in normToActual) {
        resolved[canonical] = normToActual[alias];
        break;
      }
    }
  }
  return resolved;
}

function ogReadRows(rawRows, columns) {
  const colmap = ogBuildColumnMap(columns);
  const missing = ["option_group", "option_name", "price", "short_code"].filter((f) => !(f in colmap));
  if (missing.length) {
    throw new Error(`Input Excel is missing required column(s): ${missing.join(", ")}. Found columns: ${columns.join(", ")}`);
  }

  const validRows = [];
  const validationErrors = [];
  let skippedBlank = 0;
  const rankCounters = new Map();

  rawRows.forEach((raw, idx) => {
    const excelRowNumber = idx + 2;
    const get = (field) => (colmap[field] !== undefined ? raw[colmap[field]] : undefined);

    const blank = ["item_name", "option_group", "option_name"].every((f) => isBlank(get(f)));
    if (blank) {
      skippedBlank++;
      return;
    }

    try {
      const itemName = toStr(get("item_name"));
      if (!itemName) throw new Error(`Row ${excelRowNumber}: 'Item Name' is required but blank.`);
      const optionGroup = toStr(get("option_group"));
      if (!optionGroup) throw new Error(`Row ${excelRowNumber}: 'Option Group' is required but blank.`);
      const optionName = toStr(get("option_name"));
      if (!optionName) throw new Error(`Row ${excelRowNumber}: 'Option Name' is required but blank.`);

      const price = toFloat(get("price"), "Price", excelRowNumber);

      const shortCode = toStr(get("short_code"));
      if (!shortCode) {
        throw new Error(
          `Row ${excelRowNumber}: 'Short Code' is required but blank -- titles like 'Small'/'Medium' ` +
            `repeat across many different dishes, so Short Code is the only safe way to identify the exact item.`
        );
      }

      const minSelectable = toInt(get("min_selectable"), "Min Selectable", excelRowNumber, 0);
      const maxSelectable = toInt(get("max_selectable"), "Max Selectable", excelRowNumber, 1);
      const isAddon = toInt(get("is_addon"), "Is Addon", excelRowNumber, 0);
      const status = normalizeStatus(get("status"), excelRowNumber, 1);

      const rankKey = `${itemName.toLowerCase()}\u0001${optionGroup.toLowerCase()}`;
      const autoRank = (rankCounters.get(rankKey) || 0) + 1;
      rankCounters.set(rankKey, autoRank);
      const sortRank = toInt(get("sort_rank"), "Sort Rank", excelRowNumber, autoRank);

      validRows.push({
        rowNumber: excelRowNumber,
        itemName,
        optionGroup,
        optionName,
        price,
        shortCode,
        minSelectable,
        maxSelectable,
        isAddon,
        status,
        sortRank,
        error: null,
        stageReached: null,
      });
    } catch (e) {
      validationErrors.push([excelRowNumber, e.message]);
    }
  });

  return { validRows, validationErrors, skippedBlank };
}

function ogGroupRows(rows) {
  const grouped = new Map();
  for (const row of rows) {
    const key = `${row.itemName.trim().toLowerCase()}\u0001${row.optionGroup.trim().toLowerCase()}`;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  }
  return grouped;
}

// ---- Item index (mirrors option_group.py's OptionGroupItemIndex) ----
function buildOptionGroupItemIndex(menuId, templateRaw, menuChildRaw) {
  const parentsByName = new Map();
  const parentsByShortCode = new Map();
  const suboptionsByShortCode = new Map();
  const suboptionsByTitle = new Map();

  const notInSubOptions = (templateRaw && templateRaw.NotInSubOptions) || [];

  for (const entry of (templateRaw && templateRaw.menu_items) || []) {
    const itemId = Number(entry && entry.item_id);
    if (Number.isNaN(itemId)) continue;
    const title = String((entry && entry.title) || "");
    const ref = { itemId, menuId, name: title, shortCode: String((entry && entry.short_code) || "") };
    if (title) parentsByName.set(title.trim().toLowerCase(), ref);
    if (entry.short_code) parentsByShortCode.set(String(entry.short_code).trim().toLowerCase(), ref);
  }

  const childResult = Array.isArray(menuChildRaw)
    ? menuChildRaw
    : menuChildRaw && Array.isArray(menuChildRaw.data)
    ? menuChildRaw.data
    : [];
  for (const entry of childResult || []) {
    const itemId = Number(entry && entry.item_id);
    if (Number.isNaN(itemId)) continue;
    const title = String((entry && entry.title) || "");
    const info = (entry && entry.item_info) || {};
    const shortCode = String(info.short_code || (entry && entry.short_code) || "");
    const price = Number((entry && entry.sale_price) || 0) || 0;
    const sub = { itemId, title, shortCode, salePrice: price };
    if (shortCode) suboptionsByShortCode.set(shortCode.trim().toLowerCase(), sub);
    if (title) {
      const key = title.trim().toLowerCase();
      if (!suboptionsByTitle.has(key)) suboptionsByTitle.set(key, []);
      suboptionsByTitle.get(key).push(sub);
    }
  }

  return {
    notInSubOptions,
    resolveParent(itemName) {
      const key = itemName.trim().toLowerCase();
      const ref = parentsByName.get(key) || parentsByShortCode.get(key);
      if (!ref) {
        if (suboptionsByTitle.has(key)) {
          throw new Error(
            `Menu item '${itemName}' was not found among PARENT items under menu_id=${menuId}, but IS a ` +
              `variant/child item. Option Groups can only attach to the PARENT dish -- put that dish's ` +
              `parent item title in 'Item Name' instead.`
          );
        }
        throw new Error(
          `Menu item '${itemName}' was not found under menu_id=${menuId} (checked against option-group/0's menu_items). ` +
            `Verify the 'Item Name' column matches an existing parent item's title or short code exactly.`
        );
      }
      return ref;
    },
    resolveSuboption(optionName, shortCode) {
      const key = shortCode.trim().toLowerCase();
      const sub = suboptionsByShortCode.get(key);
      if (sub) return sub;
      const candidates = suboptionsByTitle.get(optionName.trim().toLowerCase()) || [];
      if (candidates.length === 1) return candidates[0];
      throw new Error(
        `Suboption '${optionName}' (short_code='${shortCode}') was not found in outlet-menu-child for menu_id=${menuId}` +
          (candidates.length > 1 ? ` -- title also matches ${candidates.length} different items, too ambiguous.` : ".")
      );
    },
  };
}

/** Dry-run preflight (no API writes) -- mirrors runBulkOptionGroupImport's
 * resolveParent/resolveSuboption calls so the popup can show a clear
 * "these items/suboptions don't exist in TMBill yet" warning BEFORE the
 * run starts, instead of only surfacing it in the end-of-run failed rows.
 * TMBill has no create-item API, so items missing from the live menu must
 * be created there first (outside this extension) -- this just makes that
 * gap visible upfront. */
function ogPreflightCheckMissingItems(grouped, index) {
  const missingParents = new Set();
  const missingSuboptions = [];
  let resolvableGroups = 0;

  for (const [, groupRowsArr] of grouped) {
    const first = groupRowsArr[0];
    let item;
    try {
      item = index.resolveParent(first.itemName);
    } catch (e) {
      missingParents.add(first.itemName);
      continue;
    }
    let anyResolvable = false;
    for (const row of groupRowsArr) {
      try {
        index.resolveSuboption(row.optionName, row.shortCode);
        anyResolvable = true;
      } catch (e) {
        missingSuboptions.push({ itemName: row.itemName, optionGroup: row.optionGroup, optionName: row.optionName });
      }
    }
    if (anyResolvable) resolvableGroups++;
  }

  return { missingParents: [...missingParents], missingSuboptions, resolvableGroups };
}

function ogRenderPreflightWarning(container, preflight) {
  const total = preflight.missingParents.length + preflight.missingSuboptions.length;
  if (!total) return;

  const box = document.createElement("div");
  box.className = "err";
  const heading = document.createElement("p");
  heading.textContent =
    `⚠ ${total} item/suboption TMBill च्या live menu मध्ये सापडले नाहीत -- ` +
    `त्यांचे option group तयार होणार नाही (skip होतील). ` +
    `TMBill मध्ये create-item API नसल्यामुळे हा extension ते स्वतः तयार करू शकत नाही -- ` +
    `आधी नेहमीच्या पद्धतीने हे items तयार करा, मग हीच file परत bulk import मध्ये चालवा:`;
  box.appendChild(heading);

  if (preflight.missingParents.length) {
    const p = document.createElement("p");
    p.textContent = `Parent item सापडला नाही (${preflight.missingParents.length}):`;
    box.appendChild(p);
    const ul = document.createElement("ul");
    for (const name of preflight.missingParents.slice(0, 30)) {
      const li = document.createElement("li");
      li.textContent = name;
      ul.appendChild(li);
    }
    if (preflight.missingParents.length > 30) {
      const li = document.createElement("li");
      li.textContent = `...आणि ${preflight.missingParents.length - 30} more.`;
      ul.appendChild(li);
    }
    box.appendChild(ul);
  }

  if (preflight.missingSuboptions.length) {
    const p = document.createElement("p");
    p.textContent = `Parent सापडला, पण suboption सापडला नाही (${preflight.missingSuboptions.length}):`;
    box.appendChild(p);
    const ul = document.createElement("ul");
    for (const m of preflight.missingSuboptions.slice(0, 30)) {
      const li = document.createElement("li");
      li.textContent = `${m.itemName} -> ${m.optionName} (group: ${m.optionGroup})`;
      ul.appendChild(li);
    }
    if (preflight.missingSuboptions.length > 30) {
      const li = document.createElement("li");
      li.textContent = `...आणि ${preflight.missingSuboptions.length - 30} more.`;
      ul.appendChild(li);
    }
    box.appendChild(ul);
  }

  container.appendChild(box);
}

function ogGenTempId(len = 6) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let out = "";
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function buildOptionGroupPayload(rows, item, index, storeId) {
  const first = rows[0];
  const subOptions = rows.map((row) => {
    const sub = index.resolveSuboption(row.optionName, row.shortCode);
    return {
      id: ogGenTempId(),
      title: row.optionName,
      price: row.price,
      description: null,
      item_id: sub.itemId,
      available: 1,
      is_active: row.status,
      short_code: sub.shortCode,
      tmpos_id: "",
      isModified: 1,
    };
  });

  return {
    id: null,
    title: first.optionGroup,
    store_id: storeId,
    description: "",
    min_selectable: String(first.minSelectable),
    max_selectable: String(first.maxSelectable),
    is_addon: String(first.isAddon),
    active: String(first.status),
    item_ref_ids: "",
    a: [],
    b: [],
    NotInSubOptions: index.notInSubOptions,
    SubOptions: subOptions,
    sorting: first.sortRank,
    menu_id: item.menuId,
    selectedItem: [],
    SaleItems: [],
    applicable_on_item: [item.itemId],
  };
}

async function runBulkOptionGroupImport({ rows, index, existingTitles, storeId, menuId, onStep, onProgress }) {
  const summary = {
    groupsCreated: 0,
    groupsSkippedDuplicate: 0,
    groupsFailed: 0,
    successes: [],
    failures: [],
  };
  const grouped = ogGroupRows(rows);
  let done = 0;
  const total = grouped.size;

  for (const [, groupRowsArr] of grouped) {
    done++;
    const first = groupRowsArr[0];
    onStep(`[${done}/${total}] Option Group '${first.optionGroup}' under item '${first.itemName}' (${groupRowsArr.length} option(s))`);
    if (onProgress) onProgress(done, total);

    let item;
    try {
      item = index.resolveParent(first.itemName);
    } catch (e) {
      for (const row of groupRowsArr) {
        row.error = e.message;
        row.stageReached = "item_lookup";
        summary.failures.push(row);
      }
      summary.groupsFailed++;
      onStep(`  FAILED: ${e.message}`, true);
      continue;
    }

    const titleKey = `${first.optionGroup.trim().toLowerCase()}\u0001${item.menuId}`;
    const existingId = existingTitles.get(titleKey);
    if (existingId !== undefined) {
      for (const row of groupRowsArr) {
        row.groupId = existingId;
        row.itemId = item.itemId;
        row.stageReached = "skipped_duplicate";
        summary.successes.push(row);
      }
      summary.groupsSkippedDuplicate++;
      onStep(`  Option Group '${first.optionGroup}' already exists (id=${existingId}) -- skipped.`);
      continue;
    }

    let payload;
    try {
      payload = buildOptionGroupPayload(groupRowsArr, item, index, storeId);
    } catch (e) {
      for (const row of groupRowsArr) {
        row.error = e.message;
        row.stageReached = "suboption_resolve_failed";
        summary.failures.push(row);
      }
      summary.groupsFailed++;
      onStep(`  FAILED: ${e.message}`, true);
      continue;
    }

    try {
      await paceWriteCall(onStep);
      await sendMsg("OG_CREATE", { payload });
      for (const row of groupRowsArr) {
        row.itemId = item.itemId;
        row.stageReached = "created";
        summary.successes.push(row);
      }
      summary.groupsCreated++;
      onStep(`  Created Option Group '${first.optionGroup}' under item '${item.name}' (${groupRowsArr.length} option(s)).`);
    } catch (e) {
      for (const row of groupRowsArr) {
        row.error = e.message;
        row.stageReached = "group_create_failed";
        summary.failures.push(row);
      }
      summary.groupsFailed++;
      onStep(`  FAILED: group creation error: ${e.message}`, true);
    }
  }

  return summary;
}

// ---- UI wiring ----
let ogBulkParsedRows = null;
let ogBulkLastSummary = null;

function ogBulkLog(text, isError = false) {
  log(`[bulk-og] ${text}`, isError);
}

{
  const fileInput = $("bulk-og-file");
  const parseBtn = $("bulk-og-parse-btn");
  const runBtn = $("bulk-og-run-btn");
  const downloadBtn = $("bulk-og-download-btn");
  const preview = $("bulk-og-preview");
  const progress = $("bulk-og-progress");
  const summaryEl = $("bulk-og-summary");

  parseBtn.addEventListener("click", async () => {
    const file = fileInput.files[0];
    if (!file) {
      ogBulkLog("Choose an .xlsx file first.", true);
      return;
    }
    try {
      let { rows: rawRows, columns } = await readWorkbookFile(file);
      if (typeof looksLikeRawMenu === "function" && looksLikeRawMenu(columns)) {
        ogBulkLog(`'${file.name}' raw Atlantic menu export दिसतंय (Option Group column नाही) -- auto-convert करत आहे...`);
        const converted = convertRawMenuToOptionGroupRows(rawRows, columns);
        rawRows = converted.rows;
        columns = converted.columns;
        let msg = `Auto-convert पूर्ण: ${converted.groupCount} group(s), ${converted.addonCount} addon-sentence row(s) added`;
        if (converted.skippedNoVariant.length) {
          msg += `; ${converted.skippedNoVariant.length} single-price item(s) skipped (no variant, no addon sentence).`;
        } else {
          msg += ".";
        }
        ogBulkLog(msg);
      }
      const { validRows, validationErrors, skippedBlank } = ogReadRows(rawRows, columns);
      ogBulkParsedRows = validRows;
      preview.innerHTML = "";
      const summaryLine = document.createElement("p");
      summaryLine.textContent = `Parsed ${validRows.length} valid row(s), ${validationErrors.length} error(s), ${skippedBlank} blank row(s) skipped.`;
      preview.appendChild(summaryLine);
      if (validationErrors.length) {
        const ul = document.createElement("ul");
        for (const [rowNum, msg] of validationErrors.slice(0, 20)) {
          const li = document.createElement("li");
          li.className = "err";
          li.textContent = `Row ${rowNum}: ${msg}`;
          ul.appendChild(li);
        }
        if (validationErrors.length > 20) {
          const li = document.createElement("li");
          li.textContent = `...and ${validationErrors.length - 20} more.`;
          ul.appendChild(li);
        }
        preview.appendChild(ul);
      }
      const groups = ogGroupRows(validRows);
      const groupsLine = document.createElement("p");
      groupsLine.textContent = `Option Groups by (Item, Group): ${groups.size}`;
      preview.appendChild(groupsLine);
      runBtn.disabled = validRows.length === 0;
      downloadBtn.hidden = true;
      ogBulkLog(`Parsed '${file.name}': ${validRows.length} valid row(s) across ${groups.size} group(s).`);
    } catch (e) {
      ogBulkLog(e.message, true);
      runBtn.disabled = true;
    }
  });

  runBtn.addEventListener("click", async () => {
    if (!ogBulkParsedRows || !ogBulkParsedRows.length) return;
    const stateRes = await sendMsg("GET_STATE");
    const storeId = stateRes.state.storeId;
    const menuId = stateRes.state.menuId;
    if (!storeId || !menuId) {
      ogBulkLog("Select an Outlet and Menu at the top of the popup first.", true);
      return;
    }
    if (!confirmBulkRunContext(stateRes)) {
      ogBulkLog("Import cancelled -- account/outlet/menu not confirmed.", true);
      return;
    }

    runBtn.disabled = true;
    parseBtn.disabled = true;
    progress.textContent = "Loading option-group context and existing groups...";
    summaryEl.innerHTML = "";

    try {
      const [templateRes, childRes, allGroupsRes] = await Promise.all([
        sendMsg("OG_TEMPLATE", { storeId, menuId }),
        sendMsg("OG_MENU_CHILD", { menuId }),
        sendMsg("OG_LIST_ALL", { storeId }),
      ]);
      const index = buildOptionGroupItemIndex(menuId, templateRes.template, childRes.items);

      const existingTitles = new Map();
      for (const g of allGroupsRes.groups || []) {
        const t = g && g.title;
        const mid = g && g.menu_id;
        if (t !== undefined && t !== null && mid !== undefined && mid !== null) {
          existingTitles.set(`${String(t).trim().toLowerCase()}\u0001${Number(mid)}`, g.id);
        }
      }
      ogBulkLog(`Item index built. ${existingTitles.size} existing option group(s) known store-wide.`);

      const ogGrouped = ogGroupRows(ogBulkParsedRows);
      const ogPreflight = ogPreflightCheckMissingItems(ogGrouped, index);
      ogRenderPreflightWarning(preview, ogPreflight);
      if (ogPreflight.missingParents.length || ogPreflight.missingSuboptions.length) {
        ogBulkLog(
          `Preflight: ${ogPreflight.missingParents.length} parent item(s) + ${ogPreflight.missingSuboptions.length} suboption row(s) not found in TMBill yet -- ते skip होतील, उरलेले normal चालतील.`,
          true
        );
      }

      writeCallCount = 0;
      const summary = await runBulkOptionGroupImport({
        rows: ogBulkParsedRows,
        index,
        existingTitles,
        storeId,
        menuId,
        onStep: (text, isError) => ogBulkLog(text, isError),
        onProgress: (done, total) => {
          progress.textContent = `Processing group ${done}/${total}...`;
        },
      });
      ogBulkLastSummary = summary;
      progress.textContent = "Done.";

      const ogResultsHeading = document.createElement("p");
      ogResultsHeading.textContent = "Run results:";
      summaryEl.appendChild(ogResultsHeading);
      const lines = [
        `Groups created: ${summary.groupsCreated}`,
        `Groups skipped (already existed): ${summary.groupsSkippedDuplicate}`,
        `Groups failed: ${summary.groupsFailed}`,
        `Total row failures: ${summary.failures.length}`,
      ];
      for (const line of lines) {
        const li = document.createElement("li");
        li.textContent = line;
        summaryEl.appendChild(li);
      }
      downloadBtn.hidden = false;
      ogBulkLog(`Import finished. ${summary.successes.length} row(s) succeeded, ${summary.failures.length} row(s) failed.`);
    } catch (e) {
      ogBulkLog(`Import aborted: ${e.message}`, true);
      progress.textContent = "Aborted.";
    } finally {
      runBtn.disabled = false;
      parseBtn.disabled = false;
    }
  });

  downloadBtn.addEventListener("click", () => {
    if (!ogBulkLastSummary) return;
    const successRows = ogBulkLastSummary.successes.map((r) => ({
      "Row Number": r.rowNumber,
      "Item Name": r.itemName,
      "Option Group": r.optionGroup,
      "Option Name": r.optionName,
      "Short Code": r.shortCode,
      "Group ID": r.groupId,
      Stage: r.stageReached,
    }));
    const failureRows = ogBulkLastSummary.failures.map((r) => ({
      "Row Number": r.rowNumber,
      "Item Name": r.itemName,
      "Option Group": r.optionGroup,
      "Option Name": r.optionName,
      "Short Code": r.shortCode,
      Stage: r.stageReached,
      Error: r.error,
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(successRows), "option_group_success_report");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(failureRows), "option_group_failed_records");
    XLSX.writeFile(wb, `tmbill_bulk_option_groups_result_${Date.now()}.xlsx`);
  });
}

// Tell the main panel which Back Office outlet is selected (shown top-left)
$("outlet-select").addEventListener("change", () => {
  const s = $("outlet-select");
  const name = s.value && s.selectedIndex >= 0 ? s.options[s.selectedIndex].textContent.replace(/\s*\(\d+\)\s*$/, "") : "";
  window.dispatchEvent(new CustomEvent("tmbill-bo", { detail: { name } }));
});
window.__tmbillSuiteReady = true;

})();
