// Modifier Suite backend (merged from the TMBill Modifier Suite extension). Isolated in its own scope; answers only {type:...} messages.
(function () {
/**
 * background.js -- TMBill Automation Suite (browser extension MVP)
 *
 * Reimplements core/auth.py's TMBillAuth in JavaScript:
 *   1. GET {base_url}/login  -> scrape a CSRF token (hidden _token input,
 *      csrf-token meta tag, or XSRF-TOKEN cookie, in that fallback order).
 *   2. POST credentials (application/x-www-form-urlencoded) to the same
 *      URL. Laravel responds with a 302 -> fetch() follows it automatically.
 *      Landing back on /login means the login was rejected.
 *   3. Read the fresh XSRF-TOKEN cookie the server just set.
 *   4. GET an authenticated page (/admin/master-catalogue, falling back to
 *      /admin/dashboard) and scrape ITS csrf-token meta tag -- Laravel
 *      regenerates this on login, so the pre-login token is stale.
 *   5. Store both tokens; every subsequent request sends them as
 *      X-XSRF-TOKEN / X-CSRF-TOKEN headers, same as the Python suite.
 *
 * Session cookies themselves are handled by the browser's own cookie jar
 * (fetch with credentials:"include") -- no manual cookie plumbing needed,
 * unlike the Python `requests.Session`.
 */

const HIDDEN_TOKEN_RE =
  /<input[^>]*name=["']_token["'][^>]*value=["']([^"']+)["']|<input[^>]*value=["']([^"']+)["'][^>]*name=["']_token["']/i;
const META_CSRF_RE = /<meta[^>]*name=["']csrf-token["'][^>]*content=["']([^"']+)["']/i;
const LOGIN_ERROR_RE =
  /<(?:span|div)[^>]*class=["'][^"']*(?:invalid-feedback|alert-danger|error)[^"']*["'][^>]*>\s*(?:<strong>)?\s*([^<]{3,200}?)\s*(?:<\/strong>)?\s*<\/(?:span|div)>/i;

// 429 ("Too Many Attempts") is the server's own rate limiter, not a real
// failure -- retried with backoff instead of surfaced immediately. Shared
// by both the pre-login page fetches (login GET/POST, post-login csrf
// fetch) and apiRequest()'s post-login calls below, so a login attempt
// that happens to land during a throttle window recovers on its own
// instead of failing hard with a raw 429 HTML page.
const RETRY_429 = { maxAttempts: 5, baseDelayMs: 3000 };
function retrySleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
/** fetch() wrapper that retries on HTTP 429 with backoff (3s, 6s, 9s, 12s).
 * Every other status/network error is returned/thrown as-is on first try --
 * only 429 is treated as transient. `onStep` (optional) gets a progress
 * line on each retry so it's visible in the popup log instead of a silent
 * multi-second pause. */
async function fetchRetry429(url, opts, onStep, label) {
  for (let attempt = 1; attempt <= RETRY_429.maxAttempts; attempt++) {
    let resp;
    try {
      resp = await fetch(url, opts);
    } catch (e) {
      throw new Error(`${label || url} failed: ${e.message}`);
    }
    if (resp.status === 429) {
      if (attempt === RETRY_429.maxAttempts) {
        return resp; // let the caller surface the final 429 with its own error text/format
      }
      const delay = RETRY_429.baseDelayMs * attempt;
      if (onStep) {
        onStep(`Rate limited (429) on ${label || url} -- retrying in ${delay / 1000}s (attempt ${attempt}/${RETRY_429.maxAttempts})...`);
      }
      await retrySleep(delay);
      continue;
    }
    return resp;
  }
}


// In-memory session state. Cleared on service-worker restart (MV3 workers
// are short-lived) -- persisted mirror lives in chrome.storage.session so a
// popup reopened seconds later doesn't force a re-login for no reason.
let state = {
  baseUrl: null,
  authenticated: false,
  xsrfToken: null,
  csrfToken: null,
  username: null,
  storeId: null,
  menuId: null,
};

async function restoreState() {
  const saved = await chrome.storage.session.get("tmbillState");
  if (saved.tmbillState) state = saved.tmbillState;
}
async function persistState() {
  await chrome.storage.session.set({ tmbillState: state });
}
restoreState();

function decodeXsrf(raw) {
  try {
    return decodeURIComponent(raw);
  } catch {
    return raw;
  }
}

async function getCookie(url, name) {
  const cookie = await chrome.cookies.get({ url, name });
  return cookie ? cookie.value : null;
}

async function clearDomainCookies(baseUrl) {
  // CRITICAL: without this, a login POST with FRESH credentials can be a
  // no-op -- if the browser already holds a valid session cookie for this
  // domain (from an earlier extension login, or a normal logged-in tab on
  // the TMBill site itself), Laravel's guest-only /login route typically
  // redirects an already-authenticated session straight past the login
  // form instead of processing the new credentials, so the server keeps
  // using WHOEVER was already logged in via that cookie -- not the
  // username/password just typed into the popup. Confirmed as the cause
  // of a real run showing the wrong (previous) account/outlet after
  // "logging in" with different credentials. Clearing every cookie for
  // the domain first forces the server to treat the next request as a
  // true guest, so the POST actually authenticates the NEW credentials.
  let url;
  try {
    url = new URL(baseUrl).origin;
  } catch {
    url = baseUrl;
  }
  const cookies = await chrome.cookies.getAll({ url });
  await Promise.all(
    cookies.map((c) =>
      chrome.cookies.remove({
        url: (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path,
        name: c.name,
      })
    )
  );
}

async function primeLoginPage(loginUrl, onStep) {
  onStep("Loading login page...");
  let resp;
  try {
    resp = await fetchRetry429(loginUrl, { credentials: "include" }, onStep, `GET ${loginUrl}`);
  } catch (e) {
    throw new Error(`Could not reach ${loginUrl}: ${e.message}`);
  }
  const html = await resp.text();

  const hidden = HIDDEN_TOKEN_RE.exec(html);
  if (hidden) return hidden[1] || hidden[2];

  const meta = META_CSRF_RE.exec(html);
  if (meta) return meta[1];

  const cookieToken = await getCookie(loginUrl, "XSRF-TOKEN");
  if (cookieToken) return decodeXsrf(cookieToken);

  throw new Error(
    `Could not find a usable CSRF token (hidden '_token' input, csrf-token meta tag, ` +
      `or XSRF-TOKEN cookie) on ${loginUrl}. The login page markup may have changed, ` +
      `or the site is showing a bot-challenge/maintenance page.`
  );
}

async function fetchPostLoginCsrfToken(baseUrl, onStep) {
  for (const path of ["/admin/master-catalogue", "/admin/dashboard"]) {
    try {
      const resp = await fetchRetry429(baseUrl + path, { credentials: "include" }, onStep, `GET ${baseUrl + path}`);
      const html = await resp.text();
      const meta = META_CSRF_RE.exec(html);
      if (meta) return meta[1];
    } catch {
      // try the next candidate path
    }
  }
  return null;
}


async function connectExistingBackoffice({ baseUrl = "https://backoffice.tmbill.com" } = {}, onStep = () => {}) {
  baseUrl = baseUrl.replace(/\/+$/, "");
  onStep("Checking your existing TMBill Backoffice session...");

  let resp;
  try {
    // An authenticated Backoffice tab uses the same browser cookie jar.
    // If the user is already logged in, this request lands on an admin page;
    // otherwise TMBill redirects it to /login.
    resp = await fetchRetry429(
      `${baseUrl}/admin/dashboard`,
      { credentials: "include", redirect: "follow" },
      onStep,
      `GET ${baseUrl}/admin/dashboard`
    );
  } catch (e) {
    throw new Error(`Could not connect to TMBill Backoffice: ${e.message}`);
  }

  const finalUrl = (resp.url || "").replace(/\/+$/, "");
  const html = await resp.text();

  if (finalUrl.endsWith("/login") || HIDDEN_TOKEN_RE.test(html) && /name=["']email["']/i.test(html)) {
    state = {
      ...state,
      baseUrl,
      authenticated: false,
      xsrfToken: null,
      csrfToken: null,
      username: null,
    };
    await persistState();
    throw new Error("TMBill Backoffice is not logged in. Please log in to Backoffice first, then click Retry.");
  }

  const xsrfRaw = await getCookie(baseUrl, "XSRF-TOKEN");
  if (!xsrfRaw) {
    throw new Error("Backoffice session was found, but its XSRF-TOKEN cookie is missing. Refresh Backoffice and try again.");
  }

  const meta = META_CSRF_RE.exec(html);
  const csrfToken = meta ? meta[1] : await fetchPostLoginCsrfToken(baseUrl, onStep);

  state = {
    ...state,
    baseUrl,
    authenticated: true,
    xsrfToken: decodeXsrf(xsrfRaw),
    csrfToken: csrfToken || null,
    username: "Backoffice session",
  };
  await persistState();

  onStep("Backoffice session detected. Fetching outlets...");
  const outlets = await fetchOutlets();

  // If this account has only one outlet, select it automatically.
  // If several are available, preserve the user's previous selection when valid.
  if (state.storeId && outlets.some((o) => String(o.store_id ?? o.id) === String(state.storeId))) {
    // keep existing outlet
  } else if (outlets.length === 1) {
    state.storeId = outlets[0].store_id ?? outlets[0].id ?? null;
    state.menuId = null;
    await persistState();
    onStep(`Outlet selected automatically: ${outlets[0].name || outlets[0].store_name || outlets[0].outlet_name || state.storeId}`);
  } else {
    state.storeId = null;
    state.menuId = null;
    await persistState();
  }

  onStep(`Connected successfully. ${outlets.length} outlet(s) available.`);
  return { state, outlets };
}

async function login({ baseUrl, username, password }, onStep) {
  baseUrl = baseUrl.replace(/\/+$/, "");
  const loginUrl = `${baseUrl}/login`;

  onStep("Clearing any existing session for this site (so the new credentials actually take effect)...");
  try {
    await clearDomainCookies(baseUrl);
  } catch (e) {
    onStep(`Warning: could not clear old cookies (${e.message}); continuing anyway.`);
  }

  const csrfField = await primeLoginPage(loginUrl, onStep);
  onStep("Login page loaded, token found. Submitting credentials...");

  const body = new URLSearchParams({
    _token: csrfField,
    lat: "",
    lng: "",
    location: "",
    user_type: "admin",
    email: username,
    password: password,
  });

  let resp;
  try {
    resp = await fetchRetry429(
      loginUrl,
      {
        method: "POST",
        credentials: "include",
        redirect: "follow",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
          Referer: loginUrl,
        },
        body: body.toString(),
      },
      onStep,
      `POST ${loginUrl}`
    );
  } catch (e) {
    throw new Error(`Login request to ${loginUrl} failed: ${e.message}`);
  }

  if (resp.status >= 400) {
    const text = (await resp.text()).slice(0, 500);
    throw new Error(`Login failed with status ${resp.status}: ${text}`);
  }

  if (resp.url.replace(/\/+$/, "").endsWith("/login")) {
    const text = await resp.text();
    const match = LOGIN_ERROR_RE.exec(text);
    if (match) {
      throw new Error(
        `Login rejected by the server: "${match[1].trim()}" (logged in as ${username}, user_type=admin).`
      );
    }
    throw new Error(
      "Login POST did not redirect away from the login page, but no specific error " +
        "could be found -- credentials, user_type, or the token were likely rejected. " +
        "Double-check the email/password, and that this account has Owner Panel / " +
        "Back Office access rather than only POS Front Office access."
    );
  }

  const xsrfRaw = await getCookie(baseUrl, "XSRF-TOKEN");
  if (!xsrfRaw) {
    throw new Error("Login succeeded but no XSRF-TOKEN cookie was set by the server.");
  }
  const xsrfToken = decodeXsrf(xsrfRaw);
  onStep("Credentials accepted. Fetching post-login security token...");

  const csrfToken = await fetchPostLoginCsrfToken(baseUrl, onStep);
  onStep("Login complete.");
  if (!csrfToken) {
    onStep(
      "Warning: no csrf-token meta tag found post-login; mutating requests may silently no-op."
    );
  }

  state = {
    baseUrl,
    authenticated: true,
    xsrfToken,
    csrfToken,
    username,
  };
  await persistState();
  return state;
}

function authHeaders() {
  const headers = {
    Accept: "application/json, text/plain, */*",
    "X-Requested-With": "XMLHttpRequest",
    "X-XSRF-TOKEN": state.xsrfToken,
  };
  if (state.csrfToken) headers["X-CSRF-TOKEN"] = state.csrfToken;
  return headers;
}

/**
 * Generic authenticated request. `method` is GET/POST/DELETE. `query` is an
 * object appended as a query string; `jsonBody` is sent as a JSON body for
 * POST (TMBill's admin API is JSON-in for every "create"/"list" POST route,
 * confirmed via api_client.py's self.post()). Non-JSON success bodies
 * (several DELETE/create routes return a bare "1" or empty 200) are
 * returned as raw text.
 */
function apiSleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// 429 ("Too Many Attempts") is transient -- the server's own rate limiter,
// not a real failure -- so it gets retried with backoff instead of being
// surfaced immediately. Every other non-2xx status (401/404/422/500...) is
// a real error and is thrown straight away, same as before. Uses the same
// RETRY_429 config as the pre-login fetches above (fetchRetry429).

async function apiRequest(method, path, { query, jsonBody, onStep } = {}) {
  if (!state.authenticated) throw new Error("Not logged in.");
  let url = state.baseUrl + path;
  if (query) {
    const qs = new URLSearchParams(
      Object.fromEntries(Object.entries(query).filter(([, v]) => v !== undefined && v !== null))
    ).toString();
    if (qs) url += (url.includes("?") ? "&" : "?") + qs;
  }

  for (let attempt = 1; attempt <= RETRY_429.maxAttempts; attempt++) {
    const headers = { ...authHeaders() };
    const opts = { method, credentials: "include", headers };
    if (jsonBody !== undefined) {
      headers["Content-Type"] = "application/json;charset=UTF-8";
      opts.body = JSON.stringify(jsonBody);
    }
    const resp = await fetch(url, opts);
    const text = await resp.text();

    if (resp.status === 429) {
      if (attempt === RETRY_429.maxAttempts) {
        throw new Error(`${method} ${path} failed with status 429: ${text.slice(0, 300)} (gave up after ${attempt} attempts)`);
      }
      const delay = RETRY_429.baseDelayMs * attempt; // 3s, 6s, 9s, 12s
      if (onStep) onStep(`Rate limited (429) on ${method} ${path} -- retrying in ${delay / 1000}s (attempt ${attempt}/${RETRY_429.maxAttempts})...`);
      await apiSleep(delay);
      continue;
    }

    if (!resp.ok) {
      throw new Error(`${method} ${path} failed with status ${resp.status}: ${text.slice(0, 300)}`);
    }
    try {
      return text ? JSON.parse(text) : {};
    } catch {
      return { raw: text };
    }
  }
}

function asList(body) {
  if (Array.isArray(body)) return body;
  const result = body && body.result !== undefined ? body.result : body;
  if (Array.isArray(result)) return result;
  if (result && Array.isArray(result.data)) return result.data;
  return [];
}

async function fetchOutlets() {
  const body = await apiRequest("GET", "/api/admin/outlets");
  return asList(body);
}

async function fetchOutletMenus(storeId) {
  const body = await apiRequest("GET", "/api/admin/outlet-menu", { query: { all: 1, outlet_id: storeId } });
  return asList(body);
}

async function fetchOutletMenuList(menuId) {
  // GET /api/admin/outlet-menu-list/{menu_id} -- parent items in this menu,
  // used as the picker source for a modifier group's/option's "gid"/
  // "applicable_on_item" (parent item id).
  const body = await apiRequest("GET", `/api/admin/outlet-menu-list/${menuId}`);
  return asList(body);
}

// ---- Modifier Groups & Modifiers (api_client.py's create_modifier_group /
// create_modifier, same payload shapes as modifier_group.py / modifier.py's
// build_payload) ------------------------------------------------------

async function fetchModifierGroupList(storeId, menuId) {
  const body = await apiRequest("POST", "/api/admin/modifier-group-list", {
    jsonBody: { market_id: "", brand_id: "", store_id: storeId, menu_id: menuId ?? "", type: "all", page: 1, q: "" },
  });
  return asList(body);
}

async function createModifierGroup(payload, onStep) {
  return apiRequest("POST", "/api/admin/modifier-group", { jsonBody: payload, onStep });
}

async function deleteModifierGroup(groupId) {
  return apiRequest("DELETE", `/api/admin/modifier-group/${groupId}`);
}

async function fetchModifiersList(groupId) {
  const body = await apiRequest("POST", `/api/admin/modifiers-list/${groupId}`, {
    jsonBody: { page: 1, q: "" },
  });
  return asList(body);
}

async function createModifier(payload, onStep) {
  return apiRequest("POST", "/api/admin/modifier", { jsonBody: payload, onStep });
}

async function deleteModifier(modifierId) {
  return apiRequest("DELETE", `/api/admin/modifier/${modifierId}`);
}

async function fetchModifierMapping(groupId, storeId) {
  // POST /api/admin/modifiers-item-mapping/{group_id} -> existing item
  // mappings for a group (GET is not supported on this route -- confirmed
  // in api_client.py's fetch_modifier_mapping).
  return apiRequest("POST", `/api/admin/modifiers-item-mapping/${groupId}`, {
    jsonBody: { store_id: storeId },
  });
}

async function mapModifierItems(payload, onStep) {
  // POST /api/admin/modifiers-item-mapping (group_id travels in the body).
  return apiRequest("POST", "/api/admin/modifiers-item-mapping", { jsonBody: payload, onStep });
}

// ---- Option Groups (api_client.py's create_option_group, same payload
// shape as option_group.py's build_payload) ----------------------------

async function fetchOptionGroups(storeId) {
  const body = await apiRequest("GET", "/api/admin/option-group", { query: { page: 1, q: "", outlet_id: storeId } });
  return asList(body);
}

async function fetchAllOptionGroups(storeId) {
  // Paginates GET /api/admin/option-group -- confirmed shape
  // {"result": {"data": [...], "last_page": N, ...}} (mirrors
  // api_client.py's fetch_all_option_groups). Used for store-wide
  // title+menu_id duplicate detection before creating a group.
  const all = [];
  let page = 1;
  while (true) {
    const body = await apiRequest("GET", "/api/admin/option-group", { query: { page, q: "", outlet_id: storeId } });
    const result = body && body.result !== undefined ? body.result : body;
    const data = result && Array.isArray(result.data) ? result.data : [];
    if (!data.length) break;
    all.push(...data);
    const lastPage = result && result.last_page;
    if (lastPage === undefined || lastPage === null || page >= lastPage) break;
    page++;
  }
  return all;
}

async function fetchOptionGroupTemplate(storeId, menuId) {
  // {"SubOptions": [], "NotInSubOptions": [...], "menu_items": [...]}
  return apiRequest("GET", "/api/admin/option-group/0", { query: { store_id: storeId, menu_id: menuId } });
}

async function fetchOutletMenuChild(menuId) {
  // Variant/size-item pool an option group's SubOptions are picked from.
  const body = await apiRequest("GET", `/api/admin/outlet-menu-child/${menuId}`);
  return asList(body);
}

async function createOptionGroup(payload, onStep) {
  return apiRequest("POST", "/api/admin/option-group", { jsonBody: payload, onStep });
}

async function deleteOptionGroup(groupId) {
  return apiRequest("DELETE", `/api/admin/option-group/${groupId}`);
}

async function setContext({ storeId, menuId }) {
  if (storeId !== undefined) state.storeId = storeId;
  if (menuId !== undefined) state.menuId = menuId;
  await persistState();
  return state;
}

async function logout() {
  // Do not clear Backoffice cookies. Disconnecting the extension must not log
  // the user out of the actual TMBill Backoffice session.
  state = { ...state, authenticated: false, xsrfToken: null, csrfToken: null, username: null, storeId: null, menuId: null };
  await persistState();
}

// Handlers that return a plain value under a named result key. Keeps the
// popup-side call sites uniform: chrome.runtime.sendMessage({type, payload})
// -> {ok, ...resultKey} | {ok:false, error}.
const HANDLERS = {
  FETCH_OUTLETS: { fn: () => fetchOutlets(), key: "outlets" },
  FETCH_OUTLET_MENUS: { fn: (p) => fetchOutletMenus(p.storeId), key: "menus" },
  FETCH_OUTLET_MENU_LIST: { fn: (p) => fetchOutletMenuList(p.menuId), key: "items" },
  MG_LIST: { fn: (p) => fetchModifierGroupList(p.storeId, p.menuId), key: "groups" },
  MG_CREATE: { fn: (p, onStep) => createModifierGroup(p.payload, onStep), key: "result" },
  MG_DELETE: { fn: (p) => deleteModifierGroup(p.groupId), key: "result" },
  MOD_LIST: { fn: (p) => fetchModifiersList(p.groupId), key: "modifiers" },
  MOD_CREATE: { fn: (p, onStep) => createModifier(p.payload, onStep), key: "result" },
  MOD_DELETE: { fn: (p) => deleteModifier(p.modifierId), key: "result" },
  MAPPING_FETCH: { fn: (p) => fetchModifierMapping(p.groupId, p.storeId), key: "mapping" },
  MAPPING_CREATE: { fn: (p, onStep) => mapModifierItems(p.payload, onStep), key: "result" },
  OG_LIST: { fn: (p) => fetchOptionGroups(p.storeId), key: "groups" },
  OG_LIST_ALL: { fn: (p) => fetchAllOptionGroups(p.storeId), key: "groups" },
  OG_TEMPLATE: { fn: (p) => fetchOptionGroupTemplate(p.storeId, p.menuId), key: "template" },
  OG_MENU_CHILD: { fn: (p) => fetchOutletMenuChild(p.menuId), key: "items" },
  OG_CREATE: { fn: (p, onStep) => createOptionGroup(p.payload, onStep), key: "result" },
  OG_DELETE: { fn: (p) => deleteOptionGroup(p.groupId), key: "result" },
  SET_CONTEXT: { fn: (p) => setContext(p), key: "state" },
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const onStep = (text) => chrome.runtime.sendMessage({ type: "LOG", text }).catch(() => {});

  if (msg.type === "LOGIN") {
    login(msg.payload, onStep)
      .then((s) => sendResponse({ ok: true, state: s }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true; // keep the message channel open for the async response
  }

  if (msg.type === "CONNECT_BACKOFFICE") {
    connectExistingBackoffice(msg.payload || {}, onStep)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((e) => sendResponse({ ok: false, error: e.message, state }));
    return true;
  }

  if (msg.type === "GET_STATE") {
    sendResponse({ ok: true, state });
    return false;
  }

  if (msg.type === "LOGOUT") {
    logout().then(() => sendResponse({ ok: true }));
    return true;
  }

  const handler = HANDLERS[msg.type];
  if (handler) {
    handler
      .fn(msg.payload || {}, onStep)
      .then((value) => sendResponse({ ok: true, [handler.key]: value }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

})();
