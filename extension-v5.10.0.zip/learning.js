/* Local-only, safe-mode diagnostics. Does not modify extension code or log secrets. */
(() => {
  const KEY = 'tmbill_learning_memory_v1';
  const MAX = 100;
  const SENSITIVE = /(password|passwd|token|secret|cookie|authorization|credential|email|phone|mobile|contact|username)/i;
  const safeText = (value) => String(value || '').replace(/https?:\/\/\S+/gi, '[url]').replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email]').replace(/\b(?:\+?91[-\s]?)?[6-9]\d{9}\b/g, '[phone]').replace(/(token|secret|password|cookie|authorization)\s*[:=]\s*[^\s,;]+/gi, '$1=[redacted]').slice(0, 220);
  async function readMemory() {
    try { const r = await chrome.storage.local.get(KEY); return r[KEY] || { errors: [], resolved: 0, pending: [] }; }
    catch (_) { return { errors: [], resolved: 0, pending: [] }; }
  }
  async function writeMemory(mem) { try { await chrome.storage.local.set({ [KEY]: mem }); } catch (_) {} }
  async function record(category, message, source='popup') {
    const mem = await readMemory();
    const item = { at: new Date().toISOString(), category: safeText(category), message: safeText(message), source: safeText(source), resolved: false };
    mem.errors = [item, ...(mem.errors || [])].slice(0, MAX);
    await writeMemory(mem);
    render();
  }
  window.tmbillLearning = { record };
  window.addEventListener('error', (e) => { record('javascript_error', e && e.message || 'Uncaught JavaScript error'); });
  window.addEventListener('unhandledrejection', (e) => { const r=e && e.reason; record('unhandled_rejection', r && r.message || 'Unhandled async operation failed'); });
  const modal = document.getElementById('learningModal');
  const history = document.getElementById('learnHistory');
  const esc = (s) => String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function render() {
    const mem = await readMemory(); const errors = mem.errors || [];
    const el = id => document.getElementById(id);
    if (!el('learnErrorCount')) return;
    el('learnErrorCount').textContent = errors.length;
    el('learnResolvedCount').textContent = mem.resolved || 0;
    el('learnPendingCount').textContent = (mem.pending || []).length;
    history.innerHTML = errors.length ? errors.slice(0,30).map((x,i)=>`<div style="padding:8px 2px;border-bottom:1px solid #ddd"><b>${esc(x.category)}</b> <span style="opacity:.65">${esc(new Date(x.at).toLocaleString())}</span><div>${esc(x.message)}</div><small>${esc(x.source)}</small></div>`).join('') : '<p class="hint">No errors recorded yet.</p>';
  }
  document.getElementById('learningBtn')?.addEventListener('click', async()=>{ await render(); modal.style.display='flex'; });
  document.getElementById('learningCloseBtn')?.addEventListener('click',()=>{modal.style.display='none';});
  modal?.addEventListener('click',e=>{if(e.target===modal) modal.style.display='none';});
  document.getElementById('learnExportBtn')?.addEventListener('click',async()=>{
    const mem=await readMemory(); const payload={exportedAt:new Date().toISOString(),errors:mem.errors||[],resolved:mem.resolved||0,pending:mem.pending||[]};
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='tmbill-sanitized-learning-logs.json'; a.click(); URL.revokeObjectURL(url);
  });
  document.getElementById('learnResetBtn')?.addEventListener('click',async()=>{
    if (!confirm('Delete local learning logs and reset memory on this computer?')) return;
    await writeMemory({errors:[],resolved:0,pending:[]}); await render();
  });
  // Log failed extension-message calls without capturing request payloads (which may contain credentials).
  const originalSend = window.send;
  if (typeof originalSend === 'function') {
    window.send = async function(action, data={}) {
      const result = await originalSend(action, data);
      if (result && result.ok === false) await record('extension_action_failed', `${safeText(action)}: ${safeText(result.error || 'operation failed')}`, 'extension');
      return result;
    };
  }
})();
