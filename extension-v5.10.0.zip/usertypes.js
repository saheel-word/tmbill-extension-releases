// Extra users for Full Setup (POS billing, captain, KDS, OrderHub ...). Pure functions.
//
// What is known for sure is the shape of the backoffice "create user" request
// (the owner/manager user is created with it): a designation, a numeric `type`,
// and six access flags. The presets below only PRE-FILL those flags; every
// flag stays editable per user, because how each TMBill product maps onto the
// flags is not documented here.

var USER_FLAG_DEFS = [
  { key: "web", label: "Back office (web panel)", field: "is_web_panel_permission", kind: "num" },
  { key: "terminal", label: "POS billing (terminal app)", field: "is_terminal_app", kind: "num" },
  { key: "captain", label: "Captain app", field: "is_captain_app", kind: "bool" },
  { key: "kds", label: "KDS (kitchen display)", field: "is_kds_app", kind: "bool" },
  { key: "selfOrder", label: "Self order", field: "is_self_order", kind: "bool" },
  { key: "hub", label: "OrderHub access", field: "has_hub_access", kind: "bool" },
];

var USER_TYPE_DEFAULT_ID = 17070; // the `type` value the owner/manager user is created with

var USER_TYPES = [
  { key: "pos", short: "pos", label: "POS Billing", designation: "cashier", flags: ["terminal"] },
  { key: "captain", short: "cap", label: "Captain", designation: "captain", flags: ["captain"] },
  { key: "kds", short: "kds", label: "KDS (Kitchen)", designation: "manager", flags: ["kds"] },
  { key: "hub", short: "hub", label: "OrderHub", designation: "manager", flags: ["hub"] },
  { key: "selfOrder", short: "self", label: "Self order", designation: "manager", flags: ["selfOrder"] },
  { key: "manager", short: "mgr", label: "Manager (Back office)", designation: "manager", flags: ["web"] },
  { key: "custom", short: "usr", label: "Custom (tick permissions)", designation: "manager", flags: ["terminal"] },
];

function userTypeByKey(key) {
  return USER_TYPES.find((t) => t.key === key) || USER_TYPES[USER_TYPES.length - 1];
}

// { web:0|1, terminal:0|1, ... } pre-filled for a type
function userFlagsFor(typeKey) {
  const t = userTypeByKey(typeKey);
  const flags = {};
  for (const d of USER_FLAG_DEFS) flags[d.key] = t.flags.includes(d.key) ? 1 : 0;
  return flags;
}

// spec: { username, password, name, designation, typeKey, typeId, flags, phone, email }
// ctx : { storeId, mobile, email }  (the outlet contact is used when a user has none of its own)
function userBuildPayload(spec, ctx) {
  const flags = spec.flags || userFlagsFor(spec.typeKey);
  const payload = {
    id: null,
    username: String(spec.username || "").trim(),
    store_id: ctx.storeId,
    phone: spec.phone || ctx.mobile,
    name: String(spec.name || "").trim() || String(spec.username || "").trim(),
    email: spec.email || ctx.email,
    password: spec.password,
    designation: String(spec.designation || "manager").trim() || "manager",
    type: spec.typeId || USER_TYPE_DEFAULT_ID,
    shift_time: null,
    IsActive: 1,
    photo: "",
    userCategory: 0,
  };
  // same value types the owner/manager request uses (numbers for two flags, booleans for the rest)
  for (const d of USER_FLAG_DEFS) payload[d.field] = d.kind === "num" ? (flags[d.key] ? 1 : 0) : !!flags[d.key];
  payload.is_multiple_stores = [];
  return payload;
}

// -> { errors: [...], warnings: [...] }  (strings, each names the user)
function userValidate(users, ownerUsername) {
  const errors = [];
  const warnings = [];
  const seen = new Map();
  const owner = String(ownerUsername || "").trim().toLowerCase();
  (users || []).forEach((u, i) => {
    const tag = `User ${i + 1}${u.username ? ` (${u.username})` : ""}`;
    const name = String(u.username || "").trim();
    if (!name) errors.push(`${tag}: username is empty`);
    else if (!/^[A-Za-z0-9._@-]{3,}$/.test(name)) errors.push(`${tag}: username has a space / invalid character or is shorter than 3 characters`);
    // Password validation removed — any length accepted (default "1234" is used for POS users).
    const k = name.toLowerCase();
    if (k) {
      if (k === owner && !u._defaultPos) errors.push(`${tag}: this is the owner's own username`);
      if (seen.has(k)) errors.push(`${tag}: username "${name}" appears twice in the list (same as User ${seen.get(k) + 1})`);
      else seen.set(k, i);
    }
    const flags = u.flags || {};
    if (!USER_FLAG_DEFS.some((d) => flags[d.key])) warnings.push(`${tag}: no permission is ticked - this user will not be able to log in anywhere`);
  });
  return { errors, warnings };
}

// Did the server store the flags we sent? Only judges keys the response actually returns.
function userEcho(resp, payload) {
  const out = [];
  if (!resp || typeof resp !== "object") return out;
  const src = resp.data && typeof resp.data === "object" && !Array.isArray(resp.data) ? resp.data : resp;
  for (const d of USER_FLAG_DEFS) {
    if (!(d.field in src) || src[d.field] === null || src[d.field] === undefined) continue;
    const got = src[d.field] === true || src[d.field] === 1 || src[d.field] === "1";
    const want = payload[d.field] === true || payload[d.field] === 1;
    if (got !== want) out.push(`${d.label}: sent ${want ? "ON" : "OFF"}, server stored ${got ? "ON" : "OFF"}`);
  }
  return out;
}

// Keeps the customer credentials message clean:
//  - any old "*Additional Users*" block is removed (extra users are never listed to the client)
//  - the POS Front Office section shows the POS user that was really created
// created: [{ label, username, password, pos }]. Safe to call repeatedly.
function userMergeBlock(text, created) {
  let lines = String(text || "").split("\n");
  const head = lines.findIndex((l) => l.trim() === "*Additional Users*");
  if (head >= 0) {
    let j = head + 1;
    while (j < lines.length && /^\*•\s/.test(lines[j])) j++;
    lines.splice(head, j - head);
    while (head < lines.length && lines[head].trim() === "" && head > 0 && lines[head - 1].trim() === "") lines.splice(head, 1);
  }
  const pos = (created || []).find((c) => c && c.pos);
  if (pos) {
    const at = lines.findIndex((l) => /POS Front Office/i.test(l));
    if (at >= 0) {
      let uDone = false, pDone = false;
      for (let k = at + 1; k < Math.min(lines.length, at + 8); k++) {
        if (!uDone && /^\*•\s*Username\*?\s*:/.test(lines[k])) { lines[k] = `*• Username* : ${pos.username}`; uDone = true; }
        else if (!pDone && /^\*•\s*Password\*?\s*:/.test(lines[k])) { lines[k] = `*• Password* : ${pos.password}`; pDone = true; }
      }
    }
  }
  return lines.join("\n");
}

if (typeof module !== "undefined") {
  module.exports = { USER_FLAG_DEFS, USER_TYPES, USER_TYPE_DEFAULT_ID, userTypeByKey, userFlagsFor, userBuildPayload, userValidate, userEcho, userMergeBlock };
}
