// (i) Guide: explains every option in the Full Setup section, how to use it and
// what happens in each scenario. Opened from the (i) buttons (data-info="key").
(function () {
  var ITEMS = [
    {
      key: "overview", icon: "🧭", title: "How the whole flow works",
      what: "Onboarding has 3 stages: (1) paste the client's message and press Fetch, (2) Start Onboarding creates the outlet and the owner user, (3) Full Setup adds tables, menu, payment modes and more. Every step is independent - if one fails the others still run.",
      how: [
        "Paste the message (or a Slack link) in the big box, then press Fetch. Check the 'Detected details' popup and press OK.",
        "Tick only the steps you need in Full Setup (use Select all / Clear).",
        "Press Pre-check to see which steps will pass or fail, then press Start Onboarding.",
        "Watch the Setup checklist. Failed steps show the reason; press the eye button for the Status / History tabs."
      ],
      scenarios: [
        "Brand-new client: keep 'Outlet' ticked, press Start Onboarding. With Auto-Pilot ON the ticked Full Setup steps run right after.",
        "Outlet already exists: untick 'Outlet', pick it in Select Outlet, press Start Onboarding (or Submit).",
        "Only one thing is missing (e.g. just tables): untick everything else, tick that step, pick the outlet, press Submit.",
        "Not sure it will work: press Pre-check first - nothing is created by Pre-check."
      ]
    },
    {
      key: "outlet", icon: "🏪", title: "Outlet (+ owner user)",
      what: "Creates the outlet in backoffice and its owner/manager login from the message. Brand and market are looked up (or auto-created, see below).",
      how: [
        "Ticked = a new outlet and owner user are created when you press Start Onboarding.",
        "Unticked = outlet creation is skipped; the later steps run on the outlet you pick in Select Outlet.",
        "Fill any red/yellow fields in the 'Detected details' popup before continuing."
      ],
      scenarios: [
        "Outlet name already exists: it is detected, the Store ID is reused and creation is skipped (no duplicate).",
        "Unticked but no outlet selected: you are asked to select one - nothing runs.",
        "Missing owner name / mobile / address: a form appears so you can type it; what you type wins over the message.",
        "Owner user already exists: marked 'Already existed' in the checklist - not an error."
      ]
    },
    {
      key: "selectOutlet", icon: "📍", title: "Select Outlet",
      what: "Chooses which outlet the Full Setup steps (and the QR download) work on.",
      how: [
        "After creating an outlet it is selected automatically.",
        "For an existing outlet, open the list and choose it. The list loads from your backoffice login.",
        "Required when 'Outlet' is unticked or when you press Submit without creating an outlet first."
      ],
      scenarios: [
        "List is empty: check the Backoffice login at the top (or log in on backoffice.tmbill.com in this browser) and press Fetch.",
        "You pick a different outlet than the one in the message: the dropdown wins for Submit; Start Onboarding with 'Outlet' ticked still uses the message.",
        "Auto-Pilot always uses the outlet that was just created, never an old dropdown value."
      ]
    },
    {
      key: "marketBrand", icon: "🏷️", title: "Market & Brand (auto-create)",
      what: "An outlet belongs to a Brand, and a Brand belongs to a Market. If the brand or market in the message does not exist yet, these options create them.",
      how: [
        "Tick 'If Market not found, create new one' and type the market name (e.g. India).",
        "Tick 'If Brand not found, create new one' and type the brand name.",
        "Or put an existing Brand ID / Market ID in 'Optional IDs' at the top to use them directly."
      ],
      scenarios: [
        "Brand exists: it is reused, nothing is created.",
        "Brand missing and the box is unticked: you get a confirmation/warning instead of a silent new brand.",
        "Market missing but brand typed: the market is created first, then the brand inside it.",
        "Tip: leave both unticked for existing clients to avoid accidental duplicates."
      ]
    },
    {
      key: "posTables", icon: "🪑", title: "POS Table Department + Tables",
      what: "Creates a table department (e.g. Dine In) and its tables so the POS and table QR codes work.",
      how: [
        "Pick an existing Department, or leave it on 'New department' and type a Department name.",
        "Table names: comma separated, e.g. B1, B2, B3.",
        "Table count: total tables wanted. If it is more than the names you typed, the extra ones continue the numbering automatically (B1..B4 then B5, B6...)."
      ],
      scenarios: [
        "Only a count (e.g. 10), no names: tables are numbered automatically.",
        "Table already exists in that department: it is skipped, others are still created.",
        "Several departments (Dine In + Rooftop): run Submit once per department.",
        "Need QR codes afterwards: use the 'Download table QR' button at the top."
      ]
    },
    {
      key: "menu", icon: "📋", title: "Default POS Menu",
      what: "Creates a default POS menu (with no items yet) for the outlet so billing screens have a menu to use.",
      how: [
        "Tick it and keep the name 'POS Menu' or type your own.",
        "Items/categories are not added here - upload them in backoffice afterwards."
      ],
      scenarios: [
        "A menu with that name already exists: it is reused ('already created'), not duplicated.",
        "Client sends a menu file: tick this, then import the file in backoffice.",
        "Leave unticked if the outlet will copy a menu from another outlet."
      ]
    },
    {
      key: "paymentModes", icon: "💳", title: "Default Payment Modes",
      what: "Adds the payment modes (Cash, UPI, Card...) the outlet accepts at billing.",
      how: [
        "By default the standard modes are used (locked) so every outlet is consistent.",
        "To change them: Settings (gear) > turn ON 'Default payment modes edit', then search or open the list and tick/untick modes.",
        "Press Pre-check or load the master list first if the list is empty (needs an outlet selected)."
      ],
      scenarios: [
        "Locked and you need an extra mode (e.g. Zomato Pay): enable the edit toggle in Settings first.",
        "You remove every mode: not allowed - keep at least one, or untick this step to skip it.",
        "A mode is not in the master list: it is flagged and skipped; add it in backoffice.",
        "Your selection becomes the new default for next time."
      ]
    },
    {
      key: "digitalOrdering", icon: "🌐", title: "Enable Digital Ordering (Pickup + Delivery)",
      what: "Turns on online ordering for the outlet: pickup and delivery, with promocodes enabled for those channels.",
      how: [
        "Tick it, select the outlet and run Submit (or Auto-Pilot).",
        "Delivery charges, radius, timings and logos still need to be set in backoffice."
      ],
      scenarios: [
        "Dine-in only client: leave unticked.",
        "Client wants only delivery or only pickup: enable here, then switch the unwanted channel off in backoffice.",
        "Already enabled: settings are re-applied; the step reports done."
      ]
    },
    {
      key: "designation", icon: "🎖️", title: "Create Designation",
      what: "Creates staff designations (job titles) that users can be assigned, e.g. Manager, Cashier, Captain, Waiter.",
      how: [
        "Type designations separated by commas.",
        "Run this BEFORE or together with Create Users so the designations exist."
      ],
      scenarios: [
        "Designation exists already: skipped for that name, others are created.",
        "You only need the standard four: leave the default text as is.",
        "Custom role (e.g. Bartender): add it to the list."
      ]
    },
    {
      key: "users", icon: "👥", title: "Create Users",
      what: "Creates extra staff logins (POS billing, Captain, KDS, OrderHub, Self order, Manager). Each user gets only the access ticked on its row.",
      how: [
        "Choose a user type, set how many, press 'Add users' - rows appear with auto-generated usernames/passwords.",
        "Edit name, designation, phone, email or the access checkboxes on any row; remove rows you do not need.",
        "Before creating, you get a confirmation listing every user and any warnings."
      ],
      scenarios: [
        "4 captains: choose Captain, count 4, Add users.",
        "Mixed team: add rows of different types one after another.",
        "Duplicate username or missing field: the row turns red and creation is blocked until fixed.",
        "With Auto-Pilot the created logins are appended to the credentials message and History automatically."
      ]
    },
    {
      key: "discounts", icon: "🏷️", title: "Create Discounts",
      what: "Creates a percentage discount and a flat (rupee) discount that cashiers can apply on bills.",
      how: [
        "Set the names (e.g. 'Discount %', 'Discount Rs').",
        "Fill BOTH the name and the rate for every discount you want. A discount with an empty name or rate is skipped; if both are empty the step fails."
      ],
      scenarios: [
        "Client wants a fixed 10% festival discount: name it and enter 10.",
        "Only a flat discount needed: clear the name and rate of the % discount and fill the flat one.",
        "Name already exists: reported as 'already created', not duplicated.",
        "Rate left at 0: a discount with a 0 value is created - set the real rate if the client wants it preset."
      ]
    },
    {
      key: "autopilot", icon: "⚡", title: "Auto-Pilot",
      what: "After the outlet and owner user are created, automatically runs every ticked Full Setup step - no extra click.",
      how: [
        "ON: Start Onboarding does everything in one go.",
        "OFF: only the outlet + user are created; press Submit later to run Full Setup."
      ],
      scenarios: [
        "Nothing ticked in Full Setup: nothing extra runs, even with Auto-Pilot ON.",
        "A step fails: the rest continue; the checklist shows which one failed and why.",
        "Want to review first: turn Auto-Pilot OFF, run onboarding, press Pre-check, then Submit."
      ]
    },
    {
      key: "buttons", icon: "🔘", title: "Pre-check, Fetch, Start, Submit",
      what: "The main buttons and what each one does.",
      how: [
        "Fetch: reads the message only (nothing is created) and shows the detected details.",
        "Pre-check: predicts pass/fail for every ticked step. Safe to press any time.",
        "Start Onboarding: creates the outlet/user (if ticked) and, with Auto-Pilot, runs Full Setup.",
        "Submit: runs only the Full Setup steps for the selected outlet (no outlet creation)."
      ],
      scenarios: [
        "Submit is greyed out: select an outlet or finish onboarding first.",
        "Something failed: use the search (magnifier) button, paste the error and get the reason + fix.",
        "Need the login message again: History (clock) button keeps every copy by outlet."
      ]
    },
    {
      key: "bulk", icon: "📣", title: "WhatsApp Bulk Messenger",
      what: "Sends one template message to many numbers from the WhatsApp Web tab that is already open (no new tab). Numbers are cleaned to 10 digits automatically.",
      how: [
        "Open WhatsApp Web once and log in. Keep that tab open.",
        "Press the megaphone button, paste numbers (one per line or comma separated). Add a name before the number if you want {name} in the message.",
        "Check the green chips (valid numbers) and red chips (rejected, with reason). Duplicates are removed.",
        "Pick a template (or press New), edit the text and press Save changes. Delete removes a template; Restore defaults brings the built-in ones back.",
        "Set the delay (minimum 3 s) and press Send to all. Stop pauses safely; Retry failed re-sends only the failed numbers."
      ],
      scenarios: [
        "Number written as +91 98765 43210 / 91-9876543210 / 09876543210: all become 9876543210.",
        "Number not on WhatsApp: marked failed, the rest continue.",
        "Foreign number (+971...): kept only if written with + or 00, otherwise rejected.",
        "More than 30 numbers: you get a safety confirmation - sending too fast to strangers can get a WhatsApp number restricted."
      ]
    }
  ];

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  function build() {
    var box = document.getElementById("helpBody");
    if (!box || box.dataset.built) return;
    box.dataset.built = "1";
    box.innerHTML = ITEMS.map(function (it) {
      return '<details class="help-item" data-help="' + it.key + '"><summary><span class="help-ic">' + it.icon + "</span><span>" + esc(it.title) + "</span></summary>" +
        '<div class="help-sec"><b>What it does</b><p>' + esc(it.what) + "</p></div>" +
        '<div class="help-sec"><b>How to use</b><ul>' + it.how.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul></div>" +
        '<div class="help-sec"><b>Scenarios</b><ul>' + it.scenarios.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul></div></details>";
    }).join("");
  }

  function open(key) {
    build();
    var modal = document.getElementById("helpModal");
    var items = modal.querySelectorAll(".help-item");
    items.forEach(function (d) { d.open = !!key && d.dataset.help === key; });
    modal.style.display = "flex";
    var target = key && modal.querySelector('.help-item[data-help="' + key + '"]');
    var body = document.getElementById("helpBody");
    body.scrollTop = 0;
    if (target) setTimeout(function () { target.scrollIntoView({ block: "start" }); }, 30);
  }

  function close() { document.getElementById("helpModal").style.display = "none"; }

  document.addEventListener("click", function (ev) {
    var b = ev.target.closest && ev.target.closest("[data-info]");
    if (b) { ev.preventDefault(); ev.stopPropagation(); open(b.getAttribute("data-info")); return; }
    if (ev.target.id === "helpCloseBtn" || ev.target.id === "helpDoneBtn" || ev.target.closest("#helpCloseBtn")) close();
    if (ev.target.id === "helpAllBtn") {
      var all = document.querySelectorAll("#helpBody .help-item");
      var anyClosed = Array.prototype.some.call(all, function (d) { return !d.open; });
      all.forEach(function (d) { d.open = anyClosed; });
      ev.target.textContent = anyClosed ? "Collapse all" : "Expand all";
    }
  });
  document.addEventListener("keydown", function (ev) {
    var m = document.getElementById("helpModal");
    if (ev.key === "Escape" && m && m.style.display !== "none" && !document.getElementById("dialogModal").style.display.includes("flex")) close();
  });
})();
