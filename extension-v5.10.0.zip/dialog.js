// In-app dialogs: replaces the browser's alert()/confirm() with a proper modal
// that has clearly placed buttons (primary action on the right / full width on
// narrow panels), Enter = confirm, Esc = cancel, and keeps the side panel usable.
(function () {
  var queue = [];
  var active = null;

  function els() {
    return {
      modal: document.getElementById("dialogModal"),
      icon: document.getElementById("dialogIcon"),
      title: document.getElementById("dialogTitle"),
      body: document.getElementById("dialogBody"),
      ok: document.getElementById("dialogOk"),
      cancel: document.getElementById("dialogCancel"),
    };
  }

  var ICONS = { info: "ℹ️", success: "✅", warn: "⚠️", error: "❌", confirm: "❓" };

  function classify(msg) {
    var m = String(msg || "").toLowerCase();
    if (/(fail|error|could not|cannot|missing|required|did not load|not look valid)/.test(m)) return "error";
    if (/(complete|done|success)/.test(m)) return "success";
    return "info";
  }

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; });
  }

  // Turns "text\n\n- a\n- b" into paragraphs + a bullet list
  function render(msg) {
    var lines = String(msg == null ? "" : msg).split("\n");
    var html = "", list = [];
    function flush() { if (list.length) { html += "<ul>" + list.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>"; list = []; } }
    lines.forEach(function (ln) {
      var t = ln.trim();
      var b = t.match(/^[-•]\s+(.*)$/);
      if (b) { list.push(b[1]); return; }
      flush();
      if (t) html += "<p>" + esc(t) + "</p>";
    });
    flush();
    return html || "<p></p>";
  }

  function next() {
    if (active || !queue.length) return;
    var e = els();
    if (!e.modal) { // fallback if the markup is missing
      var q = queue.shift();
      q.resolve(q.kind === "confirm" ? window.__nativeConfirm(q.msg) : (window.__nativeAlert(q.msg), true));
      return next();
    }
    active = queue.shift();
    var o = active.opts || {};
    var kind = active.kind === "confirm" ? "confirm" : (o.kind || classify(active.msg));
    e.icon.textContent = ICONS[kind] || ICONS.info;
    e.title.textContent = o.title || (active.kind === "confirm" ? "Please confirm" : kind === "error" ? "Action needed" : kind === "success" ? "All done" : "Notice");
    e.body.innerHTML = render(active.msg);
    e.ok.textContent = o.okText || (active.kind === "confirm" ? "Yes, continue" : "OK");
    e.cancel.textContent = o.cancelText || "Cancel";
    e.cancel.style.display = active.kind === "confirm" ? "" : "none";
    e.modal.classList.toggle("dlg-danger", !!o.danger);
    e.modal.style.display = "flex";
    setTimeout(function () { e.ok.focus(); }, 0);
  }

  function close(result) {
    var e = els();
    if (e.modal) e.modal.style.display = "none";
    var a = active; active = null;
    if (a) a.resolve(result);
    next();
  }

  function init() {
    var e = els();
    if (!e.modal) return;
    e.ok.addEventListener("click", function () { close(true); });
    e.cancel.addEventListener("click", function () { close(false); });
    document.addEventListener("keydown", function (ev) {
      if (!active) return;
      if (ev.key === "Escape") { ev.preventDefault(); close(active.kind === "confirm" ? false : true); }
      else if (ev.key === "Enter" && document.activeElement !== e.cancel) { ev.preventDefault(); close(true); }
    });
  }

  window.__nativeAlert = window.alert.bind(window);
  window.__nativeConfirm = window.confirm.bind(window);

  window.uiAlert = function (msg, opts) {
    return new Promise(function (resolve) { queue.push({ kind: "alert", msg: msg, opts: opts, resolve: resolve }); next(); });
  };
  window.uiConfirm = function (msg, opts) {
    return new Promise(function (resolve) { queue.push({ kind: "confirm", msg: msg, opts: opts, resolve: resolve }); next(); });
  };
  // Existing alert() calls keep working (non-blocking) but now use the in-app dialog.
  window.alert = function (msg) { window.uiAlert(msg); };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
