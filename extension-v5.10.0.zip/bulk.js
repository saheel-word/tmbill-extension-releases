// WhatsApp Bulk Messenger: number cleaning (pure), templates CRUD, sending loop.
const BULK_TPL_KEY = "tmbill_bulk_templates";
const BULK_DEFAULTS = [
  { id: "d_welcome", name: "Welcome / Onboarding done", builtin: true, text: "Hello {name},\n\nWelcome to TMBill! Your onboarding is complete. If you need any help, just reply to this message and our team will assist you.\n\nThank you,\nTMBill Team" },
  { id: "d_training", name: "Training reminder", builtin: true, text: "Hello {name},\n\nThis is a reminder about your TMBill training session. Please let us know a convenient time and we will schedule it.\n\nThank you,\nTMBill Team" },
  { id: "d_followup", name: "Follow-up", builtin: true, text: "Hello {name},\n\nWe are following up to check if everything is working fine with TMBill. Please reply if you face any issue.\n\nThank you,\nTMBill Team" },
  { id: "d_update", name: "Product update", builtin: true, text: "Hello {name},\n\nWe have released new updates in TMBill. Please log out and log in once to get the latest version.\n\nThank you,\nTMBill Team" }
];

// Text -> { valid:[{name,number,full}], invalid:[{raw,reason}], dupes:n }
function bulkParseNumbers(text) {
  const valid = [], invalid = []; const seen = new Set(); let dupes = 0;
  const lines = String(text || "").split(/\r?\n/);
  for (const line of lines) {
    if (!line.trim()) continue;
    let found = phoneExtract(line);
    // Comma / semicolon / tab separated bare numbers on one line
    if (found.length <= 1 && /[,;\t]/.test(line)) {
      const parts = line.split(/[,;\t]+/).map((x) => x.trim()).filter(Boolean);
      const bare = parts.map((p) => phoneExtract(p)).filter((f) => f.length);
      if (bare.length > 1) {
        for (const f of bare) {
          const c = f[0];
          if (seen.has(c.full)) { dupes++; continue; }
          seen.add(c.full); valid.push({ name: "", number: c.number, full: c.full });
        }
        continue;
      }
    }
    if (!found.length) { invalid.push({ raw: line.trim(), reason: /\d/.test(line) ? "Not a valid mobile number (needs 10 digits starting 6-9)" : "No number found" }); continue; }
    for (const f of found) {
      if (seen.has(f.full)) { dupes++; continue; }
      seen.add(f.full);
      let name = "";
      if (found.length === 1) name = (line.slice(0, f.index) + line.slice(f.index + f.raw.length)).replace(/^[\s,;:\-|.]+|[\s,;:\-|.]+$/g, "").trim();
      valid.push({ name, number: f.number, full: f.full });
    }
  }
  return { valid, invalid, dupes };
}

function bulkRender(tpl, entry) {
  const name = (entry.name || "").trim();
  let t = String(tpl).replace(/\{name\}/gi, name).replace(/\{number\}/gi, entry.number);
  // tidy greeting when no name: "Hello ," -> "Hello,"
  return t.replace(/[ \t]+([,.!])/g, "$1");
}

if (typeof module !== "undefined") module.exports = { bulkParseNumbers, bulkRender, BULK_DEFAULTS };

if (typeof document !== "undefined" && document.getElementById("bulkModal")) (function initBulk() {
  const $ = (id) => document.getElementById(id);
  const modal = $("bulkModal"), input = $("bulkInput"), numsEl = $("bulkNums"), countEl = $("bulkCount");
  const sel = $("bulkTplSel"), nameEl = $("bulkTplName"), msgEl = $("bulkMsg"), warnEl = $("bulkWarn");
  const progEl = $("bulkProg"), resEl = $("bulkResults"), sendBtn = $("bulkSendBtn"), stopBtn = $("bulkStopBtn"), retryBtn = $("bulkRetryBtn");
  let templates = [], parsed = { valid: [], invalid: [], dupes: 0 }, stop = false, running = false, failed = [], curId = "";

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const store = {
    get: () => new Promise((r) => { try { chrome.storage.local.get(BULK_TPL_KEY, (o) => r(o && o[BULK_TPL_KEY])); } catch (e) { r(null); } }),
    set: (v) => new Promise((r) => { try { chrome.storage.local.set({ [BULK_TPL_KEY]: v }, () => r()); } catch (e) { r(); } })
  };
  const persist = () => store.set(templates);

  async function loadTemplates() {
    const saved = await store.get();
    templates = Array.isArray(saved) && saved.length ? saved : BULK_DEFAULTS.map((t) => ({ ...t }));
    if (!Array.isArray(saved)) await persist();
  }
  function drawSelect(keep) {
    sel.innerHTML = templates.map((t) => `<option value="${esc(t.id)}">${esc(t.name)}</option>`).join("");
    if (!templates.length) { curId = ""; nameEl.value = ""; msgEl.value = ""; return; }
    curId = templates.some((t) => t.id === keep) ? keep : templates[0].id;
    sel.value = curId; fillEditor();
  }
  function fillEditor() { const t = templates.find((x) => x.id === curId); nameEl.value = t ? t.name : ""; msgEl.value = t ? t.text : ""; }

  function reparse() {
    parsed = bulkParseNumbers(input.value);
    countEl.textContent = parsed.valid.length ? `${parsed.valid.length} valid` + (parsed.invalid.length ? `, ${parsed.invalid.length} rejected` : "") + (parsed.dupes ? `, ${parsed.dupes} duplicate removed` : "") : "";
    numsEl.innerHTML = parsed.valid.map((v) => `<span class="bulk-chip">${v.name ? esc(v.name) + " · " : ""}${v.number}</span>`).join("") +
      parsed.invalid.map((v) => `<span class="bulk-chip bad" title="${esc(v.reason)}">${esc(v.raw.slice(0, 24))} ✕</span>`).join("");
  }
  input.addEventListener("input", reparse);
  sel.addEventListener("change", () => { curId = sel.value; fillEditor(); });

  $("bulkTplNew").addEventListener("click", async () => {
    const t = { id: "t_" + Date.now(), name: "New template", text: "Hello {name},\n\n" };
    templates.push(t); await persist(); drawSelect(t.id); nameEl.focus(); nameEl.select();
  });
  $("bulkTplSave").addEventListener("click", async () => {
    const t = templates.find((x) => x.id === curId);
    const nm = nameEl.value.trim(), tx = msgEl.value;
    if (!nm || !tx.trim()) { warnEl.textContent = "Template name and message cannot be empty."; return; }
    warnEl.textContent = "";
    if (!t) templates.push({ id: "t_" + Date.now(), name: nm, text: tx }); else { t.name = nm; t.text = tx; }
    await persist(); drawSelect(curId || templates[templates.length - 1].id);
    progEl.textContent = "Template saved.";
  });
  $("bulkTplDel").addEventListener("click", async () => {
    const t = templates.find((x) => x.id === curId); if (!t) return;
    if (!(await uiConfirm(`Delete template "${t.name}"?`, { title: "Delete template", okText: "Delete", danger: true }))) return;
    templates = templates.filter((x) => x.id !== curId); await persist(); drawSelect("");
  });
  $("bulkTplReset").addEventListener("click", async () => {
    if (!(await uiConfirm("Bring back the built-in templates? Your own templates are kept; edits to built-in ones are reset.", { title: "Restore defaults", okText: "Restore" }))) return;
    const custom = templates.filter((t) => !t.builtin);
    templates = BULK_DEFAULTS.map((t) => ({ ...t })).concat(custom); await persist(); drawSelect(curId);
  });

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function addRes(entry, ok, msg) {
    const d = document.createElement("div"); d.className = "wa-res " + (ok ? "ok" : "bad");
    d.innerHTML = `${ok ? "✓" : "✕"} ${esc(entry.number)}${entry.name ? " (" + esc(entry.name) + ")" : ""}<small>${esc(msg)}</small>`;
    resEl.appendChild(d); d.scrollIntoView({ block: "nearest" });
  }

  async function run(list) {
    const text = msgEl.value;
    if (!text.trim()) { warnEl.textContent = "Message is empty - select or write a template."; return; }
    if (!list.length) { warnEl.textContent = "No valid numbers. Paste at least one number."; return; }
    warnEl.textContent = "";
    if (list.length > 30 && !(await uiConfirm(`You are about to message ${list.length} numbers. Sending many messages quickly to people who have not chatted with you can get a WhatsApp number restricted.\n\nUse a delay of 8+ seconds. Continue?`, { title: "Large batch", okText: "Continue" }))) return;
    if (!(await uiConfirm(`Send this message to ${list.length} number(s)?\n\nPreview:\n${bulkRender(text, list[0])}`, { title: "Confirm bulk send", okText: "Send" }))) return;
    const delay = Math.min(120, Math.max(3, Number($("bulkDelay").value) || 6)) * 1000;
    const saveC = $("bulkSave").checked;
    running = true; stop = false; failed = []; resEl.innerHTML = "";
    sendBtn.style.display = "none"; retryBtn.style.display = "none"; stopBtn.style.display = ""; input.disabled = true;
    let ok = 0;
    for (let i = 0; i < list.length; i++) {
      if (stop) { progEl.textContent = `Stopped at ${i}/${list.length}. Sent: ${ok}.`; failed.push(...list.slice(i)); break; }
      const e = list[i];
      progEl.textContent = `Sending ${i + 1}/${list.length} ...`;
      let r;
      try { r = await send("WA_SEND", { items: [{ phone: e.full, name: e.name || e.number, skipSave: !saveC }], text: bulkRender(text, e) }); }
      catch (x) { r = { ok: false, error: String(x && x.message || x) }; }
      if (r && r.ok && r.results && r.results[0] && r.results[0].ok) { ok++; addRes(e, true, r.results[0].confirmed === false ? "Sent (delivery not confirmed yet)" : "Sent"); }
      else {
        const err = (r && r.ok && r.results && r.results[0] && r.results[0].error) || (r && r.error) || "Failed";
        failed.push(e); addRes(e, false, err);
        if (r && !r.ok) { progEl.textContent = "WhatsApp Web problem - stopped. " + err; failed.push(...list.slice(i + 1)); break; }
      }
      if (i < list.length - 1 && !stop) await sleep(delay);
    }
    running = false; input.disabled = false;
    sendBtn.style.display = ""; stopBtn.style.display = "none"; retryBtn.style.display = failed.length ? "" : "none";
    if (!/Stopped|problem/.test(progEl.textContent)) progEl.textContent = `Done. Sent ${ok}/${list.length}` + (failed.length ? `, failed ${failed.length}.` : ".");
    try { statusEl.textContent = `Bulk WhatsApp: ${ok}/${list.length} sent`; } catch (e) {}
  }
  sendBtn.addEventListener("click", () => { reparse(); run(parsed.valid.slice()); });
  retryBtn.addEventListener("click", () => run(failed.slice()));
  stopBtn.addEventListener("click", () => { stop = true; stopBtn.disabled = true; setTimeout(() => (stopBtn.disabled = false), 500); });

  async function open() { await loadTemplates(); drawSelect(curId); reparse(); modal.style.display = "flex"; }
  $("bulkBtn").addEventListener("click", open);
  $("bulkCloseBtn").addEventListener("click", async () => {
    if (running && !(await uiConfirm("Sending is in progress. Close anyway? (Sending continues in the background of this panel.)", { okText: "Close" }))) return;
    modal.style.display = "none";
  });
  window.tmbillBulk = { open };
})();
