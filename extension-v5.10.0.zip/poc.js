// POC (Primary / Secondary point-of-contact) logic.
// The onboarding message names the POCs (e.g. "Primary POC: @Anand TMBill").
// We match those names against the executive roster and print each person's
// shift + week off under the login credentials. Pure functions, no DOM.

if (typeof phoneCanonical === "undefined" && typeof require !== "undefined") {
  var { phoneCanonical } = require("./phone.js");
}

var POC_ROSTER_VERSION = 3; // bump when the official list changes

// Official executive list (name, shift, week off, contact).
const POC_ROSTER_RAW = [
  ["Shifa Anjum", "07:00 AM to 04:00 PM", "Wednesday", "+91 89560 99322"],
  ["Shrejal Tambe", "08:30 AM to 05:30 PM", "Tuesday", "+91 79 7214 6329"],
  ["Poonam D", "09:00 AM to 06:00 PM", "Saturday", "+91 86249 01753"],
  ["Minakshi", "11:00 AM to 08:00 PM", "Tuesday", "+91 97669 65607"],
  ["Evangel", "11:00 AM to 08:00 PM", "Sunday", "+91 95183 49753"],
  ["Faizan T", "11:00 AM to 08:00 PM", "Friday", "+91 84214 34067"],
  ["Sanket B", "10:00 AM to 07:00 PM", "Thursday", "+91 84830 91507"],
  ["Akash Y", "12:00 PM to 09:00 PM", "Wednesday", "+91 83903 27794"],
  ["Naeem S", "12:00 PM to 09:00 PM", "Tuesday", "+91 73855 30044"],
  ["Aditya K", "12:00 PM to 09:00 PM", "Monday", "+91 92841 82585"],
  ["Rehan S", "01:00 PM to 10:00 PM", "Friday", "+91 90216 08992"],
  ["Anand D", "02:00 PM to 11:00 PM", "Saturday", "+91 70282 66161"],
  ["Vikas W", "02:00 PM to 11:00 PM", "Saturday", "+91 91724 94297"],
  ["Saheel S", "02:00 PM to 11:00 PM", "Sunday", "+91 7709 528 847"],
  ["Sajid S", "02:00 PM to 11:00 PM", "Thursday", "+91 81499 46288"],
  ["Atharva", "06:00 PM to 03:00 AM", "Tuesday", "+91 820 849 8039"],
];

// Numbers are stored normalised ("+91 9876543210")
const POC_ROSTER_DEFAULT = POC_ROSTER_RAW.map(([name, shift, weekOff, contact]) => {
  const c = phoneCanonical(contact);
  return { name, shift, weekOff, contact: c.kind === "in" ? "+91 " + c.number : c.kind === "intl" ? c.number : contact };
});

// Old / alternate spellings -> the roster spelling (a message may still say "Sahil").
const POC_NAME_ALIASES = { sahil: "saheel" };
function pocFirst(n) {
  const f = String(n || "").trim().toLowerCase().split(" ")[0];
  return POC_NAME_ALIASES[f] || f;
}

function pocDefaultState() {
  return {
    version: POC_ROSTER_VERSION,
    roster: POC_ROSTER_DEFAULT.map((e) => ({ ...e })),
    defaultPrimary: "Vikas W", // used only when the message names no Primary POC
    defaultSecondary: "",
  };
}

// Saved roster from an older version -> the current official list. Extra people
// the user added themselves (with a valid number) are kept; defaults are re-pointed by first name.
function pocMigrate(stored) {
  const fresh = pocDefaultState();
  if (!stored || !Array.isArray(stored.roster) || !stored.roster.length) return fresh;
  if ((stored.version || 1) >= POC_ROSTER_VERSION) {
    return { version: stored.version, roster: stored.roster, defaultPrimary: stored.defaultPrimary || "", defaultSecondary: stored.defaultSecondary || "" };
  }
  const firstOf = pocFirst;
  const known = new Set(fresh.roster.map((e) => firstOf(e.name)));
  const extras = stored.roster
    .filter((e) => e && e.name && !known.has(firstOf(e.name)) && pocContactOk(e.contact))
    .map((e) => ({ ...e, contact: pocNormalizeContact(e.contact) }));
  const roster = fresh.roster.concat(extras);
  const remap = (n) => {
    const hit = n ? roster.find((e) => firstOf(e.name) === firstOf(n)) : null;
    return hit ? hit.name : "";
  };
  return {
    version: POC_ROSTER_VERSION,
    roster,
    defaultPrimary: remap(stored.defaultPrimary) || fresh.defaultPrimary,
    defaultSecondary: remap(stored.defaultSecondary),
  };
}

// "[@Sanket Bahirat TMBill](https://...)" -> "Sanket Bahirat"
function pocCleanName(raw) {
  return String(raw || "")
    .replace(/\(https?:[^)]*\)/gi, " ")
    .replace(/[\[\]()]/g, " ")
    .replace(/@/g, " ")
    .replace(/\b(tmbill|global|sir|ji|madam|mam|team)\b/gi, " ")
    .replace(/[^A-Za-z .'-]/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[\s.'\-]+|[\s.'\-]+$/g, "") // "Anand -" -> "Anand"
    .trim();
}

// Best roster match for a name from the message, or null.
function pocMatchExecutive(raw, roster) {
  const cleaned = pocCleanName(raw).toLowerCase();
  if (!cleaned) return null;
  const words = cleaned.split(" ").map((w, i) => (i === 0 ? pocFirst(w) : w));
  let best = null;
  let bestScore = 0;
  for (const e of roster || []) {
    const full = String(e.name || "").trim().toLowerCase();
    if (!full) continue;
    const first = pocFirst(full);
    let score = 0;
    if (cleaned === full) score = 100;
    else if (` ${cleaned} `.includes(` ${full} `)) score = 80;
    else if (words[0] === first) score = 60;
    if (score > bestScore || (score === bestScore && score > 0 && full.length > String(best.name).length)) {
      best = e;
      bestScore = score;
    }
  }
  return bestScore >= 60 ? best : null;
}

function pocIst(shift) {
  const s = String(shift || "").trim();
  return !s || /\bIST\b/i.test(s) ? s : s + " IST";
}

function pocFormat(role, p) {
  const lines = [`*${role} POC – ${p.name}*`];
  if (p.shift) lines.push(`Shift Timing – ${pocIst(p.shift)}`);
  if (p.weekOff) lines.push(`Week Off – ${p.weekOff}`);
  if (p.contact) lines.push(`Contact Number - ${p.contact}`);
  return lines.join("\n");
}

// ---------------------------------------------------------------------
// Find the Primary / Secondary POC names in the raw message, wherever the name
// sits relative to its label:
//   "Primary POC: @Anand TMBill"          name AFTER the label
//   "@Anand TMBill - Primary POC"         name BEFORE the label
//   "Anand (Primary POC), Sanket (Secondary POC)"   several on one line
//   "Primary POC:" + next line "@Anand"   name on the NEXT line
//   "Anand" + next line "Primary POC"     name on the PREVIOUS line
// ---------------------------------------------------------------------
const POC_NOT_OURS = /\b(sales|support|tech|technical|account|accounts|billing|onboarding|implementation|training|escalation|l1|l2|l3|business|regional)\s+(?:poc|spoc)\b/i;
const POC_LABEL_RE = /(?:\b(primary|main|first|1st)\s*|\b(secondary|second|2nd|backup|alternate)\s*)?(?:\bpoc\b|\bspoc\b|point\s+of\s+contact)(?:\s*(?:name|person))?(?:\s*[-_#]?\s*(1|one|2|two)\b)?/gi;
const POC_STOP_NAMES = new Set(["primary", "secondary", "poc", "spoc", "contact", "name", "main", "backup", "alternate", "first", "second", "tmbill", "none", "na", "n/a", "nil"]);

function pocPlain(line) {
  return String(line || "")
    .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1") // markdown link -> its text
    .replace(/[*_~`]/g, "")
    .trim();
}

function pocValidName(n) {
  const c = pocCleanName(n);
  if (c.length < 2 || c.length > 40 || !/[A-Za-z]/.test(c)) return "";
  if (POC_STOP_NAMES.has(c.toLowerCase())) return "";
  // "Billing package", "Pro plan", "POS software" ... are not people
  if (/\b(billing|package|plan|subscription|license|licence|software|pos|app|kot|kds|hardware|printer|amount|price|renewal|validity|month|year|yearly|monthly)\b/i.test(c)) return "";
  return c;
}

function pocFindLabels(line) {
  const labels = [];
  POC_LABEL_RE.lastIndex = 0;
  let m;
  while ((m = POC_LABEL_RE.exec(line))) {
    if (!m[0].trim()) { POC_LABEL_RE.lastIndex++; continue; }
    const before = line.slice(Math.max(0, m.index - 22), m.index + m[0].length);
    if (POC_NOT_OURS.test(before)) continue; // "Sales POC", "Support POC" ...
    let role = "primary";
    if (m[2]) role = "secondary";
    else if (m[3] && /^(2|two)$/i.test(m[3])) role = "secondary";
    labels.push({ start: m.index, end: m.index + m[0].length, role, plainRole: !!(m[1] || m[2] || m[3]) });
  }
  return labels;
}

function pocExtract(text) {
  const lines = String(text || "").split(/\r?\n/).map(pocPlain);
  const out = { primary: "", secondary: "" };
  const bare = []; // labels that had no name on their own line: { line, role, colon }

  const take = (role, name) => {
    const n = pocValidName(name);
    if (n && !out[role]) out[role] = n;
    return !!n;
  };

  lines.forEach((line, li) => {
    const labels = pocFindLabels(line);
    labels.forEach((lb, i) => {
      const prevEnd = i > 0 ? labels[i - 1].end : 0;
      const nextStart = i + 1 < labels.length ? labels[i + 1].start : line.length;
      const before = line.slice(prevEnd, lb.start);
      const after = line.slice(lb.end, nextStart);
      const afterIsValue = /^\s*[:=\-–—]/.test(after) || (i + 1 === labels.length && /^\s*@/.test(after));
      const order = afterIsValue ? [after, before] : [before, after];
      if (take(lb.role, order[0]) || take(lb.role, order[1])) return;
      bare.push({ line: li, role: lb.role, colon: /[:=\-–—]\s*$/.test(line) });
    });
  });

  // Names on a neighbouring line (label alone on its line)
  const isLabelLine = (i) => i >= 0 && i < lines.length && pocFindLabels(lines[i]).length > 0;
  const nameLike = (i) => {
    if (i < 0 || i >= lines.length || !lines[i] || isLabelLine(i)) return "";
    if (/[:=]\s*\S/.test(lines[i]) && !/^@/.test(lines[i])) return ""; // another "Label: value" line
    if (/\d{5,}/.test(lines[i]) || lines[i].length > 45) return "";
    return lines[i];
  };
  const bareLines = new Set(bare.map((b) => b.line));
  for (const b of bare) {
    const next = nameLike(b.line + 1);
    const prev = nameLike(b.line - 1);
    // "Name" above a label (no colon) is the usual stacked "Name / Label" layout.
    const nextClaimedByFollowingLabel = next && bareLines.has(b.line + 2) && !b.colon;
    if (next && !nextClaimedByFollowingLabel) take(b.role, next);
    else if (prev) take(b.role, prev);
    else if (next) take(b.role, next);
  }
  return out;
}

// ---- Contact numbers are MANDATORY for every POC that gets printed ----
// Stored as "+91 9876543210" (Indian) or "+971501234567" (other countries).
function pocContactOk(raw) {
  return phoneCanonical(raw).kind !== "bad";
}
function pocNormalizeContact(raw) {
  const c = phoneCanonical(raw);
  if (c.kind === "in") return "+91 " + c.number;
  if (c.kind === "intl") return c.number;
  return String(raw || "").trim();
}

// POCs that will be printed but have no usable contact number.
function pocProblems(data, state) {
  const { primary, secondary } = pocResolve(data, state);
  const out = [];
  for (const [role, p] of [["Primary", primary], ["Secondary", secondary]]) {
    if (p && !pocContactOk(p.contact)) out.push({ role, name: p.name, reason: p.shift ? "no contact number in the roster" : "not in the roster (so no number either)" });
  }
  return out;
}

// Same check on a finished message (used by the WhatsApp confirmation popup,
// where the text can be edited): every "*Primary POC – X*" block needs a number.
function pocMessageProblems(text) {
  const out = [];
  const re = /\*(Primary|Secondary) POC – ([^*\n]+)\*([\s\S]*?)(?=\n\s*\n|\*(?:Primary|Secondary) POC|$)/g;
  let m;
  while ((m = re.exec(String(text || "")))) {
    const m2 = m[3].match(/Contact Number\s*[-–]\s*(.+)/);
    if (!m2 || !pocContactOk(m2[1])) out.push(`${m[1]} POC (${m[2].trim()}) has no contact number`);
  }
  return out;
}

// data: parsed message fields (primary_poc / secondary_poc, raw text from the message)
function pocResolve(data, state) {
  const roster = state.roster || [];
  const byName = (n) => roster.find((e) => String(e.name).toLowerCase() === String(n || "").toLowerCase()) || null;
  const unmatched = [];
  const one = (raw, fallbackName) => {
    const cleaned = pocCleanName(raw);
    if (cleaned) {
      const m = pocMatchExecutive(raw, roster);
      if (m) return m;
      unmatched.push(cleaned); // named in the message but not in our roster: print the name only
      return { name: cleaned, shift: "", weekOff: "", contact: "" };
    }
    return fallbackName ? byName(fallbackName) : null;
  };
  const primary = one(data && data.primary_poc, state.defaultPrimary);
  const secondary = one(data && data.secondary_poc, state.defaultSecondary);
  return { primary, secondary, unmatched };
}

function pocBlockFor(data, state) {
  const { primary, secondary } = pocResolve(data, state);
  const parts = [];
  if (primary) parts.push(pocFormat("Primary", primary));
  if (secondary) parts.push(pocFormat("Secondary", secondary));
  return parts.join("\n\n");
}

function pocStripBlock(text) {
  return String(text || "").replace(/\s*\*(?:Primary|Secondary) POC[\s\S]*$/, "").replace(/\s+$/, "");
}

// Only touches the login-credentials output; idempotent.
function pocApply(text, data, state) {
  const t = String(text || "");
  if (!/Back Office \/ Owner Panel/.test(t)) return t;
  const block = pocBlockFor(data, state);
  const base = pocStripBlock(t);
  return block ? base + "\n\n" + block : base;
}

if (typeof module !== "undefined") {
  module.exports = { pocMigrate, POC_ROSTER_VERSION, pocContactOk, pocNormalizeContact, pocProblems, pocMessageProblems, pocExtract, POC_ROSTER_DEFAULT, pocDefaultState, pocCleanName, pocMatchExecutive, pocResolve, pocBlockFor, pocApply, pocStripBlock };
}
