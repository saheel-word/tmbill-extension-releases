// Phone helpers shared by the popup and the background worker (pure functions).
//
// phoneCanonical(raw) -> { kind, number, full }
//   kind "in"   : Indian mobile.  number = 10 digits ("9876543210"), full = "919876543210"
//   kind "intl" : other country (needs a leading + or 00). number = "+971501234567", full = "971501234567"
//   kind "bad"  : cannot be a usable number
// Accepts: 9876543210 | +91 98765 43210 | 91-9876543210 | 09876543210 | (+91) 98765.43210 |
//          +91 09876543210 | 0091 9876543210 | 98765 43 210 ...

function phoneCanonical(raw) {
  const s = String(raw == null ? "" : raw).trim();
  const explicit = /^[\s(]*\+/.test(s) || /^[\s(]*00/.test(s); // "+" or "00" = country code follows
  let d = s.replace(/\D/g, "");
  if (/^[\s(]*00/.test(s)) d = d.replace(/^00/, "");

  const indian = (ten) => ({ kind: "in", number: ten, full: "91" + ten });
  if (/^[6-9]\d{9}$/.test(d)) return indian(d);
  if (/^0[6-9]\d{9}$/.test(d)) return indian(d.slice(1));
  if (/^91[6-9]\d{9}$/.test(d)) return indian(d.slice(2));
  if (/^910[6-9]\d{9}$/.test(d)) return indian(d.slice(3)); // "+91 0 98765 43210"

  // Another country: only trust it when written with + / 00 (otherwise a 10-digit
  // number could be anything).
  if (explicit && d.length >= 8 && d.length <= 15 && !d.startsWith("91")) {
    return { kind: "intl", number: "+" + d, full: d };
  }
  return { kind: "bad", number: s, full: "" };
}

// Every phone number found in a piece of text, canonicalised and de-duplicated
// (same number written two ways counts once). Returns [{ number, full, kind, raw, index }].
function phoneExtract(text) {
  const t = String(text == null ? "" : text);
  const found = [];
  const seen = new Set();
  const add = (raw, index) => {
    const c = phoneCanonical(raw);
    if (c.kind === "bad" || seen.has(c.full)) return;
    seen.add(c.full);
    found.push({ ...c, raw, index });
  };
  // Indian: optional 91 / +91 / (+91) / 0 prefix, then 10 digits with any
  // single separators (space . -) between digits.
  const indian = /(?<!\d)((?:\(?\+?\s?91\)?[\s.\-]*|0[\s.\-]*)?[6-9](?:[\s.\-]?\d){9})(?!\d)/g;
  let m;
  while ((m = indian.exec(t))) add(m[1], m.index);
  // International: must start with + and not be +91
  const intl = /(?<![\d+])\+(?!\s?91(?!\d))\s?\d[\d\s.\-()]{6,18}\d/g;
  while ((m = intl.exec(t))) add(m[0], m.index);
  return found.sort((a, b) => a.index - b.index);
}

if (typeof module !== "undefined") module.exports = { phoneCanonical, phoneExtract };
