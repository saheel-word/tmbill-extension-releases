// TMBill Outlet Onboarding — background service worker
importScripts("phone.js", "usertypes.js", "updater_core.js"); // phone helpers + extra-user presets (shared with the popup)
// parse -> resolve brand/market -> create/update outlet -> create owner user

const BASE_URL = "https://backoffice.tmbill.com";
const DEFAULT_SUPPORT_EMAIL = "support@tmbill.com";
const ALIAS_KEY = "tmbill_custom_aliases";
const DEFAULT_BRAND_ID = "9042";
const DEFAULT_MARKET_ID = "72923343";

const FIELD_ALIASES = {
  outlet_name: ["outlet name", "outlet", "store name", "company name", "business name", "restaurant name", "brand outlet name", "shop name", "name", "restaurant", "cafe name", "hotel name", "firm name", "outlet title", "client outlet name"],
  owner_name: ["outlet owner name", "owner name", "owner", "manager name", "client name", "contact person", "contact person name", "contact name", "owner s name", "name of owner", "person name"],
  primary_poc: ["primary poc", "primary poc name"],
  secondary_poc: ["secondary poc", "secondary poc name"],
  mobile: [
    "mobile no", "mobile number", "mobile", "contact number", "phone",
    "outlet owner mobile", "outlet owner mobile no", "outlet owner mobile number", "owner mobile", "owner mobile no",
    "owner mobile number", "outlet mobile", "outlet mobile no", "outlet mobile number", "outlet contact number",
    "outlet owner contact", "outlet owner contact number", "owner contact number", "outlet phone", "owner phone",
  , "contact", "contact no", "contact no.", "whatsapp contact", "whatsapp number", "whatsapp no"],
  address: ["outlet address", "address", "location address", "outlet location", "full address", "shop address", "business address", "store address", "restaurant address", "location", "outlet full address"],
  pincode: ["pincode", "pin code", "zip code", "zip_codes", "postal code", "pin", "zip", "postcode", "pincode no", "pin no"],
  email: ["outlet mail id", "outlet mail", "outlet email", "outlet email id", "owner email", "owner mail", "email id", "email", "mail id", "mail", "e-mail", "e-mail id", "e mail", "e mail id", "email address", "mail address", "email id of owner"],
  gst: ["gst no", "gst number", "gst", "gstin", "gst in", "gst no.", "gst number."],
  username: ["username", "user name", "user id", "userid", "login id", "loginid", "login name", "login username", "back office username", "login"],
  password: ["password", "pass", "pwd", "passcode", "login password", "back office password"],
  login_link: ["login link", "access portal", "login url"],
  pos_username: ["pos username", "front office username", "billing username"],
  pos_password: ["pos password", "front office password", "billing password"],
  support_email: ["support email"],
  city: ["city"],
  locality: ["locality", "area"],
  brand_id: ["brand id", "brand_id"],
  market_id: ["market id", "market_id"],
  brand_name: ["brand name", "brand"],
  market_name: ["market name", "market"],
  day_start_time: ["day start time", "start day time", "day_start_time"],
  day_close_time: ["day close time", "close day time", "day_close_time"],
  resetBillAfterDays: ["reset bill after days", "resetbillafterdays"],
  reset_kot_indays: ["reset kot in days", "reset_kot_indays"],
};

// Friendly Marathi/English labels for the manual "fill missing fields" box
// in the popup -- keys must match requiredFields()/FIELD_ALIASES keys.
const FIELD_LABELS = {
  outlet_name: "Outlet Name",
  owner_name: "Owner / Manager Name",
  mobile: "Mobile Number",
  address: "Address",
  pincode: "Pincode",
  email: "Email ID",
  username: "Username",
  password: "Password",
};

function clean(v) {
  v = v.replace(/\[([^\]]+)\]\([^)]*\)/g, "$1");
  v = v.replace(/\\:/g, ":").replace(/\\@/g, "@").trim();
  v = v.replace(/^[*•\-\s]+/, "");
  // emoji / arrows / other symbol prefixes (e.g. "📍 Address", "➡ Mobile")
  v = v.replace(/^[^\p{L}\p{N}+@(]+/u, "");
  return v.trim();
}

// Learned label -> field mappings (saved when the user assigns an unknown label).
let customAliases = {};

function normalizeMobile(v) {
  const c = phoneCanonical(v);
  return c.kind === "bad" ? String(v || "").trim() : c.number;
}

// "Label: value" / "Label - value" / "Label = value" / "LABEL-value"
function splitLabelValue(plain) {
  let m = plain.match(/^\s*([^:：]{1,60}?)\s*[:：]+\s*(.*)$/);
  if (m && !/^https?$/i.test(m[1].trim())) return [m[1], m[2]];
  m = plain.match(/^\s*([^\-–—=→]{1,60}?)\s+[\-–—=→]+\s+(.*)$/);
  if (m) return [m[1], m[2]];
  m = plain.match(/^\s*([^:\-]+?)\s*-\s*(.+?)\s*$/);
  if (m) return [m[1], m[2]];
  return null;
}

function normaliseLabel(label) {
  label = clean(label);
  label = label.replace(/[*_`]+/g, "").trim().toLowerCase();
  label = label.replace(/^:(?:one|two|three|four|five|six|seven|eight|nine|ten):\s*/i, "");
  label = label.replace(/^(?:\d+|[ivx]+)[.)\-:]\s*/i, "");
  label = label.replace(/^[•*\-]+\s*/, "");
  // strip trailing annotations like "GST No(if any)" -> "GST No"
  label = label.replace(/\([^)]*\)/g, "").trim();
  label = label.replace(/\s*[\/&]\s*/g, " "); // "Outlet/Owner Mobile" -> "outlet owner mobile"
  return label.replace(/\s+/g, " ").trim();
}

function keyFromLabel(label) {
  if (customAliases && customAliases[label]) return customAliases[label];
  let bestKey = null;
  let bestLen = -1;
  for (const [candidate, aliases] of Object.entries(FIELD_ALIASES)) {
    for (const a of aliases) {
      if (label === a && a.length > bestLen) {
        bestKey = candidate;
        bestLen = a.length;
      }
    }
  }
  return bestKey;
}

function parseDetails(text) {
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  const result = {};
  const alts = {}; // every distinct value seen per field (to spot conflicts)
  const unmapped = []; // "Label: value" lines we could not map to a field
  let pendingSection = null;

  const note = (key, value) => {
    (alts[key] = alts[key] || []);
    if (!alts[key].includes(value)) alts[key].push(value);
  };

  for (let i = 0; i < lines.length; i++) {
    let plain = clean(lines[i]);
    plain = plain.replace(/^:(?:one|two|three|four|five|six|seven|eight|nine|ten):\s*/i, "");
    plain = plain.replace(/^(?:\d+|[ivx]+)[.)\-:]\s*/i, "");
    const low = plain.toLowerCase();

    if (low.includes("back office") || low.includes("owner panel")) {
      pendingSection = "backoffice";
      continue;
    }
    if (low.includes("pos front office") || low.includes("billing system")) {
      pendingSection = "pos";
      continue;
    }

    const parts = splitLabelValue(plain);
    if (!parts) continue;
    const label = normaliseLabel(parts[0]);
    let value = clean(parts[1] || "");
    if (!label) continue;

    let key = keyFromLabel(label);

    // Value on the NEXT line ("Username:" then "dailycoffee" below it).
    if (!value && key) {
      const next = lines[i + 1] ? clean(lines[i + 1]) : "";
      const looksLikeLabel = /^[^:：]{1,45}[:：]\s*\S/.test(next) && !/^https?:/i.test(next);
      if (next && !looksLikeLabel) {
        value = next;
        i++;
      }
    }
    if (!value) continue;

    if (key === "username" && pendingSection === "pos") key = "pos_username";
    else if (key === "password" && pendingSection === "pos") key = "pos_password";
    if (key) {
      result[key] = value;
      note(key, value);
    } else if (
      label.length <= 40 &&
      value.length <= 80 &&
      /[a-z]/i.test(label) &&
      !/[\[\]\d]/.test(label) &&
      !/login details|master|head office|for support|package|\bpoc\b|\bteam\b/i.test(label) &&
      !/^https?/i.test(value) &&
      unmapped.length < 12 &&
      !unmapped.some((u) => u.label === label)
    ) {
      unmapped.push({ label, value });
    }
  }

  if (!result.login_link) result.login_link = BASE_URL;
  if (!result.support_email) result.support_email = DEFAULT_SUPPORT_EMAIL;

  // Fallback: some pastes lead with a plain "header block" of unlabeled
  // lines instead of "Label: value" pairs, e.g.:
  //   KANHAIYA PURE VEG          <- outlet name
  //   Shridhar J. Muni           <- owner/manager name
  //   9881818285                 <- mobile
  //   vaibhav@kanhaiyyarestaurant.com   <- email
  //   YAVATMAL                   <- city/address
  // Only kicks in when core fields are still missing after label-based
  // parsing, and only trusts the first contiguous block of lines (up to
  // the first blank line) that contains a bare 10-digit Indian mobile
  // number -- so normal labelled pastes are left untouched.
  if (!result.outlet_name || !result.owner_name || !result.mobile || !result.address) {
    const rawLines = text.split("\n").map((l) => l.trim());
    const blockEnd = rawLines.findIndex((l) => l === "");
    const block = (blockEnd === -1 ? rawLines : rawLines.slice(0, blockEnd))
      .map((l) => clean(l))
      .filter(Boolean);

    const mobileIdx = block.findIndex((l) => /^[6-9]\d{9}$/.test(l.replace(/[\s\-]/g, "")));
    if (mobileIdx !== -1) {
      if (!result.mobile) result.mobile = block[mobileIdx].replace(/[\s\-]/g, "");
      if (!result.outlet_name && block[0] && !/[:\-]/.test(block[0]) && !/\d/.test(block[0])) {
        result.outlet_name = block[0];
      }
      if (!result.owner_name && mobileIdx > 0) {
        const cand = block[mobileIdx - 1];
        if (cand && !/\d/.test(cand) && !/@/.test(cand) && cand !== result.outlet_name) {
          result.owner_name = cand;
        }
      }
      if (!result.address) {
        const emailIdx = block.findIndex((l) => /@/.test(l));
        const cityIdx = emailIdx !== -1 ? emailIdx + 1 : mobileIdx + 1;
        const cand = block[cityIdx];
        if (
          cand &&
          !/\d/.test(cand) &&
          !/@/.test(cand) &&
          cand !== result.outlet_name &&
          cand !== result.owner_name
        ) {
          result.address = cand;
        }
      }
    }
  }

  // Fallback: some pastes never state an explicit Owner/Manager Name field
  // but do have a "Connect with <Name> <phone>" contact line (common in the
  // NE-region onboarding requests) — use that as the owner_name.
  if (!result.owner_name) {
    const contactMatch = text.match(/connect\s+with\s+([a-zA-Z][a-zA-Z .]*?)\s+[\d+][\d\s\-]{7,}/i);
    if (contactMatch) result.owner_name = contactMatch[1].trim();
  }

  // A value that still starts with its own label ("Outlet Name One Bite") -> drop the label part.
  for (const k of ["outlet_name", "owner_name"]) {
    if (result[k]) result[k] = String(result[k]).replace(/^\s*(?:outlet|restaurant|store|shop|cafe|hotel|firm|business|company|owner|manager|client)\s+name\s*[:\-\u2013\u2014]*\s+/i, "").trim() || result[k];
  }
  if (result.address) result.address = String(result.address).replace(/^\s*address\s*[:\-\u2013\u2014]\s*/i, "").trim() || result.address;

  // Fallback: derive a 6-digit Indian pincode from the address when the
  // paste never gives Pincode as its own labelled field.
  if (!result.pincode && result.address) {
    const pinMatch = result.address.match(/(\d{6})(?!\d)/);
    if (pinMatch) result.pincode = pinMatch[1];
  }

  // Label-independent fallbacks: format changes every time, but an e-mail
  // and an Indian mobile number always look the same. Lines about a manager,
  // POC, support, sales etc. are skipped so we don't grab someone else's.
  const NOT_CLIENT = /manager|poc|support|secondary|alternate|sales|helpline|accounts?\b|billing|team|tmbill/i;
  if (!result.email) {
    for (const line of text.split("\n")) {
      if (NOT_CLIENT.test(line)) continue;
      const em = clean(line).match(/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/);
      if (em) { result.email = em[0]; break; }
    }
  }
  if (!result.mobile) {
    for (const line of text.split("\n")) {
      if (NOT_CLIENT.test(line)) continue;
      const found = phoneExtract(line);
      if (found.length) { result.mobile = found[0].number; break; }
    }
  }
  if (result.email) result.email = result.email.replace(/^mailto:/i, "").replace(/[<>,;.\s]+$/g, "").trim();
  if (result.mobile) {
    // "9876543210 / 9123456780" in one field: first one is the mobile, the rest are offered as alternatives.
    const all = phoneExtract(result.mobile);
    if (all.length) {
      result.mobile = all[0].number;
      alts.mobile = all.map((a) => a.number); // chips: "Also in the message"
    } else {
      result.mobile = String(result.mobile).trim();
    }
  }

  // Not enumerable -> never leaks into payloads / JSON / spreads.
  Object.defineProperty(result, "__unmapped", { value: unmapped, enumerable: false });
  Object.defineProperty(result, "__alts", { value: alts, enumerable: false });
  return result;
}

const EMAIL_TYPO_DOMAINS = ["gamail.com", "gmial.com", "gmai.com", "gmal.com", "gnail.com", "gmaill.com", "gmeil.com", "gamil.com", "gmail.con", "gmail.co", "gmail.cm", "yaho.com", "yahooo.com", "hotmial.com"];

// Field-by-field report shown in the popup so wrong / missing details are
// visible BEFORE anything is created. status: ok | warn | missing | optional
function buildReview(d, missing) {
  const has = (v) => !!String(v == null ? "" : v).trim();
  const REQ = new Set(missing || []);
  const rows = [
    ["outlet_name", "Outlet Name"],
    ["owner_name", "Owner Name"],
    ["mobile", "Mobile (optional)"],
    ["email", "Email (optional)"],
    ["address", "Address"],
    ["pincode", "Pincode"],
    ["username", "Username"],
    ["password", "Password"],
    ["gst", "GST No (optional)"],
  ];
  const out = [];
  for (const [key, label] of rows) {
    const v = String(d[key] == null ? "" : d[key]).trim();
    let status = "ok";
    let msg = "";
    if (!has(v)) {
      if (REQ.has(key)) { status = "missing"; msg = "Not found - required"; }
      else { status = "optional"; msg = key === "gst" ? "" : "Not found (optional) - fill it in if you have it"; }
    } else {
      const bad = (m) => { status = "warn"; msg = m; };
      if (key === "email") {
        const dom = (v.split("@")[1] || "").toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) bad("Email format looks wrong");
        else if (EMAIL_TYPO_DOMAINS.includes(dom)) bad(`"${dom}" looks misspelled (gmail.com?)`);
      } else if (key === "mobile") {
        if (phoneCanonical(v).kind === "bad") bad("Mobile number looks invalid (10 digits, or +country code)");
      } else if (key === "pincode") {
        if (!/^[1-9]\d{5}$/.test(v)) bad("Pincode must be 6 digits");
      } else if (key === "username") {
        if (!/^\S{3,}$/.test(v)) bad("Username has a space or is too short");
      } else if (key === "password") {
        if (v.length < 6) bad("Password is shorter than 6 characters");
      } else if (key === "gst") {
        // Accept any non-empty GST value the user has provided — no length/format block.
        // (Some registrations have slightly different formats; trust what the client sent.)
      } else if (key === "owner_name") {
        if (/\d/.test(v)) bad("Owner name contains a number - please check");
      } else if (key === "address") {
        if (v.length < 8) bad("Address is too short");
      } else if (key === "outlet_name") {
        if (v.length < 2) bad("Outlet name is too short");
      }
    }
    out.push({ key, label, value: v, status, msg });
  }
  return out;
}

const LOCALITY_CITY = [
  [/\bmalad\s+(west|east)\b/i, "Mumbai"],
  [/\bandheri\s+(west|east)\b/i, "Mumbai"],
  [/\bborivali\s+(west|east)\b/i, "Mumbai"],
  [/\bbandra\s+(west|east)\b/i, "Mumbai"],
  [/\bpowai\b/i, "Mumbai"],
  [/\bgoregaon\s+(west|east)\b/i, "Mumbai"],
  [/\bkurla\s+(west|east)\b/i, "Mumbai"],
  [/\bvashi\b/i, "Navi Mumbai"],
  [/\bthane\b/i, "Thane"],
  [/\bbaner\b/i, "Pune"],
  [/\bhadapsar\b/i, "Pune"],
  [/\bwakad\b/i, "Pune"],
  [/\bhinjewadi\b/i, "Pune"],
  [/\bkandoli\b/i, "Dehradun"],
  [/\bbid(h)?oli\b/i, "Dehradun"],
  [/\bupes\b/i, "Dehradun"],
  [/\bclement\s*town\b/i, "Dehradun"],
  [/\braipur\s+road\b/i, "Dehradun"],
  [/\bkoramangala\b/i, "Bengaluru"],
  [/\bindiranagar\b/i, "Bengaluru"],
  [/\bwhitefield\b/i, "Bengaluru"],
  [/\bhsr\s*layout\b/i, "Bengaluru"],
  [/\belectronic\s*city\b/i, "Bengaluru"],
  [/\bdwarka\b/i, "New Delhi"],
  [/\bsaket\b/i, "New Delhi"],
  [/\bkarol\s*bagh\b/i, "New Delhi"],
  [/\bgurugram|gurgaon\b/i, "Gurugram"],
  [/\bnoida\b/i, "Noida"],
  [/\bhitech\s*city|hitec\s*city\b/i, "Hyderabad"],
  [/\bgachibowli\b/i, "Hyderabad"],
  [/\bbanjara\s*hills\b/i, "Hyderabad"],
  [/\bt\s*nagar\b/i, "Chennai"],
  [/\banna\s*nagar\b/i, "Chennai"],
  [/\bomr\b/i, "Chennai"],
  [/\bsalt\s*lake\b/i, "Kolkata"],
  [/\bnew\s*town\b/i, "Kolkata"],
  [/\bkothrud\b/i, "Pune"],
  [/\bviman\s*nagar\b/i, "Pune"],
  [/\bsatellite\b/i, "Ahmedabad"],
  [/\bbopal\b/i, "Ahmedabad"],
];

const CITY_NAMES = [
  "Mumbai", "Pune", "Nashik", "Nagpur", "Ahmednagar", "Thane", "Aurangabad", "Kolhapur",
  "Navi Mumbai", "Solapur", "Amravati", "Nanded", "Sangli", "Jalgaon", "Akola", "Latur",
  "Dhule", "Ahmedabad", "Chandrapur", "Parbhani", "Ichalkaranji", "Bhiwandi", "Ulhasnagar", "Malegaon",
  "Dehradun", "Haridwar", "Rishikesh", "Roorkee", "Haldwani", "Nainital", "Rudrapur",
  "New Delhi", "Delhi", "Gurugram", "Gurgaon", "Noida", "Faridabad", "Ghaziabad",
  "Bengaluru", "Bangalore", "Mysuru", "Mysore", "Mangalore", "Hubli", "Belgaum",
  "Hyderabad", "Warangal", "Vijayawada", "Visakhapatnam", "Guntur", "Nellore",
  "Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Erode", "Tirunelveli",
  "Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri",
  "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Gandhinagar",
  "Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer", "Bikaner",
  "Lucknow", "Kanpur", "Agra", "Varanasi", "Meerut", "Prayagraj", "Allahabad", "Bareilly",
  "Aligarh", "Moradabad", "Saharanpur", "Gorakhpur", "Jhansi", "Firozabad",
  "Indore", "Bhopal", "Jabalpur", "Gwalior", "Ujjain",
  "Patna", "Gaya", "Ranchi", "Jamshedpur", "Bhilai", "Dhanbad",
  "Ludhiana", "Amritsar", "Jalandhar", "Chandigarh", "Shimla", "Manali", "Jammu", "Srinagar",
  "Bhubaneswar", "Cuttack", "Rourkela", "Raipur",
  "Kochi", "Cochin", "Thiruvananthapuram", "Kozhikode", "Kollam",
  "Guwahati", "Shillong", "Imphal",
  "Panaji", "Margao",
];

// Best-effort pincode lookup via India Post's public Pincode API, used only
// when the pasted message has no explicit 6-digit pincode anywhere. A short
// timeout keeps a slow/unreachable network from hanging Parse/Onboarding.
async function fetchWithTimeout(url, ms) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    return await fetch(url, { signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function lookupPincode(query) {
  if (!query) return null;
  try {
    const resp = await fetchWithTimeout(`https://api.postalpincode.in/postoffice/${encodeURIComponent(query)}`, 5000);
    if (!resp.ok) return null;
    const data = await resp.json();
    const offices = Array.isArray(data) && data[0] && data[0].Status === "Success" ? data[0].PostOffice : null;
    if (!Array.isArray(offices) || !offices.length) return null;
    const office = offices[0];
    return { pincode: office.Pincode, district: office.District || null };
  } catch (e) {
    return null; // network error / timeout — leave pincode for the user to fill in manually
  }
}

// Addresses like "Ranthambhor road Sawai Madhopur" have no commas, so the
// whole line never matches a post office. The town is usually at the END, so
// try the last 2 / 1 / 3 words first (skipping generic words like "road").
const ADDRESS_STOPWORDS = new Set(
  "road rd street st near opp opposite behind nagar colony chowk marg lane plot no shop floor building complex market main bazar bazaar circle sector phase gali area station highway nh bypass and the at in of dist district tehsil tq ta po ps city ward opposite next beside".split(" ")
);
function addressPlaceCandidates(address) {
  const words = String(address || "")
    .replace(/[^A-Za-z\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 3 && !ADDRESS_STOPWORDS.has(w.toLowerCase()));
  const out = [];
  const add = (arr) => {
    const t = arr.join(" ").trim();
    if (t.length >= 4 && !out.some((x) => x.toLowerCase() === t.toLowerCase())) out.push(t);
  };
  for (const n of [2, 1, 3]) if (words.length >= n) add(words.slice(-n));
  for (let end = words.length - 1; end >= 1 && out.length < 8; end--) {
    for (const n of [2, 1]) if (end - n >= 0) add(words.slice(end - n, end));
  }
  return out.slice(0, 8);
}

async function inferLocation(d) {
  const address = d.address || "";
  if (!address) return;
  const low = address.toLowerCase();

  let matchedLocality = null;
  for (const [pattern, city] of LOCALITY_CITY) {
    const m = low.match(pattern);
    if (m) {
      if (!d.city) d.city = city;
      matchedLocality = m[0].replace(/\b\w/g, (c) => c.toUpperCase());
      if (!d.locality) d.locality = matchedLocality;
      break;
    }
  }
  if (!matchedLocality) {
    const sortedCities = [...CITY_NAMES].sort((a, b) => b.length - a.length);
    for (const city of sortedCities) {
      const re = new RegExp(`\\b${city.replace(/ /g, "\\s+")}\\b`, "i");
      if (re.test(address)) {
        if (!d.city) d.city = city;
        break;
      }
    }
  }

  // Pincode: address text (already handled in parseDetails) wins; only hit
  // the network if we still don't have one. Our LOCALITY_CITY/CITY_NAMES
  // tables can never cover every Indian town/taluka (e.g. "Yavatmal" isn't
  // in either), so beyond the resolved locality/city we also try each
  // comma-separated piece of the raw address directly against the pincode
  // API — this covers places our hardcoded lists don't know about.
  if (!d.pincode) {
    const tried = new Set();
    const candidates = [
      d.locality,
      d.city,
      ...address.split(",").map((s) => s.trim()).filter(Boolean),
      ...addressPlaceCandidates(address),
    ];
    for (const candidate of candidates) {
      if (!candidate) continue;
      const key = candidate.toLowerCase();
      if (tried.has(key)) continue;
      tried.add(key);
      const found = await lookupPincode(candidate);
      if (found) {
        d.pincode = found.pincode;
        if (!d.city && found.district) d.city = found.district;
        break;
      }
    }
  }
}

function itemsFromResponse(body) {
  if (Array.isArray(body)) return body;
  if (!body || typeof body !== "object") return [];
  for (const key of ["result", "data", "items", "markets", "brands"]) {
    const value = body[key];
    if (Array.isArray(value)) return value;
    if (value && typeof value === "object") {
      for (const nested of ["data", "items", "result"]) {
        if (Array.isArray(value[nested])) return value[nested];
      }
    }
  }
  return [];
}

function firstPresent(row, keys) {
  if (!row || typeof row !== "object") return null;
  for (const k of keys) {
    if (row[k] !== undefined && row[k] !== null && row[k] !== "") return row[k];
  }
  return null;
}

let session = { loggedIn: false, email: null, reused: false };

function progress(text) {
  chrome.runtime.sendMessage({ action: "PROGRESS", text }, () => void chrome.runtime.lastError);
}

async function clearDomainCookies() {
  const cookies = await chrome.cookies.getAll({ domain: "backoffice.tmbill.com" });
  await Promise.all(
    cookies.map((c) =>
      chrome.cookies.remove({
        url: `https://backoffice.tmbill.com${c.path}`,
        name: c.name,
      })
    )
  );
}

async function getXsrfToken() {
  const cookie = await chrome.cookies.get({ url: BASE_URL, name: "XSRF-TOKEN" });
  return cookie ? decodeURIComponent(cookie.value) : null;
}

async function apiFetch(path, options = {}) {
  const token = await getXsrfToken();
  const headers = {
    Accept: "application/json, text/plain, */*",
    "X-Requested-With": "XMLHttpRequest",
    "Content-Type": "application/json;charset=UTF-8",
    ...(token ? { "X-XSRF-TOKEN": token } : {}),
    ...(options.headers || {}),
  };
  return fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
    credentials: "include",
  });
}

async function readBody(resp) {
  const text = await resp.text();
  let json = null;
  if (text) {
    try {
      json = JSON.parse(text);
    } catch (e) {
      json = null;
    }
  }
  return { text, json };
}

function formatHttpError(action, resp, body) {
  let detail = "";
  const parsed = body && body.json;
  if (parsed && typeof parsed === "object") {
    if (parsed.errors && typeof parsed.errors === "object") {
      const parts = [];
      for (const [field, msgs] of Object.entries(parsed.errors)) {
        parts.push(`${field}: ${Array.isArray(msgs) ? msgs.join("; ") : msgs}`);
      }
      detail = parts.join(" | ");
    }
    if (!detail) detail = String(parsed.message || parsed.error || JSON.stringify(parsed));
  } else if (body && body.text) {
    detail = String(body.text).slice(0, 1000);
  }
  return `${action} failed: HTTP ${resp.status}. ${detail}`.trim();
}

async function sessionLooksValid() {
  // HAR-confirmed authenticated endpoint used by the live Back Office dashboard.
  // Unlike a generic 2xx page load, this endpoint should return JSON only for a valid session.
  try {
    const check = await apiFetch("/api/admin/market-list", { method: "GET" });
    if (check.status < 200 || check.status >= 300) return false;
    const body = await readBody(check);
    return !!(body.json && typeof body.json === "object" && Array.isArray(body.json.result));
  } catch (e) {
    return false;
  }
}

async function login(email, password) {
  // The HAR shows the Back Office login is a normal form POST (not JSON) with
  // _token, user_type=admin, email and password. Fetch the form to obtain a fresh
  // CSRF token, then submit it without clearing the browser's existing cookies.
  const page = await fetch(`${BASE_URL}/login`, {
    method: "GET",
    credentials: "include",
    headers: { Accept: "text/html,application/xhtml+xml" },
  });
  const pageText = await page.text();
  if (!page.ok) throw new Error(`Could not open Back Office login form (HTTP ${page.status}).`);
  const tokenMatch = pageText.match(/name=["']_token["'][^>]*value=["']([^"']+)["']/i)
    || pageText.match(/value=["']([^"']+)["'][^>]*name=["']_token["']/i);
  const csrfToken = tokenMatch ? tokenMatch[1] : null;
  if (!csrfToken) {
    throw new Error("Could not find the Back Office login CSRF token. Open backoffice.tmbill.com/login, sign in manually, then retry.");
  }
  const form = new URLSearchParams({
    _token: csrfToken,
    lat: "",
    lng: "",
    location: "",
    user_type: "admin",
    email: String(email || ""),
    password: String(password || ""),
  });
  const resp = await fetch(`${BASE_URL}/login`, {
    method: "POST",
    credentials: "include",
    redirect: "follow",
    headers: {
      Accept: "text/html,application/xhtml+xml,application/json",
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Requested-With": "XMLHttpRequest",
    },
    body: form.toString(),
  });
  if (!resp.ok) {
    const detail = (await resp.text().catch(() => "")).slice(0, 400);
    throw new Error(`Back Office login failed (HTTP ${resp.status}). ${detail}`);
  }

  let authenticated = false;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) await new Promise((r) => setTimeout(r, 400));
    authenticated = await sessionLooksValid();
    if (authenticated) break;
  }
  if (!authenticated) {
    throw new Error("Login request completed, but Back Office session verification failed. Check the credentials and account access, then retry.");
  }
  session = { loggedIn: true, email, reused: false };
  return { authenticated: true };
}

async function ensureAuth(email, password) {
  if (await sessionLooksValid()) {
    session = { loggedIn: true, email: email || session.email, reused: true };
    return { reused: true };
  }
  if (!email || !password) {
    throw new Error(
      "No backoffice session. First log in to backoffice.tmbill.com, or enter email/password in the Login section."
    );
  }
  progress("Logging in (no existing session)...");
  await login(email, password);
  return { reused: false };
}

async function apiGet(path) {
  const resp = await apiFetch(path, { method: "GET" });
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError(`GET ${path}`, resp, body));
  return body.json && typeof body.json === "object" ? body.json : {};
}

async function findExistingOutlet(d, opts = {}) {
  const wantedName = String(d.outlet_name || "").trim().toLowerCase();
  const wantedPhone = String(d.mobile || "").replace(/\D/g, "");
  const wantedEmail = String(d.email || "").trim().toLowerCase();
  if (!wantedName && !wantedPhone && !wantedEmail) return null;

  const matches = (row) => {
    if (!row || typeof row !== "object") return false;
    const name = String(firstPresent(row, ["name", "outlet_name"]) || "").trim().toLowerCase();
    const phone = String(firstPresent(row, ["contact_phone", "phone"]) || "").replace(/\D/g, "");
    const email = String(firstPresent(row, ["email"]) || "").trim().toLowerCase();
    const exactName = !!wantedName && name === wantedName;
    const exactPhone = !!wantedPhone && phone === wantedPhone;
    const exactEmail = !!wantedEmail && email === wantedEmail;
    if (opts.allowNameOnly && exactName && !wantedPhone && !wantedEmail) return true;
    return (exactName && (exactPhone || exactEmail)) || (exactPhone && exactEmail);
  };

  // Targeted search first: ask TMBill's own list/filter endpoint for the
  // outlet name and phone directly, instead of only blindly paging through
  // the list. On a retry after an earlier failed Save, a partially-created
  // outlet from that attempt can land on any page depending on sort order
  // -- a blind scan capped at 5 pages can miss it entirely on accounts with
  // many outlets, which is exactly why "no matching partially-created
  // outlet was found" could fire even when one genuinely existed.
  for (const q of [d.outlet_name, wantedPhone].filter(Boolean)) {
    try {
      const rows = itemsFromResponse(await apiGet(`/api/admin/outlet?showDeactivated=0&page=1&q=${encodeURIComponent(q)}`));
      for (const row of rows) if (matches(row)) return row;
    } catch (e) {
      /* ignore, fall through to blind scan */
    }
  }

  if (opts.quick) return null;

  const paths = [];
  // Keep scanning until an empty page. Five pages was not enough for
  // accounts with a large outlet list and could miss a partially-created
  // outlet, which then encouraged a duplicate POST.
  for (let page = 1; page <= 50; page++) {
    paths.push(`/api/admin/outlet?showDeactivated=0&page=${page}&q=`);
  }
  paths.push("/api/admin/outlets");

  for (const path of paths) {
    let rows = [];
    try {
      rows = itemsFromResponse(await apiGet(path));
    } catch (e) {
      continue;
    }
    if (!rows.length && path.includes("page=")) break;
    for (const row of rows) {
      if (matches(row)) return row;
    }
  }
  return null;
}

async function findOutletById(id) {
  const wanted = String(id).trim();
  if (!wanted) return null;

  // Try a direct GET first (mirrors the PUT /api/admin/outlet/:id endpoint
  // used for updates) in case the backend supports fetching a single
  // outlet by id.
  try {
    const resp = await apiGet(`/api/admin/outlet/${encodeURIComponent(wanted)}`);
    const direct = resp && resp.data && typeof resp.data === "object" ? resp.data : resp;
    if (direct && typeof direct === "object" && (direct.id || direct.store_id)) return direct;
  } catch (e) {
    /* endpoint may not support single-outlet GET -- fall back to list scan */
  }

  const matchesId = (row) => {
    if (!row || typeof row !== "object") return false;
    const rowId = String(firstPresent(row, ["store_id", "storeId", "id"]) || "").trim();
    return rowId && rowId === wanted;
  };

  try {
    const rows = itemsFromResponse(await apiGet(`/api/admin/outlet?showDeactivated=0&page=1&q=${encodeURIComponent(wanted)}`));
    for (const row of rows) if (matchesId(row)) return row;
  } catch (e) {
    /* ignore, fall through to blind scan */
  }

  const paths = [];
  for (let page = 1; page <= 5; page++) {
    paths.push(`/api/admin/outlet?showDeactivated=0&page=${page}&q=`);
  }
  paths.push("/api/admin/outlets");

  for (const path of paths) {
    let rows = [];
    try {
      rows = itemsFromResponse(await apiGet(path));
    } catch (e) {
      continue;
    }
    if (!rows.length && path.includes("page=")) break;
    for (const row of rows) {
      if (matchesId(row)) return row;
    }
  }
  return null;
}

function storeIdFromOutlet(outlet) {
  if (!outlet || typeof outlet !== "object") return null;
  const direct = firstPresent(outlet, ["store_id", "storeId", "id"]);
  if (direct !== null) return direct;
  for (const key of ["data", "result", "outlet", "store"]) {
    if (outlet[key] && typeof outlet[key] === "object") {
      const nested = storeIdFromOutlet(outlet[key]);
      if (nested !== null) return nested;
    }
  }
  return null;
}

async function createMarket(name) {
  const resp = await apiFetch("/api/admin/market", {
    method: "POST",
    body: JSON.stringify({ id: null, name, tmpos_id: "", market_id: "", default: 0 }),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError("Create market", resp, body));
  const raw = body.json || {};
  const data = raw.data && typeof raw.data === "object" ? raw.data : raw;
  const marketId = firstPresent(data, ["market_id"]);
  if (!marketId) throw new Error("Market was created but market_id not found in response: " + JSON.stringify(raw).slice(0, 500));
  return marketId;
}

// TMBill's brand short_name must be letters/numbers only and <= 15 chars.
// Strip spaces/punctuation from the brand title and truncate accordingly —
// previously this just did title.slice(0, 30) which kept spaces/symbols and
// allowed >15 chars, causing "Create brand failed: HTTP 422" on real names
// like "Anikait Enterprises" or anything with a space/hyphen.
function makeBrandShortName(title) {
  const stripped = String(title || "").replace(/[^a-zA-Z0-9]/g, "");
  return (stripped || "Brand").slice(0, 15);
}

async function createBrand(title, marketId) {
  const shortName = makeBrandShortName(title);
  const resp = await apiFetch("/api/admin/brand", {
    method: "POST",
    body: JSON.stringify({
      id: null,
      title,
      address: null,
      gst_no: null,
      pan_no: null,
      phone: null,
      fssai_no: null,
      is_active: true,
      logo: null,
      short_name: shortName,
      website: null,
      market_id: marketId,
      ga_id: "",
      default: 0,
    }),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError("Create brand", resp, body));
  const data = body.json || {};
  const brandId = firstPresent(data, ["id"]);
  if (!brandId) throw new Error("Brand was created but id not found in response: " + JSON.stringify(data).slice(0, 500));
  return brandId;
}

async function resolveBrandMarket(d) {
  const warnings = [];

  // Market must be resolved before brand — auto-creating a brand needs a market_id.
  if (!d.market_id) {
    let marketRows = [];
    for (const path of ["/api/admin/market?page=1&q=", "/api/admin/market-list"]) {
      let rows = [];
      try {
        rows = itemsFromResponse(await apiGet(path)).filter((x) => x && typeof x === "object");
      } catch (e) {
        rows = [];
      }
      if (rows.length) {
        marketRows = rows;
        break;
      }
    }

    if (d.market_name && marketRows.length) {
      const wanted = d.market_name.trim().toLowerCase();
      for (const row of marketRows) {
        const name = String(firstPresent(row, ["market_name", "name", "market"]) || "").trim().toLowerCase();
        const mid = firstPresent(row, ["market_id", "id"]);
        if (mid !== null && mid !== "" && name === wanted) {
          d.market_id = mid;
          break;
        }
      }
    }

    // Default market name is always "India" when auto-create is on but no name given
    if (d.autoCreateMarket && !d.market_name) d.market_name = "India";
    if (!d.market_id && d.autoCreateMarket && d.market_name) {
      progress(`Creating new market "${d.market_name}"...`);
      try {
        d.market_id = await createMarket(d.market_name);
        warnings.push(`New market "${d.market_name}" created (Market ID ${d.market_id}).`);
      } catch (e) {
        warnings.push(`Market auto-create failed: ${e.message}`);
      }
    }

    if (!d.market_id) {
      const ids = [];
      const seen = new Set();
      for (const row of marketRows) {
        const mid = firstPresent(row, ["market_id", "id"]);
        if (mid !== null && mid !== "" && !seen.has(String(mid))) {
          ids.push(mid);
          seen.add(String(mid));
        }
      }
      if (ids.length === 1) {
        d.market_id = ids[0];
      } else if (ids.length > 1) {
        const match = ids.find((x) => String(x) === String(DEFAULT_MARKET_ID));
        d.market_id = match !== undefined ? match : ids[0];
        warnings.push(`Account has ${ids.length} markets. Using Market ID ${d.market_id}. If wrong, enter Market ID in UI.`);
      }
    }

    if (!d.market_id) {
      d.market_id = DEFAULT_MARKET_ID;
      warnings.push(`Market ID not found, using default ${DEFAULT_MARKET_ID}.`);
    }
  }

  if (!d.brand_id) {
    let brandRows = [];
    for (const path of ["/api/admin/brand-list", "/api/admin/active-stores-brands"]) {
      try {
        const items = itemsFromResponse(await apiGet(path));
        if (items.length) {
          brandRows = items.filter((x) => x && typeof x === "object");
          if (brandRows.length) break;
        }
      } catch (e) {
        continue;
      }
    }

    if (d.brand_name && brandRows.length) {
      const wanted = d.brand_name.trim().toLowerCase();
      for (const row of brandRows) {
        const name = String(firstPresent(row, ["brand_name", "name", "brand"]) || "").trim().toLowerCase();
        const bid = firstPresent(row, ["brand_id", "id"]);
        if (bid !== null && bid !== "" && name === wanted) {
          d.brand_id = bid;
          break;
        }
      }
    }

    if (!d.brand_id) {
      const ids = [];
      const seen = new Set();
      for (const row of brandRows) {
        const bid = firstPresent(row, ["brand_id", "id"]);
        if (bid !== null && bid !== "" && !seen.has(String(bid))) {
          ids.push(bid);
          seen.add(String(bid));
        }
      }
      if (ids.length === 1) {
        d.brand_id = ids[0];
      } else if (ids.length > 1) {
        const match = ids.find((x) => String(x) === String(DEFAULT_BRAND_ID));
        d.brand_id = match !== undefined ? match : ids[0];
        warnings.push(`Account has ${ids.length} brands. Using Brand ID ${d.brand_id}. If wrong, enter Brand ID in UI.`);
      }
    }

    if (!d.brand_id) {
      try {
        const outlets = itemsFromResponse(await apiGet("/api/admin/outlets"));
        const outletBrandIds = [];
        for (const row of outlets) {
          if (row && typeof row === "object") {
            const bid = firstPresent(row, ["brand_id", "brandId"]);
            if (bid !== null && bid !== "" && !outletBrandIds.includes(String(bid))) outletBrandIds.push(String(bid));
          }
        }
        if (outletBrandIds.length === 1) d.brand_id = outletBrandIds[0];
      } catch (e) {
        /* ignore */
      }
    }

    if (!d.brand_id && d.autoCreateBrand && d.brand_name && d.market_id) {
      progress(`Creating new brand "${d.brand_name}"...`);
      try {
        d.brand_id = await createBrand(d.brand_name, d.market_id);
        warnings.push(`New brand "${d.brand_name}" created (Brand ID ${d.brand_id}).`);
      } catch (e) {
        warnings.push(`Brand auto-create failed: ${e.message}`);
      }
    }

    if (!d.brand_id) {
      d.brand_id = DEFAULT_BRAND_ID;
      warnings.push(`Brand ID not found, using default ${DEFAULT_BRAND_ID}.`);
    }
  }

  if (!d.brand_id || !d.market_id) {
    throw new Error("TMBill requires brand_id and market_id. Enter 'Brand ID:' / 'Market ID:' in the message or UI.");
  }
  return warnings;
}

// Computes an epoch-ms timestamp for midnight IST, N days from now — this is
// the same value TMBill's own frontend sends for reset_bill_time/reset_kot_time
// (verified against a captured real save: resetBillAfterDays "1" produced a
// timestamp equal to midnight IST the following day).
function istMidnightDaysAhead(daysAhead) {
  const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000;
  const nowIst = new Date(Date.now() + IST_OFFSET_MS);
  const target = new Date(Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), nowIst.getUTCDate() + daysAhead, 0, 0, 0));
  const epochMs = target.getTime() - IST_OFFSET_MS;
  const dateStr = `${target.getUTCFullYear()}-${String(target.getUTCMonth() + 1).padStart(2, "0")}-${String(target.getUTCDate()).padStart(2, "0")}`;
  return { epochMs, dateStr };
}

// Default value for the nested settings blocks TMBill's outlet-create API
// expects on every save (confirmed from a captured real onboarding session —
// our previous minimal payload omitted all of this, which is the most likely
// cause of the generic "HTTP 500 while saving store data" error: the backend
// almost certainly does unguarded reads/writes into these nested structures
// and has nothing to fall back on when they're entirely absent from the
// request body).
function defaultDigitalOrderingSettings() {
  return {
    items: { description: true, preparation_time: false, show_nutritioninfo: false, show_price_upto_decimal: "2" },
    other: {
      dinein: "0", pickup: "1", loyalty: 0, tagline: "", delivery: "1", language: "en", skip_otp: false,
      sendotpVia: "0", is_grid_view: "1", is_list_view: "0", item_sort_by: 0, category_sort: "1",
      dine_in_title: "dinein", disable_ordernow: 0, card_category_view: 0, enable_subcat_view: 0,
      show_install_popup: 0, show_whatsapp_link: "0", login_with_truecaller: "0", hide_food_type_from_ui: 0,
      enable_collapsible_view: 0, dine_in_title_placeholder: "", ask_for_ordertype_before_placing_order: "0",
    },
    social_media: {
      call: "", show_call: "0", fb: "", show_fb: "0", insta: "", show_insta: "0", website: "", show_website: "0",
      pinterest: "", show_pinterest: "0", linkedin: "", show_linkedin: "0", show_youtube: "0", youtube: "",
    },
    pay_gateway: {
      webhook: { ayu_success_url: "", payu_failure_url: "" },
      dinein: [{ key: "cash", flag: 0, active: 1 }],
      pickup: [{ key: "cash", flag: 0, active: 1 }],
      delivery: [{ key: "cash", flag: 0, active: 1 }],
    },
    sent_msgto_customer: {
      via: "0", order_placed: "0", order_accepted: "0", order_fullfiled: "0", order_cancelled: "0",
      order_food_ready: "0", order_dispatched: "0",
    },
    order_limit: { dinein: "0", pickup: "0", delivery: "0", cod_after_amount: "0" },
    digi_banners: [],
    config: {
      custom_timing: { days: ["0", "1", "2", "3", "4", "5", "6"], every_day: 1, time_slots: [] },
      delivery_areawise_charges: "1",
      assign_deliveryboy_on: "food ready",
      auto_fulfill_on_delivery_done: 0,
    },
    sliding_banners: [],
    payment_window_banner: [],
    order_type_banner: [],
    customer: {
      login_method: "1", show_logo: true, reject_order: "0", order_later: "0", order_later_days_limit: "1",
      order_later_time_slots: [], delivery_within_limit: "5", verify_otp_while_registration: "1",
      promocode: { dinein: "0", pickup: "1", delivery: "1" }, custom_msg_when_store_offline: "",
      ask_for_tip: false, pre_order_start_from: "", pre_order_custom_range: { startDate: "", endDate: "" },
    },
  };
}

function defaultOutletConfig() {
  return {
    whatapp_account_id: 0, notification_channel: "SMS", nextel_key: "", whatapp_channel: "",
    channels_enabled: { zomato: 0, swiggy: 0 }, zatca_integration: 0, captain_user_access: 0,
    roundoff_upto_decimal: 2, enabled_round_off: 0, enable_multipricing: 0, enable_customer_loyalty: 0,
    reelo_integration: 0, bill_number_length: 0, verfy_pos_system_date: 1, ondc_enabled: 0,
    send_reports_via: [1], table_reservation: 0, allowMultipleTax: 0, verify_pos_system_date: 1,
    enable_pos_user_2fa: 0, enable_allergen: 0, redeem_points_with_otp: 0,
  };
}

async function buildOutletPayload(d, outletId) {
  let tmposId = d.tmpos_id;
  if (!tmposId) {
    try {
      const rows = itemsFromResponse(await apiGet("/api/admin/market?page=1&q=")).filter((x) => x && typeof x === "object");
      for (const row of rows) {
        const mid = firstPresent(row, ["market_id", "id"]);
        if (String(mid) === String(d.market_id)) {
          tmposId = firstPresent(row, ["tmpos_id", "tmposId"]);
          if (tmposId) d.tmpos_id = tmposId;
          break;
        }
      }
    } catch (e) {
      /* ignore */
    }
  }

  let startTime = d.day_start_time || "20:00:00";
  let closeTime = d.day_close_time || "23:59:59";
  if (closeTime === "00:00:00") closeTime = "23:59:59";

  const resetBillAfterDays = parseInt(d.resetBillAfterDays || 1, 10);
  const resetKotIndays = parseInt(d.reset_kot_indays || 1, 10);
  const billReset = istMidnightDaysAhead(resetBillAfterDays);
  const kotReset = istMidnightDaysAhead(resetKotIndays);

  return {
    id: outletId ?? null,
    tmpos_id: tmposId !== undefined && tmposId !== null ? String(tmposId) : null,
    name: d.outlet_name,
    country_id: 98,
    timezone: "Asia/Kolkata",
    city: d.city || "",
    locality: d.locality || "",
    contact_phone: d.mobile,
    address: d.address,
    zip_codes: d.pincode,
    market_id: d.market_id,
    brand_id: d.brand_id,
    active: true,
    disable_ordering: 0,
    user_creation_limit: 5,
    reduce_inventory: true,
    day_start_time: startTime,
    day_close_time: closeTime,
    resetBillAfterDays,
    reset_kot_indays: resetKotIndays,
    email: d.email,

    // Fields below were absent from the previous minimal payload. A captured
    // real onboarding session confirms TMBill's frontend always sends these
    // on outlet save — their absence is the most likely cause of the
    // generic "HTTP 500 while saving store data" error, since the backend
    // very likely reads/writes these nested structures unconditionally.
    min_pickup_time: "",
    min_delivery_time: "",
    min_order_value: "",
    notification_emails: "",
    geo_longitude: "",
    geo_latitude: "",
    warehouse_id: 0,
    logo: "",
    reset_bill_time: billReset.epochMs,
    reset_kot_time: kotReset.epochMs,
    description: d.description || "",
    next_bill_reset_dates: null,
    send_payment_link: "",
    custom_qr_codes: { qrcodes: [] },
    logout_after_close_pos_app: true,
    next_reset_dates: {
      nextkotresetDate: kotReset.epochMs,
      nextbillresetDate: billReset.epochMs,
      resetKotafterdays: String(resetKotIndays),
      resetBillafterdays: String(resetBillAfterDays),
    },
    dateRange: { startDate: billReset.dateStr, endDate: billReset.dateStr },
    dateRangeKot: { startDate: kotReset.dateStr, endDate: kotReset.dateStr },
    send_ebill_link_on_whatsapp: "0",
    enabled_passcode_protection: "1",
    upsale_config: { upsale_integrated: 1 },
    outlet_code: "",
    pdam_start_time: 0,
    pdam_end_time: 6,
    tenant_id: 0,
    is_feedback_active: 0,
    digital_ordering_settings: defaultDigitalOrderingSettings(),
    gst_no: d.gst || "",
    config: defaultOutletConfig(),
    show_phone_on_bill: "",
  };
}

async function postOutlet(payload) {
  const resp = await apiFetch("/api/admin/outlet", { method: "POST", body: JSON.stringify(payload) });
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError("Save outlet", resp, body));
  if (body.json) return body.json;
  throw new Error(`Save outlet returned HTTP ${resp.status} with a non-JSON response: ${String(body.text).slice(0, 1000)}`);
}

async function createOutlet(d, payload) {
  try {
    return await postOutlet(payload);
  } catch (exc) {
    // Two situations land here where the outlet may have actually been
    // created despite postOutlet() throwing:
    //   1. A genuine server-side HTTP 500 (existing handling).
    //   2. HTTP 2xx with a non-JSON body ("non-JSON response" message from
    //      postOutlet). TMBill's create endpoint, like its PUT endpoint,
    //      can return 200 with an empty/HTML body on a real success -- so
    //      previously this was rethrown immediately without ever checking
    //      whether the outlet exists, surfacing as a raw "non-JSON
    //      response" error even when the outlet was created fine.
    const msg = String(exc.message);
    const ambiguous2xx = /non-JSON response/.test(msg) && !/HTTP [45]\d\d/.test(msg);
    if (!msg.includes("HTTP 500") && !ambiguous2xx) throw exc;

    let existing = await findExistingOutlet(d);
    if (!existing && ambiguous2xx) {
      // A 2xx response almost certainly means TMBill's backend accepted the
      // create -- any "not found" here is more likely list-endpoint /
      // search-index lag than a real failure, unlike a genuine HTTP 500
      // where the create very likely did NOT go through. So give the
      // lookup one more try after a short pause instead of immediately
      // assuming failure.
      await new Promise((r) => setTimeout(r, 1200));
      existing = await findExistingOutlet(d);
    }
    if (existing) {
      return { data: existing, store_id: storeIdFromOutlet(existing), already_created: true };
    }

    if (ambiguous2xx) {
      // Do NOT retry the create here: TMBill returned a 2xx, so the first
      // POST likely already succeeded server-side even though we can't
      // find it in the list yet. Blindly re-posting risks creating a
      // duplicate outlet. Surface a clear message instead and let the
      // user check backoffice / retry the lookup manually.
      throw new Error(
        `${msg} | TMBill returned HTTP 2xx (likely a real success) but the outlet couldn't be found yet via search -- ` +
          `check backoffice.tmbill.com for "${d.outlet_name || ""}" before retrying, so we don't create a duplicate outlet.`
      );
    }

    const alt = { ...payload };
    delete alt.email;
    try {
      return await postOutlet(alt);
    } catch (exc2) {
      const existing2 = await findExistingOutlet(d);
      if (existing2) {
        return { data: existing2, store_id: storeIdFromOutlet(existing2), already_created: true };
      }
      throw new Error(`${exc2.message} | TMBill returned a server-side 500 and no matching partially-created outlet was found.`);
    }
  }
}

async function updateOutlet(payload) {
  // Test Mode must NEVER hit the create endpoint (POST /api/admin/outlet) —
  // it should only ever PUT to the known demo outlet's own id. The previous
  // version tried postOutlet() (a real create) first and only fell back to
  // PUT on failure, which is exactly backwards for Test Mode and is why a
  // "creation limit exceeded" error showed up even with Test Mode on.
  const id = payload.id;
  if (!id) throw new Error("Test Mode outlet update requires a Demo Outlet / Store ID.");

  const resp = await apiFetch(`/api/admin/outlet/${encodeURIComponent(String(id))}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError("Update outlet", resp, body));
  if (body.json) return body.json;

  // TMBill's PUT endpoint can return HTTP 200 with an empty/non-JSON body on
  // a genuine success. Since we already know the outlet id we're updating,
  // treat any 2xx here as success instead of throwing.
  return { data: { store_id: id, id }, store_id: id, id, raw: String(body.text || "").slice(0, 500) };
}

async function createUser(d, storeId) {
  const payload = {
    id: null,
    username: d.username,
    store_id: storeId,
    phone: d.mobile,
    name: d.owner_name,
    email: d.email,
    password: d.password,
    designation: d.designation || "manager",
    type: 17070,
    shift_time: null,
    IsActive: 1,
    photo: "",
    userCategory: 0,
    is_web_panel_permission: 1,
    is_captain_app: false,
    is_kds_app: false,
    is_self_order: false,
    is_terminal_app: 0,
    has_hub_access: false,
    is_multiple_stores: [],
  };

  const resp = await apiFetch("/api/admin/user", { method: "POST", body: JSON.stringify(payload) });
  const body = await readBody(resp);
  if (resp.status >= 400) {
    const err = formatHttpError("Create owner/manager user", resp, body);
    if (resp.status === 409 || resp.status === 422 || /already|exist|taken|duplicate/i.test(err)) {
      return { already_created: true, warning: err, data: body.json };
    }
    throw new Error(err);
  }
  return body.json || {};
}

// Extra users (POS billing, captain, KDS, OrderHub ...). One request per user, same
// endpoint as the owner/manager user. Never aborts the batch on one failure.
async function createExtraUsers(d, storeId) {
  const users = Array.isArray(d.extraUsers) ? d.extraUsers : [];
  if (!users.length) throw new Error("No users to create - add at least one user row");
  const check = userValidate(users, d.username);
  if (check.errors.length) throw new Error(check.errors.join("; "));
  const ctx = { storeId, mobile: d.mobile, email: d.email };
  const created = [];
  const already = [];
  const failed = [];
  for (let i = 0; i < users.length; i++) {
    const u = users[i];
    const label = userTypeByKey(u.typeKey).label;
    // The automatic POS user starts with the Back Office username; if it is taken it becomes name1, name2 ...
    const baseName = u.username;
    let attempt = 0;
    for (;;) {
      const cur = attempt === 0 ? u : { ...u, username: `${baseName}${attempt}` };
      const payload = userBuildPayload(cur, ctx);
      progress(`Creating user ${i + 1}/${users.length}: ${payload.username}...`);
      try {
        const resp = await apiFetch("/api/admin/user", { method: "POST", body: JSON.stringify(payload) });
        const body = await readBody(resp);
        if (resp.status >= 400) {
          const err = formatHttpError(`Create user "${payload.username}"`, resp, body);
          const taken = resp.status === 409 || resp.status === 422 || /already|exist|taken|duplicate/i.test(err);
          if (taken && u._defaultPos && attempt < 9) { attempt++; continue; }
          if (taken) already.push({ username: payload.username, label, reason: err });
          else failed.push({ username: payload.username, label, error: err });
        } else {
          created.push({ username: payload.username, password: u.password, label, pos: !!u._defaultPos, warnings: userEcho(body.json, payload) });
        }
      } catch (e) {
        failed.push({ username: payload.username, label, error: String((e && e.message) || e) });
      }
      break;
    }
    if (i < users.length - 1) await new Promise((r) => setTimeout(r, 300));
  }
  return { created, already, failed };
}

const OUTLET_REQUIRED = ["outlet_name", "address", "pincode"];
const USER_REQUIRED = ["owner_name", "username", "password"]; // mobile + email are optional (but taken if present)

function requiredFields(d, testMode, resumeMode) {
  // Most fields are optional (partial onboarding: tables only, etc).
  // But when the message clearly asks for an outlet (name/address given) or
  // for a login (username/password given), the fields those steps need must be
  // there -- otherwise they'd be skipped silently (or fail halfway).
  const need = [];
  if (!(testMode || resumeMode || d.store_id) && (d.outlet_name || d.address)) need.push(...OUTLET_REQUIRED);
  if (d.username || d.password) need.push(...USER_REQUIRED);
  return need.filter((k) => !String(d[k] || "").trim());
}

async function prepareOnboarding(d) {
  const testMode = !!d.testMode;
  const testOutletId = String(d.testOutletId || "").trim();
  const resumeStoreId = String(d.resumeStoreId || "").trim();
  const resumeMode = !!resumeStoreId;
  if (testMode && !testOutletId) throw new Error("For Test Mode, Demo Outlet / Store ID is required.");
  if (testMode && resumeMode) throw new Error("Test Mode and Resume mode cannot be used together.");

  // Auto-detect city/locality/pincode from the address BEFORE checking
  // required fields — previously this check ran first, so a pincode that
  // could have been auto-filled from the locality/city was never given the
  // chance to fill in, and onboarding failed with "Missing: pincode" even
  // when the address clearly implied one.
  progress("Detecting city/pincode from address...");
  await inferLocation(d);

  // ALL FIELDS ARE OPTIONAL - Allow partial onboarding
  // Users can run with ANY combination of data
  // Example: Tables only, Outlet only, User only, etc.
  progress("Checking backoffice session...");
  const auth = await ensureAuth(d.masterEmail, d.masterPassword);

  // Outlet fields needed to CREATE an outlet. If some are missing, first check
  // whether this outlet already exists in backoffice (name + phone/email
  // match). If it does, reuse it (same as Resume mode) so user/tables/etc.
  // still run. Only if it does NOT exist do we block -- and we do it BEFORE
  // brand/market get created, so nothing is left half-done.
  const missing = requiredFields(d, testMode, resumeMode);
  if (missing.length && !resumeMode) {
    progress("Outlet details incomplete - checking if outlet already exists...");
    let existing = null;
    try {
      existing = await findExistingOutlet(d, { allowNameOnly: true });
    } catch (e) {
      existing = null;
    }
    const existingId = existing ? String(storeIdFromOutlet(existing) || "").trim() : "";
    const stillMissing = missing.filter((k) => !OUTLET_REQUIRED.includes(k));
    if (existingId && stillMissing.length) {
      throw new Error(
        "Missing: " + stillMissing.map((k) => FIELD_LABELS[k] || k).join(", ") + ". Fill them in and run again."
      );
    }
    if (existingId) {
      return {
        testMode: false,
        resumeStoreId: existingId,
        authReused: auth.reused,
        warnings: [`Outlet "${d.outlet_name}" already exists (Store ID ${existingId}). Using it - outlet create will be skipped.`],
        outletPayload: null,
        details: {},
      };
    }
    throw new Error(
      "The outlet cannot be created - missing: " +
        missing.map((k) => FIELD_LABELS[k] || k).join(", ") +
        ". Fill them in (enter the pincode manually if it could not be detected) and run again."
    );
  }

  if (resumeMode) {
    // Nothing to resolve/build for the outlet itself in resume mode -- the
    // Store ID is used as-is at commit time and createUser() doesn't need
    // brand/market/outlet payload fields.
    return {
      testMode: false,
      resumeStoreId,
      authReused: auth.reused,
      warnings: auth.reused ? ["Using existing backoffice session (tab was not logged out)."] : [],
      outletPayload: null,
      details: {},
    };
  }

  progress("Resolving brand / market...");
  const warnings = await resolveBrandMarket(d);
  if (auth.reused) warnings.unshift("Using existing backoffice session (tab was not logged out).");

  const outletId = testMode ? testOutletId : null;
  const outletPayload = await buildOutletPayload(d, outletId);
  return {
    testMode,
    testOutletId,
    authReused: auth.reused,
    warnings,
    outletPayload,
    details: {
      brand_id: d.brand_id,
      market_id: d.market_id,
      tmpos_id: d.tmpos_id,
      city: d.city,
      locality: d.locality,
      pincode: d.pincode,
    },
  };
}

async function commitOnboarding(d, prepared) {
  await ensureAuth(d.masterEmail, d.masterPassword);
  // Apply the already-resolved city/locality/pincode from Prepare first, so
  // inferLocation() below only needs to fill in anything still missing
  // instead of re-doing (and possibly re-fetching) work Prepare already did.
  Object.assign(d, prepared.details || {});
  await inferLocation(d);

  const testMode = !!(prepared.testMode || d.testMode);
  const resumeStoreId = String(prepared.resumeStoreId || d.resumeStoreId || "").trim();
  const payload = prepared.outletPayload;
  if (!payload && !resumeStoreId) throw new Error("Prepared payload missing. Try again.");

  // OPTIONAL: Create outlet only if we have the necessary data
  let outlet = null;
  let storeId = null;
  const hasOutletData = !!(d.outlet_name && d.address && d.pincode);
  
  if (hasOutletData) {
    if (testMode) {
      progress(`Updating demo outlet ${payload.id}...`);
      outlet = await updateOutlet(payload);
    } else if (resumeStoreId) {
      progress(`Resuming from existing outlet ${resumeStoreId} (no create call made)...`);
      const existingData = await findOutletById(resumeStoreId);
      if (!existingData) {
        throw new Error(
          `Store ID ${resumeStoreId} not found in backoffice. Verify the Store ID is correct and open that outlet on backoffice.tmbill.com to check.`
        );
      }
      outlet = { data: existingData, store_id: storeIdFromOutlet(existingData) || resumeStoreId, already_created: true };
    } else {
      progress("Creating outlet...");
      outlet = await createOutlet(d, payload);
    }
    storeId = outlet && outlet.store_id ? outlet.store_id : storeIdFromOutlet(outlet) || (testMode ? payload.id : null);
    if (!storeId) {
      throw new Error("Outlet API returned success but no store_id was found: " + JSON.stringify(outlet).slice(0, 1200));
    }
  } else {
    // Try to get storeId from resumeStoreId or testOutletId if outlet creation skipped
    const testOutletId = String(prepared.testOutletId || d.testOutletId || "").trim();
    storeId = resumeStoreId || (testMode ? testOutletId : "") || d.store_id;
    if (!storeId) {
      progress("⚠️ Skipping outlet creation - missing outlet data (outlet_name, address, pincode)");
    }
  }

  // OPTIONAL: Create user only if we have the necessary data
  let user = null;
  let userSkipped = false;
  const hasUserData = !!(d.owner_name && d.email && d.password && d.mobile && d.username);
  
  if (!hasUserData) {
    userSkipped = true;
    progress("⚠️ Skipping user creation - missing user data (owner_name, email, password, mobile, username)");
  } else if (testMode) {
    userSkipped = true;
  } else {
    if (storeId) {
      progress("Creating owner/manager user...");
      user = await createUser(d, storeId);
    } else {
      progress("⚠️ Cannot create user - no store_id available");
      userSkipped = true;
    }
  }

  d.store_id = storeId;
  d.user_response = user;
  await inferLocation(d);
  return { details: d, userSkipped, alreadyCreatedUser: !!(user && user.already_created) };
}

// ─────────────────────────────────────────────────────────────────────────
// FULL SETUP — optional steps run after outlet + owner user are created:
// POS table department/tables, default menu, payment modes, digital
// ordering, and an owner/manager designation record. Each step is
// independent and best-effort: one failing doesn't stop the others.
// ─────────────────────────────────────────────────────────────────────────

async function ensurePosTableDept(storeId, deptName) {
  const wanted = deptName.trim().toLowerCase();
  const rows = itemsFromResponse(await apiGet(`/api/admin/tmpos-table-dept?store_id=${encodeURIComponent(storeId)}&is_active=1`));
  for (const row of rows) {
    const name = String(firstPresent(row, ["department_name"]) || "").trim().toLowerCase();
    if (name === wanted) return firstPresent(row, ["id", "department_id"]);
  }

  const resp = await apiFetch("/api/admin/tmpos-table-dept", {
    method: "POST",
    body: JSON.stringify({
      id: "",
      store_id: String(storeId),
      department_name: deptName,
      is_active: "1",
      section: "1",
      product_groups: [],
    }),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) {
    const err = formatHttpError("Create table department", resp, body);
    if (!/already|exist|taken|duplicate/i.test(err)) throw new Error(err);
  }

  // TMBill returns an empty body on success here, so re-fetch to find the new id.
  const rows2 = itemsFromResponse(await apiGet(`/api/admin/tmpos-table-dept?store_id=${encodeURIComponent(storeId)}&is_active=1`));
  for (const row of rows2) {
    const name = String(firstPresent(row, ["department_name"]) || "").trim().toLowerCase();
    if (name === wanted) return firstPresent(row, ["id", "department_id"]);
  }
  throw new Error("Table department was created but then could not be found.");
}

// NEW: List all existing table departments for an outlet, for the UI dropdown.
async function listPosTableDepartments(storeId) {
  try {
    const rows = itemsFromResponse(await apiGet(`/api/admin/tmpos-table-dept?store_id=${encodeURIComponent(storeId)}&is_active=1`));
    return rows.map((row) => ({
      id: firstPresent(row, ["id", "department_id"]),
      name: firstPresent(row, ["department_name"]) || "Unnamed",
    })).filter((d) => d.id);
  } catch (e) {
    return [];
  }
}

// NEW: List outlets the logged-in user can access, for the outlet dropdown.
async function listOutlets() {
  try {
    const rows = itemsFromResponse(await apiGet(`/api/admin/outlet?limit=200`));
    return rows.map((row) => ({
      store_id: firstPresent(row, ["store_id", "id"]),
      outlet_name: firstPresent(row, ["outlet_name", "name"]) || "Unnamed Outlet",
    })).filter((o) => o.store_id);
  } catch (e) {
    return [];
  }
}

async function findPosTables(storeId, deptId) {
  try {
    const rows = itemsFromResponse(await apiGet(`/api/admin/tmpos-tables?store_id=${encodeURIComponent(storeId)}`));
    return rows.filter((row) => {
      const rowStore = firstPresent(row, ["store_id", "storeId", "outlet_id"]);
      const rowDept = firstPresent(row, ["department", "department_id", "dept_id"]);
      return String(rowStore || storeId) === String(storeId) && (!deptId || !rowDept || String(rowDept) === String(deptId));
    });
  } catch (e) {
    // Older backoffice versions do not expose a list route. Creation can
    // still proceed, and duplicate responses are handled below.
    return [];
  }
}

async function createPosTable(storeId, deptId, tableName, maxPerson) {
  const resp = await apiFetch("/api/admin/tmpos-tables", {
    method: "POST",
    body: JSON.stringify({
      id: null,
      store_id: String(storeId),
      table_name: tableName,
      isactive: 1,
      max_person: String(maxPerson || 2),
      department: deptId,
    }),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) {
    const err = formatHttpError(`Create table "${tableName}"`, resp, body);
    if (/already|exist|taken|duplicate/i.test(err)) return { already_created: true };
    throw new Error(err);
  }
  return { already_created: false };
}

async function setupPosTables(d, storeId) {
  // Department is resolved purely by name (typed directly by the user in
  // the popup) — existing department with that name is reused, otherwise
  // a new one is created. No id-based selection, no auto-detection.
  const deptName = (d.posDeptName || "Dine In").trim() || "Dine In";
  progress(`Setting up POS tables ("${deptName}")...`);
  const deptId = await ensurePosTableDept(storeId, deptName);

  const existing = await findPosTables(storeId, deptId);
  const existingNames = new Set(
    existing
      .map((row) => String(firstPresent(row, ["table_name", "name"]) || "").trim().toLowerCase())
      .filter(Boolean)
  );

  // Table names: if the user typed an explicit comma-separated list
  // (d.tableNames), that list is authoritative — used exactly as typed,
  // and its length IS the table count (no mixing with posTableCount).
  // Otherwise fall back to the old "Table 1, Table 2, ..." default using
  // posTableCount.
  const customNames = Array.isArray(d.tableNames) && d.tableNames.length ? d.tableNames : null;
  const tableCount = customNames
    ? customNames.length
    : Math.max(1, Math.min(100, parseInt(d.posTableCount, 10) || 4));

  let createdCount = 0;
  let existingCount = 0;
  for (let i = 1; i <= tableCount; i++) {
    const tableName = customNames ? customNames[i - 1] : `Table ${i}`;
    if (!tableName) continue;
    if (existingNames.has(tableName.toLowerCase())) {
      existingCount++;
      continue;
    }
    const result = await createPosTable(storeId, deptId, tableName, 4);
    if (result.already_created) existingCount++;
    else createdCount++;
  }
  return { deptName, tableCount, createdCount, existingCount };
}

// Returns the menu rows for an outlet, or null if the list can't be read.
async function listMenus(storeId, menuName) {
  // Same call the backoffice "Outlet Menu" page makes:
  //   GET /api/admin/outlet-menu?page=1&q=<name>&outlet_id=<id>
  // Rows carry their own store_id, so we filter by it again on our side.
  try {
    return itemsFromResponse(
      await apiGet(`/api/admin/outlet-menu?page=1&q=${encodeURIComponent(menuName || "")}&outlet_id=${encodeURIComponent(storeId)}`)
    );
  } catch (e) {
    return null;
  }
}

function menuRowMatches(row, storeId, menuName) {
  const rowStore = firstPresent(row, ["store_id", "storeId", "outlet_id"]);
  const name = String(firstPresent(row, ["menu_name", "name"]) || "").trim().toLowerCase();
  // A row without a store_id can't be proven to belong to this outlet.
  return rowStore !== null && String(rowStore) === String(storeId) && name === menuName.toLowerCase();
}

async function findMenu(storeId, menuName) {
  const rows = await listMenus(storeId, menuName);
  return (rows && rows.find((row) => menuRowMatches(row, storeId, menuName))) || null;
}

async function setupMenu(d, storeId) {
  const menuName = (d.posMenuName || "POS Menu").trim() || "POS Menu";
  progress(`Creating menu "${menuName}"...`);
  if (await findMenu(storeId, menuName)) return { menuName, already_created: true };
  const resp = await apiFetch("/api/admin/outlet-menu", {
    method: "POST",
    body: JSON.stringify({
      id: null,
      store_id: String(storeId),
      default_flag: "1",
      is_digital_menu: "0",
      default_digi_menu: "0",
      default_kiosk_menu: "0",
      menu_name: menuName,
      is_orderingapp_menu: 0,
      is_ondc_menu: 0,
      short_name: menuName,
      menu_items: [],
    }),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) {
    const err = formatHttpError("Create menu", resp, body);
    if (/already|exist|taken|duplicate/i.test(err)) return { menuName, already_created: true };
    throw new Error(err);
  }
  // The backoffice answers 201 with the new menu (incl. its id). No id => not created.
  const created = body && body.json && typeof body.json === "object" ? body.json : null;
  if (created && (created.id || created.menu_id)) return { menuName, already_created: false, id: created.id || created.menu_id };
  const rows = await listMenus(storeId, menuName);
  if (rows && rows.some((row) => menuRowMatches(row, storeId, menuName))) return { menuName, already_created: false };
  throw new Error(
    `Menu "${menuName}": the create request returned no menu ID (HTTP ${resp.status}) and the menu is not in the menu list of outlet ${storeId} either. ` +
      `Response: ${String((body && body.text) || "").slice(0, 200)}`
  );
}

const DEFAULT_PAYMENT_MODE_NAMES = ["Cash", "Card", "GooglePay", "Paytm", "Credit"];

const PAYMENT_ALIASES = {
  googlepay: ["googlepay", "gpay", "googlepe"],
  gpay: ["googlepay", "gpay", "googlepe"],
  card: ["card", "creditcard", "debitcard", "creditdebitcard", "cards"],
  upi: ["upi", "bhimupi"],
  cash: ["cash"],
  paytm: ["paytm", "paytmwallet"],
  phonepe: ["phonepe", "phonepay"],
};
const normPay = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");

// masterKeys: normalised names the backoffice really has. A wanted name that exists there
// matches EXACTLY ("Card" must not also pull in "Credit Card"); fuzzy aliases
// (GPay = GooglePay ...) are only a fallback for names the master list doesn't have.
function wantedPaymentKeys(d, masterKeys) {
  const names = Array.isArray(d.paymentModes) && d.paymentModes.length ? d.paymentModes : DEFAULT_PAYMENT_MODE_NAMES;
  const exactOnly = !!d.paymentMasterLoaded;
  const keys = new Set();
  const perName = {};
  for (const n of names) {
    const k = normPay(n);
    const exact = exactOnly || (masterKeys && masterKeys.has(k));
    const group = new Set(exact ? [k] : [k, ...(PAYMENT_ALIASES[k] || [])]);
    perName[n] = group;
    group.forEach((x) => keys.add(x));
  }
  return { names, keys, perName };
}

// Works out (without changing anything) which payment modes would be added.
async function planPaymentModes(d, storeId) {
  const current = await apiGet(`/api/admin/outlet-payment-modes?outlet_id=${encodeURIComponent(storeId)}`);
  const master = Array.isArray(current.ItemSourceList) ? current.ItemSourceList : [];
  const already = Array.isArray(current.user_selected_payment_mode) ? current.user_selected_payment_mode : [];
  const alreadyIds = new Set(already.map((m) => String(firstPresent(m, ["payment_mode_id", "id"]))));
  const { names, keys, perName } = wantedPaymentKeys(d, new Set(master.map((m) => normPay(m.payment_mode_name))));

  const selected = [];
  const remaining = [];
  const matchedKeys = new Set();
  for (const row of master) {
    const id = firstPresent(row, ["payment_mode_id", "id"]);
    if (alreadyIds.has(String(id))) continue;
    const nk = normPay(row.payment_mode_name);
    if (keys.has(nk)) {
      matchedKeys.add(nk);
      selected.push({
        id,
        payment_mode_name: row.payment_mode_name,
        payment_mode_image: row.payment_mode_image || "",
        is_active: 1,
        payment_mode_id: id,
        store_id: String(storeId),
      });
    } else {
      remaining.push(row);
    }
  }
  const alreadyKeys = new Set(already.map((m) => normPay(m.payment_mode_name)));
  const notFound = names.filter((n) => {
    const g = [...perName[n]];
    return !g.some((x) => matchedKeys.has(x) || alreadyKeys.has(x));
  });
  return {
    already,
    selected,
    remaining,
    notFound,
    availableNames: master.map((m) => m.payment_mode_name).filter(Boolean),
    alreadyNames: already.map((m) => m.payment_mode_name).filter(Boolean),
  };
}

// Every payment mode the backoffice offers (plus what the outlet already has),
// so the popup can show a real selection list.
async function listPaymentModeNames(storeId) {
  const cur = await apiGet(`/api/admin/outlet-payment-modes?outlet_id=${encodeURIComponent(storeId)}`);
  const master = Array.isArray(cur.ItemSourceList) ? cur.ItemSourceList : [];
  const chosen = Array.isArray(cur.user_selected_payment_mode) ? cur.user_selected_payment_mode : [];
  const names = [];
  for (const row of [...master, ...chosen]) {
    const n = String((row && row.payment_mode_name) || "").trim();
    if (n && !names.some((x) => x.toLowerCase() === n.toLowerCase())) names.push(n);
  }
  return { names, selected: chosen.map((m) => String(m.payment_mode_name || "")).filter(Boolean) };
}

async function setupPaymentModes(d, storeId) {
  progress("Setting up payment modes...");
  const plan = await planPaymentModes(d, storeId);
  const { already, selected, remaining, notFound } = plan;

  if (!selected.length) {
    if (notFound.length && !plan.alreadyNames.length) {
      // Nothing matched and nothing was set before: this is a real failure, not "all done".
      throw new Error(
        `Payment modes did not match: ${notFound.join(", ")}. The master list has: ${plan.availableNames.join(", ") || "(empty)"}`
      );
    }
    return { added: [], notFound, already: plan.alreadyNames };
  }

  const resp = await apiFetch("/api/admin/outlet-payment-modes", {
    method: "PUT",
    body: JSON.stringify({
      id: null,
      outlet_id: String(storeId),
      UserSelectedPaymentModes: [...already, ...selected],
      ItemSourceList: remaining,
    }),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError("Set payment modes", resp, body));

  // Verify it actually stuck.
  try {
    const after = await apiGet(`/api/admin/outlet-payment-modes?outlet_id=${encodeURIComponent(storeId)}`);
    const afterIds = new Set(
      (Array.isArray(after.user_selected_payment_mode) ? after.user_selected_payment_mode : []).map((m) =>
        String(firstPresent(m, ["payment_mode_id", "id"]))
      )
    );
    const missingAfter = selected.filter((x) => !afterIds.has(String(x.id)));
    if (missingAfter.length === selected.length) {
      throw new Error(
        `The payment modes save request was accepted (HTTP ${resp.status}) but they do not show on outlet ${storeId}. Please check the backoffice.`
      );
    }
  } catch (e) {
    if (/save request accept hui/.test(e.message)) throw e;
  }
  return { added: selected.map((x) => x.payment_mode_name), notFound, already: plan.alreadyNames };
}

async function findDigitalOrderSettingsId(storeId, outletName) {
  const queries = [`?page=1&q=${encodeURIComponent(outletName || "")}`, "?page=1&q="];
  for (const q of queries) {
    try {
      const rows = itemsFromResponse(await apiGet(`/api/admin/digital-order-settings${q}`));
      for (const row of rows) {
        if (String(firstPresent(row, ["store_id"])) === String(storeId)) {
          return firstPresent(row, ["id"]);
        }
      }
    } catch (e) {
      /* try next query */
    }
  }
  return null;
}

async function setupDigitalOrdering(d, storeId) {
  progress("Enabling digital ordering (pickup + delivery)...");
  const settingsId = await findDigitalOrderSettingsId(storeId, d.outlet_name);
  if (!settingsId) throw new Error("Digital order settings record not found for this outlet.");

  let closeTime = d.day_close_time || "23:59:00";
  if (closeTime === "00:00:00") closeTime = "23:59:00";

  const payload = {
    id: settingsId,
    store_id: String(storeId),
    name: d.outlet_name,
    digi_notification: 1,
    digital_ordering: "1",
    day_start_time: d.day_start_time || "08:00:00",
    day_close_time: closeTime,
    dunzo_delivery_enabled: "0",
    digi_whatsapp_no: "0",
    digi_whatsapp_msg: null,
    enbl_digi_inventory: 0,
    digital_ordering_settings: {
      items: { description: true, preparation_time: false, show_nutritioninfo: false, show_price_upto_decimal: "2" },
      other: {
        dinein: "0",
        pickup: "1",
        loyalty: 0,
        tagline: null,
        delivery: "1",
        language: "en",
        skip_otp: false,
        sendotpVia: "0",
        is_grid_view: "1",
        is_list_view: "0",
        item_sort_by: 0,
        category_sort: "1",
        dine_in_title: "dinein",
        disable_ordernow: 0,
        card_category_view: 0,
        enable_subcat_view: 0,
        show_install_popup: 0,
        show_whatsapp_link: "0",
        login_with_truecaller: "0",
        hide_food_type_from_ui: 0,
        enable_collapsible_view: 0,
        dine_in_title_placeholder: null,
        ask_for_ordertype_before_placing_order: "0",
      },
      config: {
        custom_timing: { days: ["0", "1", "2", "3", "4", "5", "6"], every_day: 1, time_slots: [] },
        assign_deliveryboy_on: "food ready",
        delivery_areawise_charges: "1",
        auto_fulfill_on_delivery_done: 0,
      },
      customer: {
        promocode: { dinein: "0", pickup: "1", delivery: "1" },
        show_logo: true,
        ask_for_tip: false,
        order_later: "0",
        login_method: "1",
        reject_order: "0",
        pre_order_start_from: null,
        delivery_within_limit: "5",
        order_later_days_limit: "1",
        order_later_time_slots: [],
        pre_order_custom_range: { endDate: null, startDate: null },
        custom_msg_when_store_offline: null,
        verify_otp_while_registration: "1",
      },
      order_limit: { dinein: "0", pickup: "0", delivery: "0", cod_after_amount: "0" },
      pay_gateway: {
        webhook: { ayu_success_url: null, payu_failure_url: null },
        dinein: [{ flag: 0, key: "cash", active: 1 }],
        pickup: [{ flag: 0, key: "cash", active: 1 }],
        delivery: [{ flag: 0, key: "cash", active: 1 }],
      },
      digi_banners: [],
      social_media: {
        fb: null,
        call: null,
        insta: null,
        show_fb: "0",
        website: null,
        youtube: null,
        linkedin: null,
        pinterest: null,
        show_call: "0",
        show_insta: "0",
        show_website: "0",
        show_youtube: "0",
        show_linkedin: "0",
        show_pinterest: "0",
      },
      sliding_banners: [],
      order_type_banner: [],
      sent_msgto_customer: {
        via: "0",
        order_placed: "0",
        order_accepted: "0",
        order_cancelled: "0",
        order_fullfiled: "0",
        order_dispatched: "0",
        order_food_ready: "0",
      },
      payment_window_banner: [],
      table_ordering: { skip_otp: false, allow_request_assistance: false, request_assistance_types: [], show_pay: false },
      pages: {},
    },
    aboutUs: "",
  };

  const resp = await apiFetch(`/api/admin/digital-order-settings/${settingsId}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError("Enable digital ordering", resp, body));
  return { settingsId };
}

async function ensureDesignation(name) {
  const resp = await apiFetch("/api/admin/designation", {
    method: "POST",
    body: JSON.stringify({ id: null, name, active: 1 }),
  });
  const body = await readBody(resp);
  if (resp.status >= 400) {
    const err = formatHttpError("Create designation", resp, body);
    if (resp.status === 409 || resp.status === 422 || /already|exist|taken|duplicate/i.test(err)) {
      return { already_created: true };
    }
    throw new Error(err);
  }
  return body.json || {};
}

// Reads the REAL outlet (name / brand / market / tmpos / currency ...) from
// backoffice and fills anything missing in `d`. Needed when Full Setup runs on
// an already-existing outlet picked from the dropdown: in that case the
// pasted-message fields (outlet_name, brand_id, market_id ...) were never
// resolved, so discounts were created with an EMPTY outlet assignment.
async function hydrateOutletContext(d, storeId) {
  let row = null;
  try {
    row = await findOutletById(storeId);
  } catch (e) {
    row = null;
  }
  if (!row || typeof row !== "object") return null;
  if (row.data && typeof row.data === "object" && !Array.isArray(row.data)) row = row.data;
  d._outlet = row;
  const pickId = (k) => {
    let v = firstPresent(row, [k]);
    if (v === null || v === undefined || v === "") {
      const nested = row[k.replace(/_id$/, "")];
      if (nested && typeof nested === "object") v = firstPresent(nested, ["id", k]);
    }
    return v;
  };
  if (!d.outlet_name) d.outlet_name = String(firstPresent(row, ["name", "outlet_name"]) || "");
  for (const k of ["brand_id", "market_id", "tmpos_id"]) {
    if (d[k] === undefined || d[k] === null || d[k] === "") {
      const v = pickId(k);
      if (v !== null && v !== undefined && v !== "") d[k] = v;
    }
  }
  return row;
}

async function createDiscount(d, storeId, { name, rate, discountType }) {
  // discount_type: 1 = percentage, 2 = fixed amount
  const o = d._outlet && typeof d._outlet === "object" ? d._outlet : {};
  const has = (v) => v !== undefined && v !== null && v !== "";
  const pick = (k, fallback) => (has(o[k]) ? o[k] : fallback);
  const tmpos = has(o.tmpos_id) ? o.tmpos_id : d.tmpos_id;
  const marketId = has(o.market_id) ? o.market_id : d.market_id;
  const brandId = has(o.brand_id) ? o.brand_id : d.brand_id;
  if (!has(marketId) || !has(brandId)) {
    throw new Error(
      `Discount "${name}" cannot be assigned to the outlet - the outlet's brand/market ID was not found (Store ID ${storeId}). ` +
        "Select the outlet and try again, or enter the Brand ID / Market ID."
    );
  }
  const refStore = {
    // Backoffice tmpos_id is the first 8 digits of the 14-digit store_id (seen in a real capture).
    tmpos_id: has(tmpos) ? String(tmpos) : String(storeId).length >= 12 ? String(storeId).slice(0, 8) : null,
    market_id: marketId,
    store_id: String(storeId),
    name: d.outlet_name || pick("name", ""),
    brand_id: brandId,
    country_id: pick("country_id", 98),
    outlet_code: pick("outlet_code", null),
    captain_user_access: pick("captain_user_access", 1),
    mgs_integration: pick("mgs_integration", null),
    roundoff_upto_decimal: String(pick("roundoff_upto_decimal", "2")),
    timezone: pick("timezone", "Asia/Kolkata"),
    default: 0,
    shouldGenerateStartCloseDayReport: pick("shouldGenerateStartCloseDayReport", 0),
    currency:
      o.currency && typeof o.currency === "object"
        ? o.currency
        : { id: 98, currency_symbol: "Rs", name: "india" },
  };

  const payload = {
    id: null,
    discount_name: name,
    rate: String(rate),
    isactive: 1,
    discount_type: discountType,
    is_modifiable: "1",
    ref_stores: [refStore],
    menu_id: 0,
    applicable_on_item: 0,
    on_atlantic: 0,
    on_digiorder: 0,
    product_groups: [],
    order_type: [0],
    applicable_all_outlets: 0,
    applicable_all_outlets_group: "",
    is_default: 0,
    extra_details: { valid_on_day: "", from_time: "", to_time: "" },
  };

  const resp = await apiFetch("/api/admin/tmpos-discount", { method: "POST", body: JSON.stringify(payload) });
  const body = await readBody(resp);
  if (resp.status >= 400) {
    const err = formatHttpError(`Create discount "${name}"`, resp, body);
    if (/already|exist|taken|duplicate/i.test(err)) return { name, rate, already_created: true };
    throw new Error(err);
  }
  return { name, rate, already_created: false };
}

async function setupDiscounts(d, storeId) {
  const created = [];
  const percentName = (d.discountPercentName || "").trim();
  const percentRate = (d.discountPercentRate || "").trim();
  const fixedName = (d.discountFixedName || "").trim();
  const fixedRate = (d.discountFixedRate || "").trim();

  if (percentName && percentRate) {
    progress(`Creating discount "${percentName}" (${percentRate}%)...`);
    const r = await createDiscount(d, storeId, { name: percentName, rate: percentRate, discountType: 1 });
    created.push(`${r.already_created ? "already " : ""}"${r.name}" (${r.rate}%)`);
  }
  if (fixedName && fixedRate) {
    progress(`Creating discount "${fixedName}" (₹${fixedRate})...`);
    const r = await createDiscount(d, storeId, { name: fixedName, rate: fixedRate, discountType: 2 });
    created.push(`${r.already_created ? "already " : ""}"${r.name}" (₹${r.rate})`);
  }
  if (!created.length) throw new Error("Discount name/rate not entered — fill both fields for % or Flat discount.");
  return { summary: created.join(", ") };
}

// Predicts, BEFORE running anything, which checklist steps will pass / fail.
// level: "ok" (will pass) | "warn" (will run but check note) | "fail" (will fail) | "skip"
async function preflight(d, opts, selectedStoreId) {
  const out = {};
  const set = (k, level, message) => (out[k] = { level, message });
  const has = (v) => !!String(v == null ? "" : v).trim();
  let storeId = String(selectedStoreId || d.resumeStoreId || d.store_id || "").trim();
  let outletExists = false;

  try {
    await ensureAuth(d.masterEmail, d.masterPassword);
  } catch (e) {
    const m = "Backoffice login fail: " + e.message;
    for (const k of ["outlet", "user", "posTables", "menu", "paymentModes", "digitalOrdering", "designation", "users", "discounts"]) set(k, "fail", m);
    return out;
  }

  // Outlet
  if (storeId) {
    outletExists = true;
    set("outlet", "ok", `Existing outlet ${storeId} will be used (create skipped)`);
  } else {
    const dd = { ...d };
    try { await inferLocation(dd); } catch (e) { /* ignore */ }
    const missing = requiredFields(dd, false, false).filter((k) => OUTLET_REQUIRED.includes(k));
    let ex = null;
    if (has(dd.outlet_name)) {
      try {
        ex = await findExistingOutlet(dd, { quick: true, allowNameOnly: true });
      } catch (e) { ex = null; }
    }
    const exId = ex ? String(storeIdFromOutlet(ex) || "").trim() : "";
    if (exId) {
      storeId = exId;
      outletExists = true;
      set("outlet", "ok", `Already exists (Store ID ${exId}) - will be skipped and the rest of the setup continues`);
    } else if (!has(dd.outlet_name) && !has(dd.address)) {
      set("outlet", "skip", "No outlet data - the outlet step will be skipped");
    } else if (missing.length) {
      set("outlet", "fail", "Missing: " + missing.map((k) => FIELD_LABELS[k] || k).join(", "));
    } else {
      set("outlet", "ok", "A new outlet will be created");
    }
  }

  // Obvious email typos (e.g. "gamail.com" written in the message)
  const emailDomain = String(d.email || "").split("@")[1] || "";
  const TYPO_DOMAINS = ["gamail.com", "gmial.com", "gmai.com", "gmal.com", "gnail.com", "gmaill.com", "gmeil.com", "gamil.com", "gmail.con", "gmail.co", "gmail.cm", "yaho.com", "yahooo.com", "hotmial.com"];
  if (TYPO_DOMAINS.includes(emailDomain.toLowerCase()) && out.outlet) {
    const note = `Email "${d.email}" looks misspelled (gmail.com?) - confirm with the client`;
    if (out.outlet.level === "ok") out.outlet = { level: "warn", message: out.outlet.message + " | " + note };
    else out.outlet.message += " | " + note;
  }

  // Owner user
  const needUser = ["username", "password", "owner_name"].filter((k) => !has(d[k]));
  if (!has(d.username) && !has(d.password)) set("user", "skip", "No username/password - the user step will be skipped");
  else if (needUser.length) set("user", "fail", "Missing: " + needUser.map((k) => FIELD_LABELS[k] || k).join(", "));
  else if (!storeId && out.outlet && out.outlet.level === "fail") set("user", "fail", "The outlet will fail, so the user will not be created either");
  else if (!has(d.mobile) || !has(d.email)) {
    set("user", "warn", `Will be created, but ${[!has(d.mobile) ? "Mobile" : "", !has(d.email) ? "Email" : ""].filter(Boolean).join(" + ")} not found (optional)`);
  } else set("user", "ok", "The Owner/Manager user will be created");

  const blockedByOutlet = !storeId && out.outlet && out.outlet.level === "fail";
  const noStoreYet = !storeId;

  // Tables
  if (!opts.posTables) set("posTables", "skip", "Not selected");
  else if (blockedByOutlet) set("posTables", "fail", "The outlet will not be created");
  else {
    const n = Array.isArray(d.tableNames) && d.tableNames.length ? d.tableNames.length : parseInt(d.posTableCount || "0", 10);
    if (!n) set("posTables", "warn", "Table count/names not provided");
    else set("posTables", "ok", `"${d.posDeptName || "Dine In"}" dept + ${n} tables`);
  }

  // Menu
  if (!opts.menu) set("menu", "skip", "Not selected");
  else if (blockedByOutlet) set("menu", "fail", "The outlet will not be created");
  else {
    const menuName = (d.posMenuName || "POS Menu").trim() || "POS Menu";
    if (storeId && (await findMenu(storeId, menuName))) set("menu", "ok", `"${menuName}" already exists - will be skipped`);
    else set("menu", "ok", `"${menuName}" will be created`);
  }

  // Payment modes (master list is checked against a real outlet)
  if (!opts.paymentModes) set("paymentModes", "skip", "Not selected");
  else if (blockedByOutlet) set("paymentModes", "fail", "The outlet will not be created");
  else {
    let probe = storeId;
    if (!probe) {
      try {
        const list = await listOutlets();
        const first = Array.isArray(list) ? list[0] : null;
        probe = first ? String(storeIdFromOutlet(first) || "") : "";
      } catch (e) { probe = ""; }
    }
    if (!probe) set("paymentModes", "warn", "Will run after the outlet is created (could not be pre-checked)");
    else {
      try {
        const plan = await planPaymentModes(d, probe);
        if (plan.selected.length) {
          set("paymentModes", plan.notFound.length ? "warn" : "ok",
            `Will add: ${plan.selected.map((x) => x.payment_mode_name).join(", ")}` +
              (plan.notFound.length ? ` | Not in master: ${plan.notFound.join(", ")}` : ""));
        } else if (plan.notFound.length && !plan.alreadyNames.length) {
          set("paymentModes", "fail", `No match: ${plan.notFound.join(", ")} | Master list: ${plan.availableNames.join(", ")}`);
        } else set("paymentModes", "ok", "Already set");
      } catch (e) {
        set("paymentModes", "warn", "Could not pre-check: " + e.message.slice(0, 120));
      }
    }
  }

  // Digital ordering
  if (!opts.digitalOrdering) set("digitalOrdering", "skip", "Not selected");
  else if (blockedByOutlet) set("digitalOrdering", "fail", "The outlet will not be created");
  else if (noStoreYet) set("digitalOrdering", "ok", "Will be enabled after the outlet is created");
  else {
    try {
      const dd = { ...d };
      await hydrateOutletContext(dd, storeId);
      const sid = await findDigitalOrderSettingsId(storeId, dd.outlet_name);
      set("digitalOrdering", sid ? "ok" : "fail", sid ? "Pickup + Delivery will be enabled" : "Digital order settings record not found");
    } catch (e) {
      set("digitalOrdering", "warn", "Could not pre-check: " + e.message.slice(0, 120));
    }
  }

  // Designation
  if (!opts.designation) set("designation", "skip", "Not selected");
  else set("designation", "ok", `${String(d.designationName || "Manager, Cashier, Captain, Waiter")} will be created / verified`);

  // Extra users
  if (!opts.users) set("users", "skip", "Not selected");
  else if (blockedByOutlet) set("users", "fail", "The outlet will not be created");
  else {
    const list = Array.isArray(d.extraUsers) ? d.extraUsers : [];
    if (!list.length) set("users", "fail", "No user rows added");
    else {
      const v = userValidate(list, d.username);
      if (v.errors.length) set("users", "fail", v.errors[0] + (v.errors.length > 1 ? ` (+${v.errors.length - 1} more)` : ""));
      else if (v.warnings.length) set("users", "warn", v.warnings[0] + (v.warnings.length > 1 ? ` (+${v.warnings.length - 1} more)` : ""));
      else {
        const byType = {};
        for (const u of list) byType[userTypeByKey(u.typeKey).label] = (byType[userTypeByKey(u.typeKey).label] || 0) + 1;
        set("users", "ok", `${list.length} user(s) will be created: ${Object.entries(byType).map(([k, n]) => `${n} x ${k}`).join(", ")}`);
      }
    }
  }

  // Discounts
  if (!opts.discounts) set("discounts", "skip", "Not selected");
  else if (blockedByOutlet) set("discounts", "fail", "The outlet will not be created");
  else {
    const pOk = has(d.discountPercentName) && has(d.discountPercentRate);
    const fOk = has(d.discountFixedName) && has(d.discountFixedRate);
    if (!pOk && !fOk) set("discounts", "fail", "Fill both the discount name and the rate (% or Flat)");
    else if (noStoreYet) set("discounts", "ok", "Will be assigned to the outlet once it is created");
    else {
      const dd = { ...d };
      await hydrateOutletContext(dd, storeId);
      const o = dd._outlet || {};
      const mk = dd.market_id ?? o.market_id;
      const br = dd.brand_id ?? o.brand_id;
      if (!mk || !br) set("discounts", "fail", "The outlet's brand/market ID was not found - the outlet will not be assigned");
      else set("discounts", "ok", `Will be assigned to outlet "${dd.outlet_name || storeId}"`);
    }
  }
  return out;
}

async function runFullSetup(d, opts) {
  // Allow running with just a store_id - no outlet creation needed
  const storeId = d.store_id || (opts.storeId ? String(opts.storeId).trim() : null);
  if (!storeId) {
    progress("⚠️ Store ID not found. If you're running just the full setup steps (tables, menu, etc), please enter the Store ID in the Resume Store ID field.");
    return { results: [], errors: ["Store ID missing"], steps: {} };
  }

  const results = [];

  const errors = [];
  const steps = {};

  // Existing outlet picked from the dropdown: load its real name / brand /
  // market / tmpos so discounts + digital ordering are assigned correctly.
  if (opts.discounts || opts.digitalOrdering) {
    try {
      await hydrateOutletContext(d, storeId);
    } catch (e) {
      /* individual steps report their own errors */
    }
  }

  if (opts.posTables) {
    try {
      const r = await setupPosTables(d, storeId);
      const msg = `"${r.deptName}" department + ${r.createdCount} created, ${r.existingCount} already present`;
      results.push(`✅ POS Tables: ${msg}`);
      steps.posTables = { ok: true, message: msg };
    } catch (e) {
      errors.push(`❌ POS Tables: ${e.message}`);
      steps.posTables = { ok: false, message: e.message };
    }
  }
  if (opts.menu) {
    try {
      const r = await setupMenu(d, storeId);
      const msg = r.already_created ? `"${r.menuName}" already existed` : `"${r.menuName}" created`;
      results.push(`${r.already_created ? "ℹ️" : "✅"} Menu: ${msg}`);
      steps.menu = { ok: true, message: msg };
    } catch (e) {
      errors.push(`❌ Menu: ${e.message}`);
      steps.menu = { ok: false, message: e.message };
    }
  }
  if (opts.paymentModes) {
    try {
      const r = await setupPaymentModes(d, storeId);
      let msg = r.added.length ? `Added: ${r.added.join(", ")}` : "Already set on this outlet";
      if (r.notFound && r.notFound.length) msg += ` | Not in master list: ${r.notFound.join(", ")}`;
      results.push(r.added.length ? `✅ Payment modes ${msg}` : `ℹ️ Payment modes: ${msg}`);
      steps.paymentModes = { ok: true, message: msg };
    } catch (e) {
      errors.push(`❌ Payment modes: ${e.message}`);
      steps.paymentModes = { ok: false, message: e.message };
    }
  }
  if (opts.digitalOrdering) {
    try {
      await setupDigitalOrdering(d, storeId);
      const msg = "Pickup + Delivery enabled";
      results.push(`✅ Digital ordering: ${msg}`);
      steps.digitalOrdering = { ok: true, message: msg };
    } catch (e) {
      errors.push(`❌ Digital ordering: ${e.message}`);
      steps.digitalOrdering = { ok: false, message: e.message };
    }
  }
  if (opts.designation) {
    const names = String(d.designationName || "Manager, Cashier, Captain, Waiter")
      .split(/[,\n]/)
      .map((x) => x.trim())
      .filter(Boolean);
    const okNames = [];
    const badNames = [];
    for (const nm of names) {
      try {
        const r = await ensureDesignation(nm);
        okNames.push(r.already_created ? `${nm} (already)` : nm);
      } catch (e) {
        badNames.push(`${nm}: ${e.message}`);
      }
    }
    if (okNames.length) results.push(`✅ Designation: ${okNames.join(", ")}`);
    if (badNames.length) errors.push(`❌ Designation: ${badNames.join(" | ")}`);
    steps.designation = {
      ok: badNames.length === 0,
      message: badNames.length ? badNames.join(" | ") : okNames.join(", "),
    };
  }
  let createdUsers = [];
  if (opts.users) {
    try {
      const r = await createExtraUsers(d, storeId);
      createdUsers = r.created;
      if (r.created.length) results.push(`✅ Users created: ${r.created.map((c) => `${c.username} (${c.label})`).join(", ")}`);
      for (const c of r.created) if (c.warnings.length) results.push(`⚠️ ${c.username}: ${c.warnings.join("; ")}`);
      if (r.already.length) results.push(`ℹ️ Users that already exist (skipped): ${r.already.map((a) => a.username).join(", ")}`);
      if (r.failed.length) errors.push(`❌ Users: ${r.failed.map((f) => `${f.username}: ${f.error}`).join(" | ")}`);
      const msg = `${r.created.length} created, ${r.already.length} already existed, ${r.failed.length} failed`;
      steps.users = { ok: r.failed.length === 0, message: msg };
    } catch (e) {
      errors.push(`❌ Users: ${e.message}`);
      steps.users = { ok: false, message: e.message };
    }
  }
  if (opts.discounts) {
    try {
      const r = await setupDiscounts(d, storeId);
      results.push(`✅ Discounts: ${r.summary}`);
      steps.discounts = { ok: true, message: r.summary };
    } catch (e) {
      errors.push(`❌ Discounts: ${e.message}`);
      steps.discounts = { ok: false, message: e.message };
    }
  }

  return { results, errors, steps, createdUsers };
}

async function dryRunPreview(d) {
  const copy = { ...d };
  await inferLocation(copy);
  const testMode = !!copy.testMode;
  const outletId = testMode ? copy.testOutletId || "(Test Mode — enter ID)" : null;

  const outletPayload = {
    id: outletId,
    tmpos_id: copy.tmpos_id || "(auto-resolved on a real run)",
    name: copy.outlet_name,
    country_id: 98,
    timezone: "Asia/Kolkata",
    city: copy.city || "(auto-detected on a real run, if recognisable)",
    locality: copy.locality || "(auto-detected on a real run, if recognisable)",
    contact_phone: copy.mobile,
    address: copy.address,
    zip_codes: copy.pincode,
    market_id: copy.market_id || "(auto-resolved on a real run)",
    brand_id: copy.brand_id || "(auto-resolved on a real run)",
    email: copy.email,
    "...": "(+ digital_ordering_settings / config / reset-date defaults — omitted here for readability, see buildOutletPayload)",
  };
  const userPayload = testMode
    ? { skipped: true, reason: "Test Mode updates outlet only; no user create" }
    : {
        username: copy.username,
        password: copy.password ? "••••••••" : undefined,
        name: copy.owner_name,
        phone: copy.mobile,
        email: copy.email,
      };

  return {
    mode: testMode
      ? `TEST MODE -- would UPDATE outlet ${outletId} (no new outlet, no new user)`
      : "NORMAL MODE -- would CREATE (POST) a brand-new outlet + owner/manager user",
    outletPayload,
    userPayload,
    output: buildOutput(copy),
  };
}

function buildOutput(d) {
  // If the client's message didn't include separate POS Front Office /
  // Billing System credentials, fall back to the standard convention:
  // same username as the Owner Panel login, but a fixed default PIN-style
  // password ("1234") for the Billing App instead of leaving it blank or
  // reusing the backoffice password.
  // POS user: use the same username as backoffice (or explicit pos_username if given),
  // and a simple 4-digit default password of "1234".
  // POS: username = same as backoffice owner (or explicit pos_username if given).
  // Password = always "1234" — never trust a parsed pos_password from the message.
  const posU = d.pos_username || d.username || "";
  const posP = "1234";
  return [
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
    "*Back Office / Owner Panel*",
    `🔗 Access Portal: ${d.login_link || BASE_URL}`,
    "",
    `*• Username* : ${d.username || ""}`,
    `*• Password* : ${d.password || ""}`,
    "",
    "TMBill Atlantic POS – Account Credentials",
    "",
    "*POS Front Office / Billing System*",
    "",
    `*• Username* : ${posU}`,
    `*• Password* : ${posP}`,
    "━━━━━━━━━━━━━━━━━━━━━",
    "For more information, visit our website: 🌐 www.tmbill.com",
    "",
    "Best Regards,",
    "*Technical Support*",
    "*TMBill*",
    "",
    "*Primary POC – Saheel S*",
    "Shift Timing – 02 PM to 11 PM IST",
    "Week Off – Sunday",
    "Contact Number - +91 7709 528847",
    "",
    "*Secondary POC – Akash Y*",
    "Shift Timing – 12:00 PM to 09:00 PM IST",
    "Week Off – Wednesday",
    "Contact Number - +91 8390327794",
  ].join("\n");
}

const DIAGNOSIS_PATTERNS = [
  {
    test: /HTTP\s*(401|403)/i,
    why: "Login/authorization failed (HTTP 401/403).",
    fix: "Check backoffice email/password, or first log into backoffice.tmbill.com and use that session.",
  },
  {
    test: /HTTP\s*419|CSRF|XSRF/i,
    why: "Session/CSRF token expired (HTTP 419).",
    fix: "Try Start Onboarding again — token may have expired, new login will happen automatically.",
  },
  {
    test: /saving store data|HTTP\s*500/i,
    why: "Server-side HTTP 500 while saving the outlet.",
    fix: "Verify brand_id / market_id / tmpos_id are correct. Enter explicit IDs in UI or message.",
  },
  {
    test: /requires brand_id|requires market_id/i,
    why: "Brand ID or Market ID not found.",
    fix: "Enter Brand ID / Market ID in the UI boxes or in the pasted message.",
  },
  {
    test: /no matching partially-created outlet was found/i,
    why: "Got HTTP 500 and no matching outlet was found.",
    fix: "Check outlet list in backoffice. Pincode/mobile format might be incorrect.",
  },
  {
    test: /^Missing:/im,
    why: "Required field(s) for onboarding not found.",
    fix: "Add the field(s) listed after 'Missing:' to the client message and Parse again.",
  },
  {
    test: /Failed to fetch|NetworkError|ERR_CONNECTION/i,
    why: "Extension could not reach backoffice.tmbill.com.",
    fix: "Check internet connection. In chrome://extensions, verify host permissions are granted.",
  },
  {
    test: /HTTP\s*404/i,
    why: "Endpoint not found (HTTP 404).",
    fix: "Check the path in the error text — TMBill may have changed the API route.",
  },
  {
    test: /store_id was found/i,
    why: "Outlet save seems successful, but store_id not found in response.",
    fix: "Send the JSON from the error — response structure may be different.",
  },
];

function diagnoseLog(text) {
  const matches = [];
  for (const p of DIAGNOSIS_PATTERNS) {
    if (p.test.test(text)) matches.push({ why: p.why, fix: p.fix });
  }
  return matches;
}

// Strictly per-tab side panel.
// Every tab gets its OWN panel (unique path per tab), prepared in advance, so
// the toolbar click can call open() immediately -- Chrome only allows opening
// inside the click's user gesture, so nothing may be awaited before it.
// A panel opened in tab A therefore never shows up in tab B, survives
// navigation / reload, and closes only when the user closes it.
function prepareTabPanel(tabId) {
  if (tabId === undefined || tabId === null || tabId < 0) return;
  chrome.sidePanel
    .setOptions({ tabId, path: `popup.html?tab=${tabId}`, enabled: true })
    .catch(() => {});
}

function enableSidePanel() {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
  chrome.sidePanel.setOptions({ enabled: false }).catch(() => {}); // no global panel
  chrome.tabs.query({}).then((tabs) => tabs.forEach((t) => prepareTabPanel(t.id))).catch(() => {});
}
chrome.runtime.onInstalled.addListener(enableSidePanel);
chrome.runtime.onStartup.addListener(enableSidePanel);
enableSidePanel();
scheduleSlackAssignmentMonitor();

chrome.tabs.onCreated.addListener((tab) => prepareTabPanel(tab.id));
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === "loading" || info.status === "complete") prepareTabPanel(tabId);
});

chrome.action.onClicked.addListener((tab) => {
  if (!tab || tab.id === undefined) return;
  // First call is synchronous inside the click -> keeps the user gesture.
  chrome.sidePanel.open({ tabId: tab.id }).catch(() => {
    // Panel wasn't prepared yet for this tab: prepare it, then try again.
    chrome.sidePanel
      .setOptions({ tabId: tab.id, path: `popup.html?tab=${tab.id}`, enabled: true })
      .then(() => chrome.sidePanel.open({ tabId: tab.id }))
      .catch(() => {});
  });
});


// ---------------------------------------------------------------------
// WhatsApp Web: save contact + send message in the ALREADY OPEN tab
// ---------------------------------------------------------------------
async function findWhatsAppTabs() {
  const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
  // Loaded, awake tabs first
  return tabs.sort((a, b) => Number(!!a.discarded) - Number(!!b.discarded));
}

async function inWhatsAppTab(tab, func, args) {
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", files: ["wa_inject.js"] });
  const out = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func, args });
  return out && out[0] ? out[0].result : undefined;
}

const NO_WA_TAB =
  "No WhatsApp Web tab found. Open web.whatsapp.com in a Chrome tab and stay logged in (a new tab is never opened for you).";

async function waSend(items, text) {
  try {
    const tabs = await findWhatsAppTabs();
    if (!tabs.length) return { ok: false, error: NO_WA_TAB };
    let last = null;
    for (const tab of tabs) {
      if (tab.discarded) {
        last = { ok: false, error: "The WhatsApp tab is asleep (Memory Saver) - click that tab once, then try again." };
        continue;
      }
      try {
        const res = await inWhatsAppTab(tab, (a) => window.__tmbillWA.run(a), [{ items, text }]);
        if (res && res.ok) return res;
        last = res || { ok: false, error: "No response from the WhatsApp tab" };
      } catch (e) {
        last = { ok: false, error: "The script did not run in the WhatsApp tab: " + String((e && e.message) || e) };
      }
    }
    return last || { ok: false, error: NO_WA_TAB };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

async function waSendQuick(items, text, openIfMissing = false) {
  let tabs = await findWhatsAppTabs();
  if (!tabs.length && openIfMissing) {
    const t = await chrome.tabs.create({ url: "https://web.whatsapp.com/", active: false });
    for (let i = 0; i < 30; i++) {
      await new Promise(r => setTimeout(r, 1000));
      tabs = await findWhatsAppTabs();
      const tab = tabs.find(x => x.id === t.id);
      if (tab && !tab.discarded && tab.status === "complete") break;
    }
  }
  return waSend(items, text);
}

async function waDiag() {
  try {
    const tabs = await findWhatsAppTabs();
    if (!tabs.length) return { ok: false, error: NO_WA_TAB };
    const d = await inWhatsAppTab(tabs[0], () => window.__tmbillWA.diag(), []);
    return { ok: true, diag: d, tabs: tabs.length };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

// ---------------------------------------------------------------------
// Slack background assignment monitor
// Watches Slack for new messages that make the current Slack user the
// Primary POC. It is intentionally independent of the active browser tab.
// ---------------------------------------------------------------------
const SLACK_ASSIGN_SETTINGS_KEY = "tmbill_settings";
const SLACK_ASSIGN_PENDING_KEY = "tmbill_pending_slack_assignment";
const SLACK_ASSIGN_SEEN_KEY = "tmbill_slack_assignment_seen";
const SLACK_MENTION_SEEN_KEY = "tmbill_slack_mention_seen";
const SLACK_ASSIGN_ALARM = "tmbill_slack_assignment_poll";
const SLACK_ASSIGN_ALARM_MIN = 0.5; // 30-second best-effort polling; Chrome may throttle alarms.

// Smart Agent state/history. The agent is deterministic by default: it
// plans from the existing onboarding workflow and only reports a step as
// complete after the underlying action returns a verified result.
const AGENT_SETTINGS_KEY = "tmbill_settings";
const AGENT_JOB_KEY = "tmbill_agent_job";
const AGENT_HISTORY_KEY = "tmbill_agent_history";
const AGENT_HISTORY_MAX = 30;

async function agentSettings() {
  const st = await chrome.storage.local.get(AGENT_SETTINGS_KEY);
  return {
    agentMode: "smart_auto",
    slackAssignment: true,
    slackMentions: true,
    slackPocName: "",
    ...(st[AGENT_SETTINGS_KEY] || {})
  };
}

async function agentLog(event, data = {}) {
  try {
    const st = await chrome.storage.local.get(AGENT_HISTORY_KEY);
    const list = Array.isArray(st[AGENT_HISTORY_KEY]) ? st[AGENT_HISTORY_KEY] : [];
    list.unshift({ ts: Date.now(), event, ...data });
    await chrome.storage.local.set({ [AGENT_HISTORY_KEY]: list.slice(0, AGENT_HISTORY_MAX) });
  } catch (e) {}
}

async function agentSetJob(patch) {
  try {
    const st = await chrome.storage.local.get(AGENT_JOB_KEY);
    const job = { ...(st[AGENT_JOB_KEY] || {}), ...patch, updatedAt: Date.now() };
    await chrome.storage.local.set({ [AGENT_JOB_KEY]: job });
    return job;
  } catch (e) { return null; }
}

async function slackAssignmentSettings() {
  const st = await chrome.storage.local.get(SLACK_ASSIGN_SETTINGS_KEY);
  return { slackAssignment: true, slackMentions: true, slackPocName: "", ...(st[SLACK_ASSIGN_SETTINGS_KEY] || {}) };
}

function assignmentLooksRelevant(text) {
  const t = String(text || "").replace(/\s+/g, " ").trim();
  if (!/(primary\s*poc|poc\s*[:=-]|ownered\s*by|assigned\s*to)/i.test(t)) return false;
  return /(assign|assigned|onboard|onboarding|new client|new outlet|client|outlet|restaurant|store|brand|cx)/i.test(t);
}

function assignmentMatchesMe(text, myId, myName) {
  const t = String(text || "");
  if (myId && new RegExp("<@" + myId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?:\\|[^>]*)?>", "i").test(t)) return true;
  const n = String(myName || "").trim().toLowerCase();
  if (n && t.toLowerCase().includes(n)) return true;
  // Also accept a shorter configured first/last name token, but only when it
  // appears near the Primary POC label to reduce false positives.
  if (n && n.includes(" ")) {
    const parts = n.split(/\s+/).filter(Boolean);
    const short = parts[0];
    if (short && new RegExp("primary\\s*poc[^\\n]{0,100}" + short.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i").test(t)) return true;
  }
  return false;
}

function assignmentOutletName(text) {
  const lines = String(text || "").split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  for (const line of lines) {
    const m = line.match(/^(?:outlet|outlet name|client|client name|restaurant|restaurant name|store|store name|brand outlet name)\s*[:\-–—=]\s*(.+)$/i);
    if (m) return m[1].trim();
  }
  return lines.find(x => /(?:new client|new outlet)/i.test(x))?.replace(/.*(?:new client|new outlet)\s*[:\-–—]?\s*/i, "").trim() || "New client";
}

function slackMentionMatchesMe(text, myId) {
  const t = String(text || "");
  if (myId && new RegExp("<@" + myId.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&") + "(?:\\|[^>]*)?>", "i").test(t)) return true;
  // Slack stores broadcast mentions as these special tokens.
  return /<!channel(?:\|[^>]*)?>|<!here(?:\|[^>]*)?>|<!everyone(?:\|[^>]*)?>/i.test(t);
}

function slackAlertSummary(text) {
  let t = slackToPlain(String(text || ""));
  t = t.replace(/\s+/g, " ").trim();
  t = t.replace(/^(?:<@[^>]+>\s*)+/i, "");
  if (!t) return "You were mentioned in Slack.";
  if (t.length > 220) t = t.slice(0, 217).trimEnd() + "…";
  return t;
}

async function slackMentionPoll(token, auth, cfg, seen) {
  if (!cfg.slackMentions) return { ok: true, notified: 0 };
  const myId = auth.user_id || "";
  const queries = [];
  if (myId) queries.push(`<@${myId}>`);
  // Slack search can miss a literal <@USERID> query in DMs. `to:me`
  // finds direct messages addressed to the authenticated user, which we
  // additionally filter to task/onboarding language below.
  queries.push("to:me", '"<!channel>"', '"<!here>"', '"<!everyone>"');
  const allMatches = new Map();
  let firstError = null;
  for (const query of queries) {
    const sr = await slackApi("search.messages", token, { query, sort: "timestamp", sort_dir: "desc", count: 20 });
    if (!sr.ok) { firstError = sr; if (sr.error === "missing_scope") break; continue; }
    for (const m of (Array.isArray(sr.messages && sr.messages.matches) ? sr.messages.matches : [])) {
      const ts = String(m.ts || "");
      const channel = String((m.channel && m.channel.id) || m.channel_id || "");
      if (ts && channel) allMatches.set(`${channel}:${ts}`, m);
    }
  }
  if (!allMatches.size && firstError && firstError.error === "missing_scope") return { ok: false, code: firstError.error, error: "Slack token needs the search:read User Token Scope for Slack mention alerts." };
  const matches = Array.from(allMatches.values()).sort((a,b) => Number(b.ts||0) - Number(a.ts||0));
  for (const m of matches.slice(0, 30)) {
    const ts = String(m.ts || "");
    const channel = String((m.channel && m.channel.id) || m.channel_id || "");
    const key = `${channel}:${ts}`;
    if (!ts || !channel || seen.has(key)) continue;
    const raw = String(m.text || "");
    const isDirectMessage = !!(m.channel && (m.channel.is_im || m.channel.is_mpim || String(m.channel.id || "").startsWith("D")));
    const dmTaskSignal = isDirectMessage && /\b(assign(?:ed|ment)?|onboard(?:ing)?|new client|new outlet|task|primary\s*poc|restaurant setup|client setup)\b/i.test(slackToPlain(raw));
    if (!slackMentionMatchesMe(raw, myId) && !dmTaskSignal) continue;
    // Assignment alerts have their own higher-priority notification.
    if (assignmentLooksRelevant(raw) && assignmentMatchesMe(raw, myId, cfg.slackPocName || auth.user || "")) continue;
    let fullText = raw;
    try { const fetched = await slackFetchMessage({ token, channel, ts }); if (fetched && fetched.ok && fetched.text) fullText = fetched.text; } catch (e) {}
    const fullIsDmTask = isDirectMessage && /\b(assign(?:ed|ment)?|onboard(?:ing)?|new client|new outlet|task|primary\s*poc|restaurant setup|client setup)\b/i.test(slackToPlain(fullText));
    if (!slackMentionMatchesMe(fullText, myId) && !fullIsDmTask) continue;
    const summary = slackAlertSummary(fullText);
    let link = String(m.permalink || "");
    if (!link && auth.team_id) link = `https://app.slack.com/client/${auth.team_id}/${channel}/thread/${channel}-${ts}`;
    const channelName = String((m.channel && m.channel.name) || "Slack");
    const sender = String(m.username || m.user_name || m.user || "").trim();
    const foundAt = Date.now();
    const alert = { text: fullText, summary, link, channel, channelName, sender, ts, foundAt, type: "mention" };
    await chrome.storage.local.set({ tmbill_pending_slack_alert: alert });
    await agentSetJob({ id: key, status: "mentioned", summary, channel, ts, link, startedAt: foundAt, source: "slack_mention" });
    await agentLog("slack_mention_detected", { channel, ts, summary });
    const nid = `tmbill-mention-${channel}-${ts}`.replace(/[^a-zA-Z0-9_-]/g, "_");
    await chrome.notifications.create(nid, {
      type: "basic", iconUrl: "icons/icon128.png",
      title: "TMBill Smart Agent — Slack Alert",
      message: `${sender ? sender + " · " : ""}${summary}`,
      contextMessage: `${channelName} · You were mentioned (or a broadcast mention was used).`,
      priority: 2, requireInteraction: true,
      buttons: [{ title: "Open Slack" }, { title: "Dismiss" }]
    });
    seen.add(key);
    return { ok: true, notified: 1 };
  }
  return { ok: true, notified: 0 };
}

async function slackAssignmentPoll(force = false) {
  try {
    const cfg = await slackAssignmentSettings();
    if (!cfg.slackAssignment && !cfg.slackMentions && !force) return { ok: true, skipped: true };
    const st = await chrome.storage.local.get(["tmbill_slack_token", SLACK_ASSIGN_SEEN_KEY, SLACK_MENTION_SEEN_KEY]);
    const token = String(st.tmbill_slack_token || "").trim();
    if (!token || /^xoxb-/i.test(token)) return { ok: false, code: "NO_USER_TOKEN" };
    if (!cfg.slackAssignment && !cfg.slackMentions && !force) return { ok: true, skipped: true };

    const auth = await slackAuthTest(token);
    if (!auth.ok) return auth;
    const myId = auth.user_id || auth.user_id;
    const myName = String(cfg.slackPocName || auth.user || "").trim();

    const mentionSeen = new Set(Array.isArray(st[SLACK_MENTION_SEEN_KEY]) ? st[SLACK_MENTION_SEEN_KEY].map(String) : []);
    const mentionResult = await slackMentionPoll(token, auth, cfg, mentionSeen);
    if (mentionResult && mentionResult.ok && mentionResult.notified) {
      await chrome.storage.local.set({ [SLACK_MENTION_SEEN_KEY]: Array.from(mentionSeen).slice(-100) });
    } else if (cfg.slackMentions) {
      // Keep de-duplication state stable across service-worker restarts.
      await chrome.storage.local.set({ [SLACK_MENTION_SEEN_KEY]: Array.from(mentionSeen).slice(-100) });
    }
    if (mentionResult && mentionResult.error && cfg.slackMentions && !cfg.slackAssignment) return mentionResult;

    // Search is much more reliable than watching a Slack browser tab: the
    // Chrome extension can wake on an alarm while the user is on any website.
    const queries = cfg.slackAssignment ? ['"Primary POC"', '"primary poc" assigned', '"assigned to" "POC"'] : [];
    const allMatches = new Map();
    let firstError = null;
    for (const query of queries) {
      const sr = await slackApi("search.messages", token, { query, sort: "timestamp", sort_dir: "desc", count: 20 });
      if (!sr.ok) {
        firstError = sr;
        if (sr.error === "missing_scope") break;
        continue;
      }
      for (const m of (Array.isArray(sr.messages && sr.messages.matches) ? sr.messages.matches : [])) {
        const ts = String(m.ts || "");
        const channel = String((m.channel && m.channel.id) || m.channel_id || "");
        if (ts && channel) allMatches.set(`${channel}:${ts}`, m);
      }
    }
    if (!allMatches.size && firstError && firstError.error === "missing_scope") {
      return { ok: false, code: firstError.error, error: "Slack token needs the search:read User Token Scope for background assignment alerts." };
    }

    const seen = new Set(Array.isArray(st[SLACK_ASSIGN_SEEN_KEY]) ? st[SLACK_ASSIGN_SEEN_KEY].map(String) : []);
    const matches = Array.from(allMatches.values()).sort((a,b) => Number(b.ts||0) - Number(a.ts||0));
    let notified = 0;
    for (const m of matches.slice(0, 30)) {
      const ts = String(m.ts || "");
      const channel = String((m.channel && m.channel.id) || m.channel_id || "");
      if (!ts || !channel) continue;
      const raw = String(m.text || "");
      const key = `${channel}:${ts}`;
      if (seen.has(key)) continue;
      if (!assignmentLooksRelevant(raw) || !assignmentMatchesMe(raw, myId, myName)) continue;

      let fullText = raw;
      try {
        const fetched = await slackFetchMessage({ token, channel, ts });
        if (fetched && fetched.ok && fetched.text) fullText = fetched.text;
      } catch (e) {}
      if (!assignmentLooksRelevant(fullText) || !assignmentMatchesMe(fullText, myId, myName)) continue;

      const outlet = assignmentOutletName(fullText);
      let link = String(m.permalink || "");
      if (!link && auth.team_id) link = `https://app.slack.com/client/${auth.team_id}/${channel}/thread/${channel}-${ts}`;
      const foundAt = Date.now();
      await chrome.storage.local.set({
        [SLACK_ASSIGN_PENDING_KEY]: { text: fullText, outlet, link, channel, ts, foundAt },
        tmbill_assignment_context: { outlet, link, channel, ts, foundAt },
      });
      await agentSetJob({ id: key, status: "detected", outlet, channel, ts, link, startedAt: foundAt, source: "slack" });
      await agentLog("assignment_detected", { outlet, channel, ts });
      const mode = String(cfg.agentMode || "smart_auto");
      const nid = `tmbill-assignment-${channel}-${ts}`.replace(/[^a-zA-Z0-9_-]/g, "_");
      if (mode !== "full_auto") {
        await chrome.notifications.create(nid, {
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: "TMBill Smart Agent — New Client",
          message: `${outlet || "A new client"} is assigned to you as Primary POC.`,
          priority: 2,
          requireInteraction: true,
          buttons: [{ title: "Start Onboarding" }, { title: "Later" }],
        });
      } else {
        await agentSetJob({ status: "starting", trigger: "full_auto" });
        await agentLog("agent_auto_start", { outlet, channel, ts });
        try { await openAssignmentQuickWindow(); } catch (e) { await agentLog("auto_start_failed", { error: String(e && e.message || e) }); }
      }
      seen.add(key);
      notified++;
      // One notification per poll is enough; pending data is a single handoff.
      break;
    }
    const arr = Array.from(seen).slice(-100);
    await chrome.storage.local.set({ [SLACK_ASSIGN_SEEN_KEY]: arr });
    return { ok: true, notified };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

async function scheduleSlackAssignmentMonitor() {
  try {
    const cfg = await slackAssignmentSettings();
    if (cfg.slackAssignment || cfg.slackMentions) { // slackAssignment defaults to true
      await chrome.alarms.create(SLACK_ASSIGN_ALARM, { periodInMinutes: SLACK_ASSIGN_ALARM_MIN });
      slackAssignmentPoll();
    } else {
      await chrome.alarms.clear(SLACK_ASSIGN_ALARM);
    }
  } catch (e) {}
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === SLACK_ASSIGN_ALARM) slackAssignmentPoll();
  if (alarm && alarm.name === UPDATE_ALARM) backgroundUpdateCheck();
});

// ---- One-click update: look for a new signed release every 6 hours (you press Update yourself) ----
async function backgroundUpdateCheck() {
  try {
    const st = await chrome.storage.local.get([UPDATE_CFG_KEY, UPDATE_DISMISS_KEY]);
    const cfg = Object.assign({ base: UPDATE_DEFAULT_BASE, auto: true }, st[UPDATE_CFG_KEY] || {});
    if (cfg.auto === false) return;
    const cur = chrome.runtime.getManifest().version;
    const res = await updCheck(cfg.base, cur);
    await chrome.storage.local.set({ [UPDATE_INFO_KEY]: { version: res.latest, notes: res.info.notes, checkedAt: Date.now() } });
    if (!res.newer) { chrome.action.setBadgeText({ text: "" }); return; }
    if (st[UPDATE_DISMISS_KEY] === res.latest) return;
    chrome.action.setBadgeBackgroundColor({ color: "#8DC231" });
    chrome.action.setBadgeText({ text: "NEW" });
    const flag = "tmbill_update_notified";
    const seen = (await chrome.storage.local.get(flag))[flag];
    if (seen !== res.latest) {
      await chrome.storage.local.set({ [flag]: res.latest });
      chrome.notifications.create("tmbill_update_" + res.latest, { type: "basic", iconUrl: "icons/icon128.png", title: "TMBill extension update", message: `Version ${res.latest} is available (installed ${cur}). Open the extension and press "Update extension".` });
    }
  } catch (e) { /* offline or source not set up - try again later */ }
}
chrome.alarms.get(UPDATE_ALARM, (a) => { if (!a) chrome.alarms.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: 360 }); });
async function openAssignmentQuickWindow() {
  try {
    const w = await chrome.windows.getLastFocused({ windowTypes: ["normal"] });
    const width = 520, height = 640;
    const left = Math.max(0, Math.round((w && Number.isFinite(w.left) ? w.left : 0) + ((w && w.width ? w.width : 1200) - width) / 2));
    const top = Math.max(0, Math.round((w && Number.isFinite(w.top) ? w.top : 0) + ((w && w.height ? w.height : 800) - height) / 2));
    return await chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?assignment=1&quick=1"),
      type: "popup", focused: true, width, height, left, top
    });
  } catch (e) {
    return await chrome.tabs.create({ url: chrome.runtime.getURL("popup.html?assignment=1&quick=1"), active: true });
  }
}

chrome.notifications.onClicked.addListener(async (notificationId) => {
  if (String(notificationId || "").startsWith("tmbill-mention-")) {
    try {
      const st = await chrome.storage.local.get("tmbill_pending_slack_alert");
      const a = st.tmbill_pending_slack_alert || {};
      if (a.link) await chrome.tabs.create({ url: a.link, active: true });
      await chrome.notifications.clear(notificationId);
    } catch (e) {}
    return;
  }

  if (!String(notificationId || "").startsWith("tmbill-assignment-")) return;
  try { await openAssignmentQuickWindow(); } catch (e) {}
});
chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  if (String(notificationId || "").startsWith("tmbill-mention-")) {
    if (buttonIndex === 0) {
      try { const st = await chrome.storage.local.get("tmbill_pending_slack_alert"); const a = st.tmbill_pending_slack_alert || {}; if (a.link) await chrome.tabs.create({ url: a.link, active: true }); } catch (e) {}
    }
    try { await chrome.notifications.clear(notificationId); } catch (e) {}
    return;
  }
  if (!String(notificationId || "").startsWith("tmbill-assignment-")) return;
  if (buttonIndex !== 0) { try { await chrome.notifications.clear(notificationId); } catch (e) {} ; return; }
  try { await openAssignmentQuickWindow(); } catch (e) {}
  try { await chrome.notifications.clear(notificationId); } catch (e) {}
});

// ---------------------------------------------------------------------
// Slack (web): post "Onboarding is done" as a REPLY IN THE SAME THREAD the
// onboarding request was copied from. Runs inside the already-open Slack tab
// (nothing is opened for you). It only ever types into the THREAD reply box --
// never the channel box -- so it can't post into the channel by mistake.
// ---------------------------------------------------------------------
const NO_SLACK_TAB =
  "No Slack tab found. Open the onboarding thread in Slack on the web (app.slack.com) in a Chrome tab - the desktop Slack app can't be controlled.";

// https://app.slack.com/client/T0123/C0456/thread/C0456-1700000000.123456
function parseSlackThreadUrl(url) {
  const m = String(url || "").match(/app\.slack\.com\/client\/([A-Z0-9]+)\/([A-Z0-9]+)\/thread\/([A-Z0-9]+)-(\d+\.\d+)/i);
  return m ? { team: m[1], channel: m[2], ts: m[4] } : null;
}

async function findSlackTabs(preferTabId) {
  const tabs = await chrome.tabs.query({ url: ["https://app.slack.com/*", "https://*.slack.com/*"] });
  const score = (t) =>
    (t.id === preferTabId ? 1000 : 0) +
    (parseSlackThreadUrl(t.url) ? 100 : 0) +
    (t.active ? 10 : 0) -
    (t.discarded ? 500 : 0);
  return tabs
    .filter((t) => /(^|\.)slack\.com\//.test(String(t.url || "").replace(/^https?:\/\//, "")))
    .sort((a, b) => score(b) - score(a) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
}

function waitTabComplete(tabId, ms) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      resolve(v);
    };
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") finish(true);
    };
    chrome.tabs.onUpdated.addListener(listener);
    const timer = setTimeout(() => finish(false), ms || 30000);
  });
}

// ---- runs INSIDE the Slack page (isolated world); must be self-contained ----
async function slackInjected(mode, text, needles, force, waitMs) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const PANE_SELS = [
    '[data-qa="threads_flexpane"]',
    '[data-qa="thread_flexpane"]',
    ".p-threads_flexpane",
    '[data-qa="slack_kit_flexpane"]',
    '.p-flexpane[aria-label*="hread" i]',
    '[role="complementary"][aria-label*="hread" i]',
  ];
  const findPane = () => {
    for (const sel of PANE_SELS) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  };
  const findComposer = (pane) => {
    // Only a composer INSIDE the thread pane counts -- never the channel's.
    const eds = pane.querySelectorAll('[data-qa="message_input"] .ql-editor[contenteditable="true"], .ql-editor[contenteditable="true"], [contenteditable="true"][role="textbox"]');
    return eds.length ? eds[eds.length - 1] : null;
  };
  const norm = (t) => String(t || "").toLowerCase().replace(/\s+/g, " ");

  // Wait for the thread pane (page may still be loading after navigation)
  let pane = null;
  const t0 = Date.now();
  while (Date.now() - t0 < (waitMs || 4000)) {
    pane = findPane();
    if (pane && findComposer(pane)) break;
    await sleep(500);
  }
  if (!pane) {
    return { ok: false, code: "NO_THREAD", error: "No thread is open in the Slack tab. Open the onboarding message's thread (click its replies / 'Reply in thread') and try again." };
  }
  const editor = findComposer(pane);
  const paneText = pane.innerText || "";
  const firstMsg = pane.querySelector('[data-qa="message_text"], [data-qa="message_content"], .c-message_kit__text, .p-rich_text_section');
  const preview = String((firstMsg && firstMsg.innerText) || paneText).replace(/\s+/g, " ").trim().slice(0, 160);

  // Does this thread look like the right outlet?
  const wanted = (needles || []).map((n) => String(n || "").trim()).filter((n) => n.length >= 3);
  let matched = null;
  if (wanted.length) {
    const nt = norm(paneText);
    const dt = paneText.replace(/\D/g, "");
    matched = wanted.some((n) => {
      const digits = n.replace(/\D/g, "");
      if (digits.length >= 8 && digits === n.replace(/[\s+\-().]/g, "")) return dt.includes(digits);
      return nt.includes(norm(n));
    });
  }

  if (mode === "peek") return { ok: true, hasPane: true, hasComposer: !!editor, preview, matched };

  if (!editor) return { ok: false, code: "NO_COMPOSER", error: "Thread reply box not found in Slack (Slack may have changed its page). Use 'Copy message' and paste it yourself.", preview };
  if (matched === false && !force) {
    return { ok: false, code: "WRONG_THREAD", error: "The open thread doesn't mention this outlet.", preview };
  }
  const blank = editor.classList.contains("ql-blank") || !String(editor.innerText || "").replace(/\u200b/g, "").trim();
  if (!blank) {
    return { ok: false, code: "DRAFT", error: "The thread reply box already has a draft. Send or clear it in Slack first, then try again.", preview };
  }

  // Type the message
  editor.focus();
  const lines = String(text).split("\n");
  lines.forEach((l, i) => {
    if (i) document.execCommand("insertLineBreak");
    if (l) document.execCommand("insertText", false, l);
  });
  await sleep(250);
  const snippet = norm(lines[0]).slice(0, 25);
  if (!norm(editor.innerText).includes(snippet)) {
    try {
      const dt = new DataTransfer();
      dt.setData("text/plain", text);
      editor.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    } catch (e) { /* ignore */ }
    await sleep(300);
  }
  if (!norm(editor.innerText).includes(snippet)) {
    return { ok: false, code: "TYPE_FAILED", error: "Could not type into Slack's reply box. Use 'Copy message' and paste it yourself.", preview };
  }

  // Send: click the send button of THIS composer, else press Enter
  let sendBtn = null;
  for (let el = editor, i = 0; el && i < 10 && !sendBtn; el = el.parentElement, i++) {
    sendBtn = el.querySelector('button[data-qa="texty_send_button"]');
  }
  if (sendBtn && sendBtn.getAttribute("aria-disabled") !== "true" && !sendBtn.disabled) {
    sendBtn.click();
  } else {
    const ev = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    editor.dispatchEvent(new KeyboardEvent("keydown", ev));
    editor.dispatchEvent(new KeyboardEvent("keyup", ev));
  }

  // Confirm: box emptied AND the text now appears in the thread
  let confirmed = false;
  for (let i = 0; i < 16; i++) {
    await sleep(500);
    const emptied = editor.classList.contains("ql-blank") || !String(editor.innerText || "").replace(/\u200b/g, "").trim();
    if (emptied && norm(pane.innerText).includes(snippet)) { confirmed = true; break; }
  }
  return { ok: true, confirmed, preview };
}

// ---- Slack API mode: works for the Slack DESKTOP app too ----
// The message is posted through Slack's API as a thread reply; the desktop app
// (and web, and phone) then show it in that thread automatically.
async function slackApi(method, token, body) {
  const resp = await fetch("https://slack.com/api/" + method, {
    method: "POST",
    // Form-encoded: Slack's read methods (conversations.replies, auth.test...) reject JSON bodies.
    headers: { "Content-Type": "application/x-www-form-urlencoded; charset=utf-8", Authorization: "Bearer " + token },
    body: new URLSearchParams(Object.entries(body || {}).map(([k, v]) => [k, String(v)])).toString(),
  });
  return resp.json();
}

function slackApiErrorText(code) {
  const map = {
    invalid_auth: "Slack token is invalid. Paste the token again.",
    not_authed: "Slack token is missing.",
    token_revoked: "Slack token was revoked. Create/paste a new one.",
    missing_scope: "Token lacks the 'chat:write' permission. Add it in your Slack app and reinstall.",
    not_in_channel: "The token's user/bot is not a member of that channel. Join the channel (or invite the bot) first.",
    channel_not_found: "Channel not found for this token (private channel or wrong link).",
    thread_not_found: "Thread message not found - check the link.",
    is_archived: "That channel is archived.",
    ratelimited: "Slack rate limit - try again in a few seconds.",
  };
  return map[code] || "Slack error: " + code;
}

async function slackApiPost({ token, channel, ts, text, needles, force }) {
  try {
    if (!token) return { ok: false, error: "Slack token is not saved." };
    if (/^xoxb-/i.test(token)) {
      return { ok: false, error: "This is a BOT token (xoxb-) - the message would go in the bot's name. Use your USER token (xoxp-) so it posts as you." };
    }
    if (!channel || !ts) return { ok: false, error: "Thread link is missing." };
    if (!String(text || "").trim()) return { ok: false, error: "The message is empty." };

    // Best-effort: make sure this is the right outlet's thread (needs history scope; skipped if absent)
    let preview = "";
    try {
      const r = await slackApi("conversations.replies", token, { channel, ts, limit: 1 });
      if (r.ok && r.messages && r.messages[0]) {
        preview = String(r.messages[0].text || "").replace(/\s+/g, " ").trim().slice(0, 160);
        const wanted = (needles || []).map((n) => String(n || "").trim()).filter((n) => n.length >= 3);
        if (wanted.length && !force) {
          const low = preview.toLowerCase();
          const digits = String(r.messages[0].text || "").replace(/\D/g, "");
          const hit = wanted.some((n) => {
            const d = n.replace(/\D/g, "");
            return d.length >= 8 && d === n.replace(/[\s+\-().]/g, "") ? digits.includes(d) : low.includes(n.toLowerCase());
          });
          if (!hit) return { ok: false, code: "WRONG_THREAD", error: "This thread's first message doesn't mention this outlet.", preview };
        }
      }
    } catch (e) { /* ignore, check is optional */ }

    const r = await slackApi("chat.postMessage", token, { channel, thread_ts: ts, text, reply_broadcast: false, unfurl_links: false });
    if (!r.ok) return { ok: false, error: slackApiErrorText(r.error), apiError: r.error, preview };
    return { ok: true, confirmed: true, preview, posted: r.ts };
  } catch (e) {
    return { ok: false, error: "Could not reach Slack API: " + String((e && e.message) || e) };
  }
}

// Slack mrkdwn -> plain text, so the onboarding parser sees the same text you'd get by copying from Slack.
function slackToPlain(t) {
  return String(t || "")
    .replace(/<mailto:([^|>]+)\|([^>]+)>/g, "$2")
    .replace(/<tel:([^|>]+)(?:\|([^>]+))?>/g, (m, a, b) => b || a)
    .replace(/<(https?:[^|>]+)\|([^>]+)>/g, "$2")
    .replace(/<(https?:[^>]+)>/g, "$1")
    .replace(/<@([A-Z0-9]+)(?:\|([^>]+))?>/g, (m, id, n) => (n ? "@" + n : ""))
    .replace(/<#([A-Z0-9]+)\|([^>]+)>/g, "#$2")
    .replace(/<!([a-z]+)(?:\|([^>]+))?>/g, (m, k, n) => n || "@" + k)
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/\*([^*\n]+)\*/g, "$1")
    .replace(/`+/g, "")
    .replace(/[\u200b\u00a0]/g, " ");
}

// Reads the onboarding request from a Slack message link (needs history scope).
async function slackFetchMessage({ token, channel, ts }) {
  try {
    if (!token) return { ok: false, code: "NO_TOKEN", error: "Slack token is not saved." };
    if (!channel || !ts) return { ok: false, error: "Invalid Slack link." };
    const r = await slackApi("conversations.replies", token, { channel, ts, limit: 1 });
    if (!r.ok) {
      if (r.error === "missing_scope") {
        return { ok: false, code: "SCOPE", error: "Token can't read messages. In your Slack app add USER scopes channels:history (public) and groups:history (private channels), reinstall, and paste the new token." };
      }
      return { ok: false, error: slackApiErrorText(r.error), apiError: r.error };
    }
    const m = r.messages && r.messages[0];
    if (!m) return { ok: false, error: "Message not found - check the link." };
    let text = String(m.text || "");
    // Workflow/form posts keep their fields in blocks or attachments
    if (!text.trim() && Array.isArray(m.blocks)) {
      text = m.blocks
        .map((b) => (b.text && b.text.text) || (Array.isArray(b.fields) ? b.fields.map((f) => f.text).join("\n") : ""))
        .filter(Boolean)
        .join("\n");
    }
    if (!text.trim() && Array.isArray(m.attachments)) {
      text = m.attachments.map((a) => a.text || a.fallback || "").filter(Boolean).join("\n");
    }
    // Slack stores @mentions as <@U123> (ID only). The POC names live there, so resolve
    // every mention to a real name (needs the users:read scope).
    let unresolved = 0;
    const ids = [...new Set([...text.matchAll(/<@([UW][A-Z0-9]+)(?:\|[^>]*)?>/g)].map((x) => x[1]))];
    for (const id of ids) {
      let name = "";
      try {
        const u = await slackApi("users.info", token, { user: id });
        if (u.ok && u.user) {
          const pr = u.user.profile || {};
          name = pr.real_name || u.user.real_name || pr.display_name || u.user.name || "";
        }
      } catch (e) { /* counted below */ }
      if (name) text = text.split("<@" + id + ">").join("@" + name).replace(new RegExp("<@" + id + "\\|[^>]*>", "g"), "@" + name);
      else unresolved++;
    }
    text = slackToPlain(text).trim();
    if (!text) return { ok: false, error: "That message has no readable text." };
    return { ok: true, text, unresolved };
  } catch (e) {
    return { ok: false, error: "Could not reach Slack API: " + String((e && e.message) || e) };
  }
}

async function slackAuthTest(token) {
  try {
    const r = await slackApi("auth.test", token, {});
    if (!r.ok) return { ok: false, error: slackApiErrorText(r.error) };
    const isBot = !!r.bot_id || /^xoxb-/i.test(token);
    return { ok: true, team_id: r.team_id, user_id: r.user_id, user: r.user, team: r.team, isBot };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

async function slackPeek(preferTabId) {
  const tabs = await findSlackTabs(preferTabId);
  if (!tabs.length) return { ok: false, error: NO_SLACK_TAB };
  const tab = tabs[0];
  const out = { ok: true, tabId: tab.id, tabUrl: tab.url, thread: null, hasPane: false, preview: "", matched: null };
  const parsed = parseSlackThreadUrl(tab.url);
  if (parsed) out.thread = { ...parsed, url: tab.url };
  if (!tab.discarded) {
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: slackInjected, args: ["peek", "", [], false, 300] });
      const res = r && r[0] ? r[0].result : null;
      if (res && res.ok) { out.hasPane = true; out.preview = res.preview; }
    } catch (e) { /* peek is best-effort */ }
  }
  return out;
}

async function slackPost({ preferTabId, threadUrl, text, needles, force }) {
  try {
    if (!String(text || "").trim()) return { ok: false, error: "The message is empty." };
    const tabs = await findSlackTabs(preferTabId);
    if (!tabs.length) return { ok: false, code: "NO_TAB", error: NO_SLACK_TAB };
    let tab = tabs[0];
    if (tab.discarded) {
      return { ok: false, code: "ASLEEP", error: "The Slack tab is asleep (Memory Saver) - click that tab once, then try again." };
    }
    let waitMs = 4000;

    // A thread saved earlier (when the message was fetched) -> make sure Slack shows it
    const want = parseSlackThreadUrl(threadUrl);
    if (want) {
      const have = parseSlackThreadUrl(tab.url);
      if (!have || have.ts !== want.ts || have.channel !== want.channel) {
        await chrome.tabs.update(tab.id, { url: threadUrl });
        await waitTabComplete(tab.id, 30000);
        await new Promise((r) => setTimeout(r, 1500));
        waitMs = 25000;
      }
    }

    const r = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: slackInjected,
      args: ["post", String(text), Array.isArray(needles) ? needles : [], !!force, waitMs],
    });
    const res = r && r[0] ? r[0].result : null;
    if (!res) return { ok: false, error: "No response from the Slack tab." };
    return { ...res, tabId: tab.id };
  } catch (e) {
    return { ok: false, error: "The script did not run in the Slack tab: " + String((e && e.message) || e) };
  }
}

// ---------------------------------------------------------------------
// Table QR bulk download (separate feature -- only runs when the popup's
// QR button is clicked; nothing in onboarding / full setup calls these).
// ---------------------------------------------------------------------
let qrCsrfCache = { token: null, at: 0 };

async function getCsrfMeta() {
  if (qrCsrfCache.token && Date.now() - qrCsrfCache.at < 10 * 60 * 1000) return qrCsrfCache.token;
  for (const path of ["/admin/master-catalogue", "/admin/dashboard"]) {
    try {
      const r = await fetch(`${BASE_URL}${path}`, { credentials: "include" });
      const html = await r.text();
      const m = html.match(/<meta[^>]*name=["']csrf-token["'][^>]*content=["']([^"']+)["']/i);
      if (m) {
        qrCsrfCache = { token: m[1], at: Date.now() };
        return m[1];
      }
    } catch (e) {
      /* try next */
    }
  }
  return null;
}

// Walks every page of /api/admin/tmpos-tables and keeps only the rows that
// belong to the chosen outlet (store_id).
async function qrFetchTables(storeId) {
  const tables = [];
  let restName = "";
  let qrConfig = null;
  let page = 1;
  let lastPage = 1;
  do {
    const json = await apiGet(
      `/api/admin/tmpos-tables?page=${page}&q=&outlet_id=&department_id=&store_id=${encodeURIComponent(storeId)}`
    );
    const result = json && json.result;
    if (!result) throw new Error("Unexpected response from tmpos-tables (no 'result').");
    lastPage = result.last_page || 1;
    for (const row of result.data || []) {
      const store = row.store_info || {};
      const rowStore = store.store_id || row.store_id || "";
      if (rowStore && String(rowStore) !== String(storeId)) continue;
      const config = store.config || {};
      if (!qrConfig) {
        restName = store.name || "";
        qrConfig = {
          tableOrderQrCode: !!config.tableOrderQrCode,
          selfOrderQrCode: !!config.selfOrderQrCode,
          tableOrderWhatsAppQrCode: !!config.tableOrderWhatsAppQrCode,
          selfOrderWhatsAppQrCode: !!config.selfOrderWhatsAppQrCode,
        };
      }
      const rawActive =
        row.isactive !== undefined ? row.isactive : row.is_active !== undefined ? row.is_active : row.status !== undefined ? row.status : true;
      const isActive = !(rawActive === false || rawActive === 0 || rawActive === "0" || rawActive === "inactive");
      tables.push({
        id: String(row.id),
        name: row.table_name || `Table ${row.id}`,
        department: (row.department_info && row.department_info.department_name) || "General",
        isActive,
      });
    }
    progress(`QR: fetching tables... page ${page}/${lastPage} (${tables.length} so far)`);
    page++;
  } while (page <= lastPage);
  return { tables, restName, qrConfig };
}

const QR_WEBSITE_BUILDERS = {
  tableOrder: ({ storeId, tableId }) => `order.tmbill.com/outlet/${storeId}?table_id=${tableId}&table_order=true`,
  selfOrder: () => "order.tmbill.com",
};

async function qrGenerate({ tableId, tableName, restName, storeId, qrType, generateWhatsapp }) {
  const build = QR_WEBSITE_BUILDERS[qrType] || QR_WEBSITE_BUILDERS.tableOrder;
  const csrf = await getCsrfMeta();
  const resp = await apiFetch(`/api/admin/table-qr/${encodeURIComponent(tableId)}`, {
    method: "POST",
    headers: csrf ? { "X-CSRF-TOKEN": csrf } : {},
    body: JSON.stringify({
      website: build({ storeId, tableId }),
      store_logo: null,
      whatapp_account_id: 1,
      restName,
      table_name: tableName,
      generateWhatsAppQR: !!generateWhatsapp,
    }),
  });
  if (resp.status === 419 || resp.status === 401) {
    qrCsrfCache = { token: null, at: 0 };
    throw new Error("Session expired -- please log in again.");
  }
  const body = await readBody(resp);
  if (resp.status >= 400) throw new Error(formatHttpError(`QR for table ${tableId}`, resp, body));
  return body.json || {};
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.action) {
        case "PROGRESS":
          break;
        case "CHECK_SESSION": {
          // "Verify & Start": make sure the session belongs to the entered account. Any other
          // Back Office login is logged out first, then the entered credentials are used.
          if (msg.enforce && msg.masterEmail && msg.masterPassword) {
            try {
              progress("Signing out any other Back Office login...");
              await clearDomainCookies();
              session = { loggedIn: false, email: null, reused: false };
              await login(msg.masterEmail, msg.masterPassword);
              const authOk = await sessionLooksValid();
              // Open Back Office tabs would still show the old account - refresh them.
              try {
                const tabs = await chrome.tabs.query({ url: ["https://backoffice.tmbill.com/*"] });
                for (const t of tabs) if (!t.discarded) chrome.tabs.reload(t.id).catch(() => {});
              } catch (e) { /* best-effort */ }
              sendResponse({ ok: true, authenticated: authOk, identity: msg.masterEmail, forced: true });
            } catch (e) {
              sendResponse({ ok: false, authenticated: false, forced: true, error: String((e && e.message) || e) });
            }
            break;
          }
          let authenticated = await sessionLooksValid();
          // If the popup supplied a username and the user explicitly opted to remember
          // the password, attempt the site's normal CSRF-protected login flow automatically.
          if (!authenticated && msg.masterEmail && msg.masterPassword) {
            await ensureAuth(msg.masterEmail, msg.masterPassword);
            authenticated = await sessionLooksValid();
          }
          // This is the last account identity authenticated through the extension, not a
          // guaranteed profile identity for a session established manually in another tab.
          sendResponse({ ok: true, authenticated, identity: (session && session.email) ? session.email : null });
          break;
        }
        case "OPEN_BACKOFFICE_LOGIN": {
          const tabs = await chrome.tabs.query({ url: ["https://backoffice.tmbill.com/*"] });
          if (tabs.length) {
            const tab = tabs.find(t => !t.discarded) || tabs[0];
            await chrome.tabs.update(tab.id, { active: true });
            if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
            sendResponse({ ok: true, tabId: tab.id, reused: true });
          } else {
            const tab = await chrome.tabs.create({ url: "https://backoffice.tmbill.com", active: true });
            sendResponse({ ok: true, tabId: tab.id, reused: false });
          }
          break;
        }
        // NEW: Popup asks for existing table departments so the dropdown
        // can be populated (instead of blindly creating a new one).
        case "FETCH_PAYMENT_MODES": {
          if (msg.masterEmail) await ensureAuth(msg.masterEmail, msg.masterPassword);
          const r = await listPaymentModeNames(msg.store_id);
          sendResponse({ ok: true, names: r.names, selected: r.selected });
          break;
        }
        case "FETCH_DEPARTMENTS": {
          const departments = await listPosTableDepartments(msg.store_id);
          sendResponse({ ok: true, departments });
          break;
        }
        // NEW: Popup asks for the outlet list so the dropdown can be
        // populated for selecting which outlet to run Full Setup against.
        case "FETCH_OUTLETS": {
          const outlets = await listOutlets();
          sendResponse({ ok: true, outlets });
          break;
        }
        case "PARSE": {
          try {
            const st = await chrome.storage.local.get(ALIAS_KEY);
            customAliases = st[ALIAS_KEY] && typeof st[ALIAS_KEY] === "object" ? st[ALIAS_KEY] : {};
          } catch (e) {
            customAliases = {};
          }
          const parsed = parseDetails(msg.text);
          await inferLocation(parsed);
          sendResponse({ ok: true, data: parsed, unmapped: parsed.__unmapped || [], alts: parsed.__alts || {} });
          break;
        }
        case "WA_SEND": {
          sendResponse(await waSend(msg.items || [], msg.text || ""));
          break;
        }
        case "WA_SEND_QUICK": {
          sendResponse(await waSendQuick(msg.items || [], msg.text || "", !!msg.openIfMissing));
          break;
        }
        case "SLACK_PEEK": {
          sendResponse(await slackPeek(msg.preferTab));
          break;
        }
        case "SLACK_API_POST": {
          sendResponse(await slackApiPost(msg.params || {}));
          break;
        }
        case "SLACK_FETCH_MESSAGE": {
          sendResponse(await slackFetchMessage(msg.params || {}));
          break;
        }
        case "SLACK_AUTH_TEST": {
          const r = await slackAuthTest(msg.token);
          sendResponse(r);
          break;
        }
        case "AGENT_GET_STATE": {
          const st = await chrome.storage.local.get([AGENT_JOB_KEY, AGENT_HISTORY_KEY, AGENT_SETTINGS_KEY]);
          sendResponse({ ok: true, job: st[AGENT_JOB_KEY] || null, history: Array.isArray(st[AGENT_HISTORY_KEY]) ? st[AGENT_HISTORY_KEY] : [], settings: st[AGENT_SETTINGS_KEY] || {} });
          break;
        }
        case "AGENT_SET_MODE": {
          const mode = ["assisted", "smart_auto", "full_auto"].includes(String(msg.mode)) ? String(msg.mode) : "smart_auto";
          const st = await chrome.storage.local.get(AGENT_SETTINGS_KEY);
          const next = { slackAssignment: false, slackMentions: true, slackPocName: "", agentMode: "smart_auto", ...(st[AGENT_SETTINGS_KEY] || {}), agentMode: mode };
          await chrome.storage.local.set({ [AGENT_SETTINGS_KEY]: next });
          await scheduleSlackAssignmentMonitor();
          await agentLog("agent_mode_changed", { mode });
          sendResponse({ ok: true, mode });
          break;
        }
        case "AGENT_PROGRESS": {
          const patch = msg.patch && typeof msg.patch === "object" ? msg.patch : {};
          await agentSetJob(patch);
          await agentLog("agent_progress", patch);
          sendResponse({ ok: true });
          break;
        }
        case "AGENT_FINISH": {
          const patch = msg.patch && typeof msg.patch === "object" ? msg.patch : {};
          await agentSetJob(patch);
          await agentLog(patch.status === "completed" ? "agent_completed" : "agent_failed", patch);
          sendResponse({ ok: true });
          break;
        }
        case "AGENT_TEST": {
          await agentLog("agent_test_started");
          const r = await slackAssignmentPoll(true);
          await agentLog("agent_test_finished", { ok: !!r.ok, notified: r.notified || 0, error: r.error || "" });
          sendResponse(r);
          break;
        }
        case "AGENT_CLEAR_HISTORY": {
          await chrome.storage.local.remove(AGENT_HISTORY_KEY);
          sendResponse({ ok: true });
          break;
        }
        case "SLACK_ASSIGNMENT_SETTINGS_CHANGED": {
          await scheduleSlackAssignmentMonitor();
          sendResponse({ ok: true });
          break;
        }
        case "SLACK_ASSIGNMENT_POLL": {
          sendResponse(await slackAssignmentPoll(true));
          break;
        }
        case "SLACK_POST": {
          sendResponse(await slackPost(msg.params || {}));
          break;
        }
        case "WA_DIAG": {
          sendResponse(await waDiag());
          break;
        }
        case "SAVE_ALIAS": {
          // The user told us which field an unknown label means -> remember it.
          const label = normaliseLabel(String(msg.label || ""));
          if (label && msg.key) {
            const st = await chrome.storage.local.get(ALIAS_KEY);
            const map = st[ALIAS_KEY] && typeof st[ALIAS_KEY] === "object" ? st[ALIAS_KEY] : {};
            map[label] = msg.key;
            await chrome.storage.local.set({ [ALIAS_KEY]: map });
            customAliases = map;
          }
          sendResponse({ ok: true });
          break;
        }
        case "DRY_RUN": {
          const preview = await dryRunPreview({ ...msg.data });
          sendResponse({ ok: true, preview });
          break;
        }
        case "PREPARE_ONBOARDING": {
          const prepared = await prepareOnboarding({ ...msg.data });
          sendResponse({ ok: true, prepared, warnings: prepared.warnings || [] });
          break;
        }
        case "CHECK_MISSING": {
          // Exposed so the popup can (a) show manual-entry boxes for missing
          // outlet fields BEFORE anything is created, and (b) detect that the
          // outlet already exists so it is skipped and the rest continues.
          const d = { ...msg.data };
          await inferLocation(d);
          const testMode = !!d.testMode;
          const resumeMode = !!String(d.resumeStoreId || "").trim();
          let missing = requiredFields(d, testMode, resumeMode);
          let existingStoreId = "";
          if (!testMode && !resumeMode && !d.store_id && String(d.outlet_name || "").trim()) {
            try {
              await ensureAuth(d.masterEmail, d.masterPassword);
              let ex = await findExistingOutlet(d, { quick: true, allowNameOnly: true });
              if (!ex && missing.length) ex = await findExistingOutlet(d, { allowNameOnly: true });
              if (ex) existingStoreId = String(storeIdFromOutlet(ex) || "").trim();
            } catch (e) {
              /* lookup is best-effort; fall back to normal flow */
            }
          }
          if (existingStoreId) missing = missing.filter((k) => !OUTLET_REQUIRED.includes(k));
          const missingLabeled = missing.map((key) => ({ key, label: FIELD_LABELS[key] || key }));
          if (missing.length && missing.some((k) => ["outlet_name", "address", "pincode"].includes(k))) {
            // Escape hatch: outlet exists but wasn't auto-matched -> type its Store ID.
            missingLabeled.push({ key: "resumeStoreId", label: "OR existing Store ID (if the outlet is already created)" });
          }
          sendResponse({ ok: true, missing, missingLabeled, existingStoreId, data: d, review: buildReview(d, missing) });
          break;
        }
        case "PREFLIGHT": {
          const pf = await preflight({ ...msg.data }, msg.opts || {}, msg.storeId || "");
          sendResponse({ ok: true, steps: pf });
          break;
        }
        case "COMMIT_ONBOARDING": {
          const result = await commitOnboarding({ ...msg.data }, msg.prepared || {});
          sendResponse({
            ok: true,
            data: result.details,
            output: buildOutput(result.details),
            userSkipped: result.userSkipped,
            alreadyCreatedUser: result.alreadyCreatedUser,
          });
          break;
        }
        case "RUN_FULL_SETUP": {
          await ensureAuth(msg.data.masterEmail, msg.data.masterPassword);
          const outcome = await runFullSetup({ ...msg.data }, msg.opts || {});
          sendResponse({ ok: true, results: outcome.results, errors: outcome.errors, steps: outcome.steps, createdUsers: outcome.createdUsers || [] });
          break;
        }
        case "QR_FETCH_TABLES": {
          await ensureAuth(msg.masterEmail, msg.masterPassword);
          const info = await qrFetchTables(msg.store_id);
          sendResponse({ ok: true, ...info });
          break;
        }
        case "QR_TABLE": {
          const body = await qrGenerate(msg.params);
          sendResponse({ ok: true, body });
          break;
        }
        case "LOGOUT": {
          await clearDomainCookies();
          session = { loggedIn: false, email: null, reused: false };
          sendResponse({ ok: true });
          break;
        }
        case "DIAGNOSE_LOG": {
          sendResponse({ ok: true, matches: diagnoseLog(msg.text || "") });
          break;
        }
        default:
          sendResponse({ ok: false, error: "Unknown action: " + msg.action });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err.message || String(err) });
    }
  })();
  return true;
});
