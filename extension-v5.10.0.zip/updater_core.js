// One-click update system - shared pure helpers (used by the popup and the background worker).
// Updates are published as a signed update.json + extension-v<version>.zip on a PUBLIC static host
// (GitHub raw). Nothing downloaded is trusted unless the SHA-256 matches AND the ECDSA signature
// (made with the developer's private key) verifies against the public key below.
const UPDATE_PUBLIC_JWK = {"kty":"EC","crv":"P-256","x":"UVQcRm5_RMK-fZ5j7A3NkKKxizeVsuL8QzYSURmw6Sg","y":"8lXdfsgz_w7FqhAj915crkmGwlERzKDZKla3pIRdnxM"};
const UPDATE_DEFAULT_BASE = "https://raw.githubusercontent.com/saheel-word/tmbill-extension-releases/main";
const UPDATE_CFG_KEY = "tmbill_update_cfg";
const UPDATE_INFO_KEY = "tmbill_update_info";
const UPDATE_DISMISS_KEY = "tmbill_update_dismissed";
const UPDATE_ALARM = "tmbill_update_check";

const updVerOk = (v) => /^\d+(\.\d+){1,3}$/.test(String(v || ""));
function updCmpVer(a, b) {
  const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}
function updBaseOk(base) {
  return /^https:\/\/[^\s/]+(\/[^\s?#]*)?$/.test(base) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/[^\s?#]*)?$/.test(base);
}
const updHex = (buf) => Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
async function updSha256Hex(buf) { return updHex(await crypto.subtle.digest("SHA-256", buf)); }
function updB64ToBytes(b64) { const s = atob(String(b64)); const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
async function updVerifySig(version, sha256, signature) {
  try {
    const key = await crypto.subtle.importKey("jwk", UPDATE_PUBLIC_JWK, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    return await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, updB64ToBytes(signature), new TextEncoder().encode(version + "\n" + sha256));
  } catch (e) { return false; }
}

// Downloads update.json and checks it is genuine. -> { version, sha256, signature, notes[] }
async function updFetchInfo(base) {
  if (!updBaseOk(base)) throw new Error("The update source must be an https:// address.");
  const r = await fetch(base.replace(/\/+$/, "") + "/update.json?t=" + Date.now(), { cache: "no-store" });
  if (!r.ok) throw new Error("Update information not found (HTTP " + r.status + ").");
  const j = await r.json();
  if (!updVerOk(j.version) || !/^[0-9a-f]{64}$/.test(String(j.sha256 || "")) || !j.signature) throw new Error("update.json is not valid.");
  if (!(await updVerifySig(j.version, j.sha256, j.signature))) throw new Error("update.json signature is NOT valid - update refused.");
  return { version: j.version, sha256: j.sha256, signature: j.signature, notes: (Array.isArray(j.notes) ? j.notes : []).slice(0, 12).map((n) => String(n).slice(0, 200)) };
}

async function updCheck(base, current) {
  const info = await updFetchInfo(base);
  return { current, latest: info.version, newer: updCmpVer(info.version, current) > 0, info };
}

if (typeof module !== "undefined") module.exports = { updCmpVer, updBaseOk, updVerifySig, updSha256Hex, updFetchInfo, updCheck, UPDATE_PUBLIC_JWK };
