// Runs INSIDE the already-open web.whatsapp.com tab (MAIN world), injected on
// demand by the extension (chrome.scripting) -- no new tab, no navigation, no
// clicking through WhatsApp's UI. It uses WhatsApp Web's own internal modules
// (the same ones its UI calls) to: check the number is on WhatsApp, save it as
// a contact, and send a text message.
//
// WhatsApp changes these internals from time to time, so every step resolves
// its module by several candidate names, then by searching the module list,
// and reports precisely what it could not find (see diag()).
(() => {
  "use strict";
  const VERSION = 3;
  if (window.__tmbillWA && window.__tmbillWA.version === VERSION) return;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const getRequire = () => (typeof window.require === "function" ? window.require : null);

  function tryRequire(name) {
    const r = getRequire();
    if (!r) return null;
    try {
      return r(name) || null;
    } catch (e) {
      return null;
    }
  }

  // A module can export its API directly or under .default
  function pick(m, names) {
    if (!m) return null;
    for (const holder of [m, m.default]) {
      if (!holder) continue;
      for (const n of names) {
        if (typeof holder[n] === "function") return { fn: (...a) => holder[n](...a), name: n };
      }
    }
    return null;
  }

  let cachedNames = null;
  function moduleNames() {
    if (cachedNames) return cachedNames;
    try {
      const dbg = tryRequire("__debug");
      const map = dbg && (dbg.modulesMap || dbg.modules);
      cachedNames = map ? Object.keys(map) : [];
    } catch (e) {
      cachedNames = [];
    }
    return cachedNames;
  }

  // candidates: known module names; discovery: regex over all module names
  function resolveFn(candidates, fnNames, discovery) {
    for (const mn of candidates) {
      const p = pick(tryRequire(mn), fnNames);
      if (p) return { ...p, module: mn };
    }
    if (discovery) {
      for (const mn of moduleNames().filter((n) => discovery.test(n))) {
        const p = pick(tryRequire(mn), fnNames);
        if (p) return { ...p, module: mn };
      }
    }
    return null;
  }

  function resolveAll() {
    return {
      collections: tryRequire("WAWebCollections"),
      widFactory: resolveFn(["WAWebWidFactory"], ["createUserWid", "createWid"], /WidFactory/),
      exists: resolveFn(["WAWebQueryExistsJob", "WAWebQueryExist"], ["queryExists", "queryPhoneExists"], /QueryExist/),
      findChat: resolveFn(["WAWebFindChatAction"], ["findOrCreateLatestChat"], /FindChat/),
      send: resolveFn(
        ["WAWebChatSendMessages", "WAWebSendTextMsgChatAction", "WAWebSendMsgChatAction"],
        ["sendTextMsgToChat"],
        /Send.*(Msg|Message)|ChatSend/i
      ),
      save: resolveFn(
        ["WAWebSaveContactAction", "WAWebContactSaveAction"],
        ["saveContactAction", "saveContact", "addContact", "createContact"],
        /(Save|Add|Create).*Contact|Addressbook/i
      ),
    };
  }

  // Same rules as phone.js (the popup normally sends the full number already):
  // "9876543210" / "+91 98765 43210" / "09876543210" / "+91 0 98765 43210" -> "919876543210"; other countries as given.
  function normalizePhone(p) {
    let d = String(p || "").replace(/\D/g, "");
    if (d.startsWith("00")) d = d.slice(2);
    if (/^[6-9]\d{9}$/.test(d)) return "91" + d;
    if (/^0[6-9]\d{9}$/.test(d)) return "91" + d.slice(1);
    if (/^910[6-9]\d{9}$/.test(d)) return "91" + d.slice(3);
    return d;
  }
  function phoneProblem(d) {
    if (/^91[6-9]\d{9}$/.test(d)) return "";
    if (d.startsWith("91")) return "Indian number looks wrong (91 followed by 10 digits starting with 6-9)";
    if (d.length === 10) return "A 10-digit number must start with 6-9 - for another country, write it with the +country code";
    if (d.length < 8 || d.length > 15) return "The number does not look valid";
    return "";
  }

  function makeWid(api, phone) {
    const w = api.widFactory;
    if (!w) throw new Error("WhatsApp WID factory module not found");
    try {
      return w.name === "createUserWid" ? w.fn(phone, "c.us") : w.fn(phone + "@c.us");
    } catch (e) {
      // the two flavours take different args -- try the other one
      return w.name === "createUserWid" ? w.fn(phone + "@c.us") : w.fn(phone, "c.us");
    }
  }

  const getContact = (api, wid) => {
    try {
      return api.collections && api.collections.Contact && api.collections.Contact.get(wid);
    } catch (e) {
      return null;
    }
  };

  async function saveContact(api, wid, phone, name, overwrite) {
    if (!api.save) return { saved: false, saveError: "Contact-save function not found (WhatsApp may have updated)" };
    // Number already in the address book? Don't create a duplicate, and don't
    // silently rename someone's existing contact unless asked to.
    const existing = getContact(api, wid);
    const isSaved = !!(existing && (existing.isAddressBookContact === true || existing.isAddressBookContact === 1));
    if (isSaved) {
      const current = String(existing.name || existing.formattedName || "");
      if (current === name) return { saved: true, note: "already saved" };
      if (!overwrite) return { saved: true, kept: current };
    }

    // Argument order differs between WhatsApp builds; every attempt is verified.
    const attempts = [
      () => api.save.fn(phone, null, name, "", true),
      () => api.save.fn(phone, phone, name, "", true),
      () => api.save.fn({ phoneNumber: phone, firstName: name, lastName: "", syncToAddressbook: true }),
      () => api.save.fn(wid, name, "", true),
      () => api.save.fn(phone, name, "", true),
    ];
    let lastErr = "";
    for (const run of attempts) {
      try {
        await run();
        await sleep(400);
        const c = getContact(api, wid);
        if (c && (c.name === name || (!isSaved && c.isAddressBookContact === true))) return { saved: true };
      } catch (e) {
        lastErr = String((e && e.message) || e);
      }
    }
    return { saved: false, saveError: lastErr || "Contact save could not be verified" };
  }

  // Message appeared in the chat AND WhatsApp's server accepted it (ack >= 1: one tick or more).
  async function confirmSent(chat, text) {
    let found = false;
    let ack;
    for (let i = 0; i < 15; i++) {
      try {
        const msgs = chat.msgs;
        const arr = (msgs && (msgs.getModelsArray ? msgs.getModelsArray() : msgs.models)) || [];
        const m = arr.filter((x) => x && x.id && x.id.fromMe && x.body === text).pop();
        if (m) {
          found = true;
          ack = m.ack;
          if (ack === undefined || ack === null || ack >= 1) return { found, ack, confirmed: true };
        }
      } catch (e) {
        /* keep polling */
      }
      await sleep(400);
    }
    return { found, ack, confirmed: false };
  }

  async function sendOne(api, item, text) {
    const phone = normalizePhone(item.phone);
    const out = { phone: item.phone, ok: false, saved: false };
    const problem = phoneProblem(phone);
    if (problem) {
      out.error = problem;
      return out;
    }

    let wid = makeWid(api, phone);

    // 1) Is this number on WhatsApp at all? (stops a typo from messaging a stranger)
    if (api.exists) {
      let res;
      try {
        res = await api.exists.fn(wid);
      } catch (e) {
        try {
          res = await api.exists.fn(phone);
        } catch (e2) {
          res = undefined;
        }
      }
      if (res === null || res === false || (res && typeof res === "object" && "wid" in res && !res.wid)) {
        out.error = "This number is not on WhatsApp - choose another number, or copy the message and send it by SMS / call";
        out.notOnWhatsApp = true;
        return out;
      }
      if (res && res.wid) wid = res.wid;
    }

    // 2) Save it as a contact under the outlet name (skipped/kept if it is already saved)
    if (!item.skipSave) {
      const s = await saveContact(api, wid, phone, item.name, !!item.overwrite);
      out.saved = !!s.saved;
      if (s.kept !== undefined) out.keptName = s.kept;
      if (s.saveError) out.saveError = s.saveError;
    }

    // 3) Find/create the chat (does NOT open it in the UI) and send
    const found = await api.findChat.fn(wid);
    const chat = found && found.chat ? found.chat : found;
    if (!chat) {
      out.error = "Could not create the chat";
      return out;
    }
    await api.send.fn(chat, text, {});
    const c = await confirmSent(chat, text);
    out.confirmed = c.confirmed;
    if (c.ack !== undefined) out.ack = c.ack;
    out.ok = true;
    return out;
  }

  async function run(args) {
    const items = (args && args.items) || [];
    const text = String((args && args.text) || "");
    if (!getRequire()) {
      return { ok: false, error: "WhatsApp Web has not loaded or is not logged in (QR screen). The chat list should be visible in the tab." };
    }
    const api = resolveAll();
    if (!api.collections || !api.collections.Chat) {
      return { ok: false, error: "WhatsApp Web is still loading or is on the QR login screen.", diag: diagnose() };
    }
    if (!api.findChat || !api.send) {
      return { ok: false, error: "WhatsApp internal functions not found (WhatsApp Web has probably been updated).", diag: diagnose() };
    }
    if (!text.trim()) return { ok: false, error: "The message is empty" };

    const results = [];
    for (let i = 0; i < items.length; i++) {
      try {
        results.push(await sendOne(api, items[i], text));
      } catch (e) {
        results.push({ phone: items[i].phone, ok: false, saved: false, error: String((e && e.message) || e) });
      }
      if (i < items.length - 1) await sleep(1500);
    }
    return { ok: true, results };
  }

  function diagnose() {
    const api = resolveAll();
    const describe = (x) => (x ? `${x.module}.${x.name}` : null);
    const words = ["SaveContact", "AddContact", "Addressbook", "FindChat", "SendText", "SendMsg", "QueryExist", "WidFactory", "ChatSend"];
    const names = moduleNames();
    const matches = {};
    for (const w of words) matches[w] = names.filter((n) => n.includes(w)).slice(0, 12);
    return {
      hasRequire: !!getRequire(),
      hasCollections: !!(api.collections && api.collections.Chat),
      moduleCount: names.length,
      resolved: {
        widFactory: describe(api.widFactory),
        exists: describe(api.exists),
        findChat: describe(api.findChat),
        send: describe(api.send),
        save: describe(api.save),
      },
      matches,
    };
  }

  window.__tmbillWA = { version: VERSION, run, diag: async () => diagnose(), normalizePhone };
})();
