// Remembers what you fix while onboarding, applies the same fix next time, and (optionally) sends an
// ANONYMISED copy of the lessons to your own private GitHub repo so the next version can be improved.
//  - Local rules keep real text (e.g. "gamail.com" -> "gmail.com") and never leave this computer.
//  - What is sent to GitHub has no names, phones, e-mails, passwords, outlets or Slack content:
//    only field names, "shapes" (letters -> a/A, digits -> 9), e-mail domain typos and error categories.
(function () {
  const KEY = "tmbill_corrections_v1";
  const CFG = "tmbill_learn_share_v1";
  const FIELDS = ["outlet_name", "owner_name", "mobile", "email", "address", "pincode", "gst"];
  const MAX_LOG = 300;
  let baseline = {};
  const timers = {};

  const shape = (v) => String(v == null ? "" : v).slice(0, 60).replace(/[A-Z]/g, "A").replace(/[a-z]/g, "a").replace(/\d/g, "9");
  const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2));

  async function load() {
    try { const r = await chrome.storage.local.get(KEY); return Object.assign({ rules: [], log: [], device: "" }, r[KEY] || {}); }
    catch (e) { return { rules: [], log: [], device: "" }; }
  }
  async function save(m) { try { await chrome.storage.local.set({ [KEY]: m }); } catch (e) { /* ignore */ } }

  // ---- learn a rule from "was X, you made it Y" ----
  function derive(field, from, to) {
    from = String(from || ""); to = String(to || "");
    if (!from || !to || from === to) return null;
    if (field === "email" && from.includes("@") && to.includes("@")) {
      const [lf, df] = from.split("@"), [lt, dt] = to.split("@");
      if (lf === lt && df && dt && df !== dt) return { kind: "domain", find: "@" + df, replace: "@" + dt };
    }
    let p = 0;
    while (p < from.length && p < to.length && from[p] === to[p]) p++;
    let s = 0;
    while (s < from.length - p && s < to.length - p && from[from.length - 1 - s] === to[to.length - 1 - s]) s++;
    const find = from.slice(p, from.length - s), repl = to.slice(p, to.length - s);
    if (find.length >= 2 && find.length <= 40 && repl.length <= 60) return { kind: "token", find, replace: repl };
    return null;
  }

  async function noteOverride(field, value) {
    if (!FIELDS.includes(field)) return;
    clearTimeout(timers[field]);
    timers[field] = setTimeout(async () => {
      const from = String(baseline[field] == null ? "" : baseline[field]).trim();
      const to = String(value || "").trim();
      if (!to || from === to) return;
      const m = await load();
      if (!m.device) m.device = uuid();
      const entry = { at: new Date().toISOString(), field, kind: from ? "changed" : "filled", shapeFrom: shape(from), shapeTo: shape(to), sent: false };
      const r = from ? derive(field, from, to) : null;
      if (r) {
        entry.rule = r.kind;
        if (r.kind === "domain") { entry.domainFrom = r.find.slice(1); entry.domainTo = r.replace.slice(1); }
        const hit = m.rules.find((x) => x.field === field && x.find === r.find && x.replace === r.replace);
        if (hit) { hit.count++; hit.last = entry.at; }
        else m.rules.push({ id: uuid(), field, kind: r.kind, find: r.find, replace: r.replace, count: 1, last: entry.at });
      }
      m.log = [entry, ...m.log].slice(0, MAX_LOG);
      await save(m);
      try { statusEl.textContent = r ? "Fix noted - the same mistake will be corrected automatically next time." : "Correction noted."; } catch (e) { /* ignore */ }
      renderRules();
      scheduleAutoSend();
    }, 900);
  }

  // ---- apply learned rules to a fresh parse ----
  async function applyRules(data) {
    const m = await load();
    const applied = [];
    for (const r of m.rules) {
      if (!(r.kind === "domain" || r.count >= 2)) continue; // a token fix must be seen twice before it is trusted
      const v = data[r.field];
      if (typeof v === "string" && v.includes(r.find)) {
        const nv = v.split(r.find).join(r.replace).replace(/\s{2,}/g, " ").trim();
        if (nv && nv !== v) { data[r.field] = nv; applied.push(r.field); }
      }
    }
    baseline = Object.assign({}, data);
    return applied;
  }

  // ---- Learning Center: list of learned fixes ----
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  async function renderRules() {
    const box = document.getElementById("corrRules"); if (!box) return;
    const m = await load();
    document.getElementById("corrCount") && (document.getElementById("corrCount").textContent = m.log.length);
    box.innerHTML = m.rules.length
      ? m.rules.map((r) => `<div class="corr-rule"><span class="corr-f">${esc(r.field)}</span><span class="corr-x"><code>${esc(r.find)}</code> &rarr; <code>${esc(r.replace) || "(removed)"}</code></span><span class="corr-n">${r.kind === "domain" || r.count >= 2 ? "auto" : "seen " + r.count + "x"}</span><button type="button" class="corr-del" data-id="${esc(r.id)}" aria-label="Forget this fix">&times;</button></div>`).join("")
      : '<p class="hint small">Nothing learned yet. When you fix a detected detail, the correction is remembered here.</p>';
  }
  document.addEventListener("click", async (e) => {
    const b = e.target.closest && e.target.closest(".corr-del"); if (!b) return;
    const m = await load(); m.rules = m.rules.filter((r) => r.id !== b.dataset.id); await save(m); renderRules();
  });

  // ---- anonymised payload ----
  async function buildPayload(onlyUnsent) {
    const m = await load();
    const memErr = await chrome.storage.local.get("tmbill_learning_memory_v1");
    const runs = await chrome.storage.local.get("tmbill_run_log");
    const items = m.log.filter((x) => !onlyUnsent || !x.sent);
    const errors = ((memErr.tmbill_learning_memory_v1 || {}).errors || []).slice(0, 40).map((x) => ({ at: x.at, category: x.category, message: x.message }));
    const runSteps = (Array.isArray(runs.tmbill_run_log) ? runs.tmbill_run_log : []).slice(0, 40).map((r) => ({ ts: r.ts, steps: Object.fromEntries(Object.entries(r.steps || {}).map(([k, v]) => [k, v && (v.status || (v.ok ? "done" : "failed"))])) }));
    return { schema: 1, version: chrome.runtime.getManifest().version, device: m.device || "unset", sentAt: new Date().toISOString(),
      corrections: items.map(({ at, field, kind, shapeFrom, shapeTo, rule, domainFrom, domainTo }) => ({ at, field, kind, shapeFrom, shapeTo, rule, domainFrom, domainTo })),
      errors, runSteps };
  }

  // ---- send to GitHub (private repo, your own fine-grained token) ----
  async function cfg() {
    const r = await chrome.storage.local.get(CFG);
    const dev = window.TMBILL_LEARN || {};
    // auto-sharing is ON by default when the developer has configured the relay; the user can switch it off.
    return Object.assign({ repo: "", token: "", auto: false, share: true }, r[CFG] || {}, { endpoint: String(dev.endpoint || ""), key: String(dev.key || "") });
  }
  async function saveCfg(c) { await chrome.storage.local.set({ [CFG]: c }); }
  async function sendNow() {
    const c = await cfg();
    const relay = !!(c.endpoint && c.key);
    if (!relay && (!/^[\w.-]+\/[\w.-]+$/.test(c.repo) || !c.token)) return { ok: false, error: "Sharing is not set up yet." };
    if (relay && c.share === false) return { ok: false, error: "Sharing is switched off." };
    const m = await load();
    if (!m.device) { m.device = uuid(); await save(m); }
    const payload = await buildPayload(true);
    if (!payload.corrections.length && !payload.errors.length) return { ok: false, error: "Nothing new to send." };
    let r;
    if (relay) {
      try {
        const resp = await fetch(c.endpoint, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ action: "learning", _learnKey: c.key, device: m.device, payload }), redirect: "follow" });
        const j = await resp.json().catch(() => ({}));
        r = resp.ok && j.ok !== false ? { ok: true } : { ok: false, error: j.error || "HTTP " + resp.status };
      } catch (e) { r = { ok: false, error: String(e && e.message || e) }; }
    } else {
      r = await new Promise((res) => chrome.runtime.sendMessage({ action: "LEARN_PUSH", repo: c.repo, token: c.token, device: m.device, payload }, res));
    }
    if (r && r.ok) { const m2 = await load(); m2.log.forEach((x) => { x.sent = true; }); await save(m2); }
    return r || { ok: false, error: "No answer from the extension." };
  }
  let autoTimer = null;
  function scheduleAutoSend() {
    clearTimeout(autoTimer);
    autoTimer = setTimeout(async () => {
      const c = await cfg();
      const relay = !!(c.endpoint && c.key);
      if ((relay && c.share !== false) || (c.auto && c.repo && c.token)) { const r = await sendNow(); if (r && r.ok) setMsg("Shared (anonymous)."); }
    }, 6000);
  }
  function setMsg(t) { const el = document.getElementById("corrMsg"); if (el) el.textContent = t; }

  async function initUi() {
    const repo = document.getElementById("corrRepo"), tok = document.getElementById("corrToken"), auto = document.getElementById("corrAuto");
    if (!repo) return;
    const c = await cfg();
    repo.value = c.repo; tok.value = c.token; auto.checked = !!c.auto;
    const share = document.getElementById("corrShare"), stat = document.getElementById("corrState"), adv = document.getElementById("corrAdv");
    const relay = !!(c.endpoint && c.key);
    if (share) {
      share.checked = c.share !== false;
      const paint = () => { stat.textContent = relay ? (share.checked ? "Sharing is ON - lessons are sent automatically, nothing to set up." : "Sharing is OFF on this computer.") : "Automatic sharing is not set up yet - ask the developer, or use Advanced below."; };
      paint();
      share.addEventListener("change", async () => { const cur = await cfg(); await saveCfg({ repo: cur.repo, token: cur.token, auto: cur.auto, share: share.checked }); paint(); });
    }
    if (adv && relay) adv.style.display = "none";
    scheduleAutoSend();
    document.getElementById("corrSave").addEventListener("click", async () => {
      const v = repo.value.trim().replace(/^https?:\/\/github\.com\//i, "").replace(/\.git$/i, "").replace(/\/+$/, "");
      if (!/^[\w.-]+\/[\w.-]+$/.test(v)) { setMsg("Repo must look like owner/name."); return; }
      try { if (!(await chrome.permissions.contains({ origins: ["https://api.github.com/*"] })) && !(await chrome.permissions.request({ origins: ["https://api.github.com/*"] }))) { setMsg("Permission for GitHub was not granted."); return; } } catch (e) { /* ignore */ }
      await saveCfg({ repo: v, token: tok.value.trim(), auto: auto.checked, share: (await cfg()).share });
      repo.value = v; setMsg("Saved.");
    });
    document.getElementById("corrSend").addEventListener("click", async () => {
      setMsg("Sending..."); const r = await sendNow(); setMsg(r.ok ? "Sent. Thank you - it will help the next version." : "Not sent: " + (r.error || "unknown error"));
    });
    document.getElementById("corrPreview").addEventListener("click", async () => {
      const p = await buildPayload(false); const blob = new Blob([JSON.stringify(p, null, 2)], { type: "application/json" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "tmbill-what-would-be-sent.json"; a.click(); URL.revokeObjectURL(a.href);
    });
    document.getElementById("learningBtn")?.addEventListener("click", renderRules);
    renderRules();
  }
  window.tmbillCorr = { autoSend: scheduleAutoSend, noteOverride, applyRules, renderRules, buildPayload, sendNow, load };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initUi); else initUi();
})();
