// One-click update: apply a verified release to the extension folder (Load unpacked install).
// Needs updater_core.js and vendor/jszip.min.js. The folder is chosen ONCE (File System Access API),
// then every update = download -> verify (SHA-256 + signature) -> backup -> write -> reload.
const UPD_BACKUP_DIR = "update-backup";
const UPD_ALLOWED = /\.(js|json|html|css|png|jpg|jpeg|svg|ico|gif|webp|txt|md|gs|woff2?|ttf)$/i;

// ---- remember the chosen folder (IndexedDB) ----
function updIdb() {
  return new Promise((res, rej) => {
    const r = indexedDB.open("tmbill_updater", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("kv");
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function updGetDir() { try { const db = await updIdb(); return await new Promise((res) => { const q = db.transaction("kv").objectStore("kv").get("dir"); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); }); } catch (e) { return null; } }
async function updSetDir(h) { const db = await updIdb(); await new Promise((res, rej) => { const t = db.transaction("kv", "readwrite"); t.objectStore("kv").put(h, "dir"); t.oncomplete = res; t.onerror = () => rej(t.error); }); }

// ---- folder helpers (work on any FileSystemDirectoryHandle) ----
async function updDirFor(root, path, create) {
  const parts = path.split("/"); const name = parts.pop();
  let d = root;
  for (const p of parts) d = await d.getDirectoryHandle(p, { create: !!create });
  return { d, name };
}
async function updRead(root, path) { const { d, name } = await updDirFor(root, path, false); const f = await (await d.getFileHandle(name)).getFile(); return new Uint8Array(await f.arrayBuffer()); }
async function updWrite(root, path, bytes) {
  const { d, name } = await updDirFor(root, path, true);
  const w = await (await d.getFileHandle(name, { create: true })).createWritable();
  try { await w.write(bytes); await w.close(); }
  catch (e) { try { await w.abort(); } catch (e2) { /* already closed */ } throw e; } // never leave a locked file behind
}
async function updRemove(root, path) { try { const { d, name } = await updDirFor(root, path, false); await d.removeEntry(name); } catch (e) { /* already gone */ } }
async function updList(dir, prefix, out) {
  out = out || [];
  for await (const [name, h] of dir.entries()) {
    if (!prefix && name === UPD_BACKUP_DIR) continue;
    const p = prefix ? prefix + "/" + name : name;
    if (h.kind === "directory") await updList(h, p, out); else out.push(p);
  }
  return out;
}

// Applies release `info` (already checked by updFetchInfo) to `root`. Returns { from, to }.
// hooks.progress(text), hooks.reload() are optional. Throws on any problem; the old files are restored.
async function updApply(root, info, base, current, manifestName, hooks) {
  const say = (t) => { try { hooks && hooks.progress && hooks.progress(t); } catch (e) { /* ignore */ } };
  if (updCmpVer(info.version, current) <= 0) throw new Error("This version is not newer than the installed one.");

  say("Checking the extension folder...");
  let local;
  try { local = JSON.parse(new TextDecoder().decode(await updRead(root, "manifest.json"))); }
  catch (e) { throw new Error("The chosen folder does not contain manifest.json. Choose the folder where this extension is installed."); }
  if (local.name !== manifestName || local.version !== current) throw new Error("The chosen folder is not this installed extension (name/version differ). Choose the correct folder.");

  say("Downloading v" + info.version + "...");
  const r = await fetch(base.replace(/\/+$/, "") + "/extension-v" + info.version + ".zip?t=" + Date.now(), { cache: "no-store" });
  if (!r.ok) throw new Error("Download failed (HTTP " + r.status + ").");
  const buf = await r.arrayBuffer();

  say("Verifying the download...");
  if ((await updSha256Hex(buf)) !== info.sha256) throw new Error("The downloaded file is corrupted or was changed (SHA-256 mismatch). Update stopped.");
  if (!(await updVerifySig(info.version, info.sha256, info.signature))) throw new Error("Signature check failed. Update stopped.");

  const zip = await JSZip.loadAsync(buf);
  const entries = Object.values(zip.files).filter((f) => !f.dir);
  if (!entries.length || entries.length > 500) throw new Error("The update package has an unexpected number of files.");
  const files = [];
  let total = 0;
  for (const f of entries) {
    const n = f.name;
    if (n.startsWith("/") || n.includes("..") || n.includes("\\") || n.split("/")[0] === UPD_BACKUP_DIR || !UPD_ALLOWED.test(n)) throw new Error("The update package contains a file that is not allowed: " + n);
    const bytes = await f.async("uint8array");
    total += bytes.length;
    if (total > 40 * 1024 * 1024) throw new Error("The update package is too large.");
    files.push({ path: n, bytes });
  }
  const mf = files.find((f) => f.path === "manifest.json");
  if (!mf) throw new Error("The update package has no manifest.json.");
  let nm; try { nm = JSON.parse(new TextDecoder().decode(mf.bytes)); } catch (e) { throw new Error("manifest.json in the update is not valid."); }
  if (nm.manifest_version !== 3 || nm.name !== manifestName || nm.version !== info.version) throw new Error("The update's manifest does not match (name / version / manifest 3). Update stopped.");

  say("Backing up v" + current + "...");
  const old = await updList(root, "", []);
  const backupRoot = await root.getDirectoryHandle(UPD_BACKUP_DIR, { create: true });
  try { for await (const [name] of backupRoot.entries()) await backupRoot.removeEntry(name, { recursive: true }); } catch (e) { /* keep going */ }
  const bdir = await backupRoot.getDirectoryHandle("v" + current, { create: true });
  for (const p of old) await updWrite(bdir, p, await updRead(root, p));

  say("Installing v" + info.version + "...");
  const written = [];
  try {
    const ordered = files.filter((f) => f.path !== "manifest.json").concat([mf]); // manifest last
    for (const f of ordered) { await updWrite(root, f.path, f.bytes); written.push(f.path); }
  } catch (e) {
    say("Something failed - restoring v" + current + "...");
    try {
      for (const p of old) await updWrite(root, p, await updRead(bdir, p));
      for (const p of written) if (!old.includes(p)) await updRemove(root, p);
    } catch (e2) { throw new Error("Update failed AND restore failed: " + e2.message + ". Your previous files are in the '" + UPD_BACKUP_DIR + "' folder."); }
    throw new Error("Update failed and the previous version was restored: " + (e && e.message ? e.message : e));
  }
  say("Done - reloading the extension...");
  if (hooks && hooks.reload) hooks.reload();
  return { from: current, to: info.version };
}

if (typeof module !== "undefined") module.exports = { updApply, updList, updRead, updWrite };

// ================= UI (popup only) =================
if (typeof document !== "undefined" && document.getElementById("updBanner")) (function initUpdater() {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const cur = () => chrome.runtime.getManifest().version;
  const store = {
    get: (k) => new Promise((r) => { try { chrome.storage.local.get(k, (o) => r(o ? o[k] : undefined)); } catch (e) { r(undefined); } }),
    set: (k, v) => new Promise((r) => { try { chrome.storage.local.set({ [k]: v }, () => r()); } catch (e) { r(); } })
  };
  const cfg = async () => Object.assign({ base: UPDATE_DEFAULT_BASE, auto: true }, (await store.get(UPDATE_CFG_KEY)) || {});

  async function renderBanner() {
    const info = await store.get(UPDATE_INFO_KEY);
    const dismissed = await store.get(UPDATE_DISMISS_KEY);
    const b = $("updBanner");
    const tag = $("updSetTag");
    if (!info || !info.version || updCmpVer(info.version, cur()) <= 0 || dismissed === info.version) { b.style.display = "none"; if (tag) tag.style.display = "none"; return; }
    if (tag) tag.style.display = "";
    $("updText").innerHTML = `<b>Update available</b><br>Installed: v${esc(cur())} &nbsp;→&nbsp; New: v${esc(info.version)}` +
      ((info.notes || []).length ? "<ul>" + info.notes.map((n) => `<li>${esc(n)}</li>`).join("") + "</ul>" : "");
    b.style.display = "";
  }

  async function check(manual) {
    const c = await cfg();
    const msg = $("updMsg");
    try {
      const res = await updCheck(c.base, cur());
      await store.set(UPDATE_INFO_KEY, { version: res.latest, notes: res.info.notes, checkedAt: Date.now() });
      try { if (!res.newer) chrome.action.setBadgeText({ text: "" }); } catch (e) { /* ignore */ }
      if (manual && msg) msg.textContent = res.newer ? `Update v${res.latest} is available.` : `You are up to date (v${cur()}).`;
      await renderBanner();
      return res;
    } catch (e) {
      if (manual && msg) msg.textContent = "Could not check: " + (e && e.message ? e.message : e);
      return null;
    }
  }

  async function folderLabel() {
    const h = await updGetDir();
    $("updFolder").textContent = h ? "Update folder: " + h.name : "Update folder: found automatically when you press Update (one Chrome prompt, only once).";
  }
  async function pickFolder() {
    const h = await window.showDirectoryPicker({ mode: "readwrite", id: "tmbill-ext-folder" });
    await updSetDir(h); await folderLabel(); return h;
  }

  async function runUpdate() {
    const btn = $("updGo"); const note = $("updProgress");
    btn.disabled = true;
    const say = (t) => { note.textContent = t; try { statusEl.textContent = "Update: " + t; } catch (e) { /* ignore */ } };
    try {
      // 1) Folder access first (the browser only allows the prompts right after your click).
      let h = await updGetDir();
      if (h) {
        let p = await h.queryPermission({ mode: "readwrite" });
        if (p !== "granted") p = await h.requestPermission({ mode: "readwrite" });
        if (p !== "granted") h = null;
      }
      if (!h) {
        await uiAlert("Choose the folder where this extension is installed (the folder that contains manifest.json).\n\nThis is asked only once. In the next Chrome prompt press \"Edit files\" / \"Allow\".", { title: "Choose extension folder" });
        h = await pickFolder();
      }
      // 2) Re-check the release, then apply.
      const c = await cfg();
      say("Checking the latest version...");
      const res = await updCheck(c.base, cur());
      if (!res.newer) { say("You are already up to date."); await renderBanner(); return; }
      const out = await updApply(h, res.info, c.base, cur(), chrome.runtime.getManifest().name, {
        progress: say,
        reload: () => { store.set("tmbill_update_done", { from: cur(), to: res.info.version, ts: Date.now() }).then(() => setTimeout(() => chrome.runtime.reload(), 700)); }
      });
      say("Updated v" + out.from + " → v" + out.to);
    } catch (e) {
      if (e && e.name === "AbortError") { say("Cancelled."); }
      else { say("Update stopped: " + (e && e.message ? e.message : e)); await uiAlert(String((e && e.message) || e), { title: "Update stopped" }); }
    } finally { btn.disabled = false; }
  }

  $("updGo").addEventListener("click", runUpdate);
  $("updLater").addEventListener("click", async () => { const i = await store.get(UPDATE_INFO_KEY); if (i) await store.set(UPDATE_DISMISS_KEY, i.version); try { chrome.action.setBadgeText({ text: "" }); } catch (e) { /* ignore */ } renderBanner(); });
  $("updCheckBtn").addEventListener("click", async () => { $("updMsg").textContent = "Checking..."; await store.set(UPDATE_DISMISS_KEY, ""); await check(true); });
  $("updPickBtn").addEventListener("click", async () => { try { await pickFolder(); } catch (e) { /* cancelled */ } });
  // The source is fixed. Double-click the field to unlock it (only needed if the GitHub repo is ever renamed).
  $("updBase").addEventListener("dblclick", () => { $("updBase").readOnly = false; $("updSaveBase").style.display = ""; $("updMsg").textContent = "Source unlocked - edit and press Save source."; });
  $("updAuto").addEventListener("change", async () => { const c = await cfg(); c.auto = $("updAuto").checked; await store.set(UPDATE_CFG_KEY, c); });
  $("updSaveBase").addEventListener("click", async () => {
    const v = $("updBase").value.trim().replace(/\/+$/, "");
    if (!updBaseOk(v)) { $("updMsg").textContent = "The update source must start with https://"; return; }
    try { const o = new URL(v).origin + "/*"; if (chrome.permissions && !(await chrome.permissions.contains({ origins: [o] }))) { const ok = await chrome.permissions.request({ origins: [o] }); if (!ok) { $("updMsg").textContent = "Permission for that address was not granted."; return; } } } catch (e) { /* default host already allowed */ }
    const c = await cfg(); c.base = v; await store.set(UPDATE_CFG_KEY, c); $("updMsg").textContent = "Update source saved."; await check(true);
  });
  $("settingsBtn").addEventListener("click", async () => {
    const c = await cfg(); $("updBase").value = c.base; $("updAuto").checked = c.auto !== false;
    $("updVer").textContent = "Installed version: v" + cur(); await folderLabel();
  });

  window.tmbillUpdater = { check, renderBanner, runUpdate };
  // just after an update: say so once
  store.get("tmbill_update_done").then(async (d) => {
    if (d && d.to === cur()) { try { statusEl.textContent = `Extension updated to v${d.to} ✓`; } catch (e) { /* ignore */ } }
    if (d) await store.set("tmbill_update_done", null);
  });
  renderBanner();
  cfg().then(async (c) => { const i = await store.get(UPDATE_INFO_KEY); if (c.auto !== false && (!i || Date.now() - (i.checkedAt || 0) > 30 * 60 * 1000)) check(false); });
})();
