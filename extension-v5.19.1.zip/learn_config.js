// One-time developer setup (see SETUP_Learning_AutoShare.txt). Fill these two lines ONCE, build a release,
// and every colleague's extension shares anonymous lessons automatically - nobody has to configure anything.
// The key below can only append small anonymised JSON; it cannot read or change any client data.
window.TMBILL_LEARN = {
  endpoint: "",   // your Apps Script Web App URL (https://script.google.com/macros/s/.../exec)
  key: ""         // same value as the LEARN_KEY Script Property
};
