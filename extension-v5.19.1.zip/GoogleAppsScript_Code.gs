/** TMBill Smart Onboarding Agent -> INDIA Client Google Sheet
 * Deploy as a Web App, execute as your Google account, access: Anyone.
 * Protect the endpoint with Script Properties -> SHEETS_SHARED_SECRET.
 */
const SPREADSHEET_ID = '1rTtsPuXEC4Bzl0O5qLBZbtH1XDULUGUkbG31jOLJgVs';
const TARGET_SHEET_NAME = 'INDIA Client';

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const props = PropertiesService.getScriptProperties();
    // Anonymous learning data from the extension: its own low-privilege key, handled before the client-sheet secret.
    if (body.action === 'learning') return handleLearning_(body, props);
    // Backward-compatible: accept the documented name and the earlier UI name.
    const expected = props.getProperty('SHEETS_SHARED_SECRET') || props.getProperty('SHARED_SECRET') || '';
    if (!expected || !body._secret || !constantTimeEquals_(String(body._secret), expected)) {
      return json_({ ok: false, error: 'Unauthorized: shared secret mismatch.' });
    }
    if (body.test === true) return json_({ ok: true, message: 'Connection test passed. No row was added.' });
    if (!body.outlet_name || !String(body.outlet_name).trim()) {
      return json_({ ok: false, error: 'Outlet Name is required.' });
    }
    lock.waitLock(15000);
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheet = ss.getSheetByName(TARGET_SHEET_NAME);
    if (!sheet) return json_({ ok: false, error: 'Tab "' + TARGET_SHEET_NAME + '" not found.' });
    const lastCol = sheet.getLastColumn();
    if (lastCol < 1) return json_({ ok: false, error: 'The target tab has no header row.' });
    const headers = sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(h => String(h).trim());
    const norm = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const col = {};
    headers.forEach((h, i) => { col[norm(h)] = i; });
    const getCol = aliases => {
      for (const alias of aliases) if (Object.prototype.hasOwnProperty.call(col, norm(alias))) return col[norm(alias)];
      return -1;
    };
    const outletCol = getCol(['Outlet Name', 'Outlet', 'Restaurant Name']);
    if (outletCol < 0) return json_({ ok: false, error: 'Could not find an Outlet Name header in row 1.' });

    const storeIdCol = getCol(['Store ID', 'TMBill Store ID']);
    const emailCol = getCol(['Email', 'E-mail']);
    const contactCol = getCol(['Contact', 'Mobile', 'Phone']);
    const eventId = String(body.event_id || body.store_id || (body.outlet_name + '|' + body.email)).trim().toLowerCase();
    // Idempotency: if Store ID column exists, match it; otherwise match outlet + contact/email.
    const lastRow = sheet.getLastRow();
    if (lastRow >= 2) {
      const data = sheet.getRange(2, 1, lastRow - 1, lastCol).getDisplayValues();
      for (let r = 0; r < data.length; r++) {
        const existingOutlet = String(data[r][outletCol] || '').trim().toLowerCase();
        const existingStoreId = storeIdCol >= 0 ? String(data[r][storeIdCol] || '').trim() : '';
        const existingEmail = emailCol >= 0 ? String(data[r][emailCol] || '').trim().toLowerCase() : '';
        const existingContact = contactCol >= 0 ? String(data[r][contactCol] || '').replace(/\D/g, '') : '';
        if ((body.store_id && existingStoreId && existingStoreId === String(body.store_id)) ||
            (existingOutlet && existingOutlet === String(body.outlet_name).trim().toLowerCase() &&
             ((body.email && existingEmail === String(body.email).trim().toLowerCase()) ||
              (body.contact && existingContact === String(body.contact).replace(/\D/g, '')) ||
              (!body.email && !body.contact)))) {
          return json_({ ok: true, duplicate: true, row: r + 2, message: 'Matching client already exists; no duplicate row added.' });
        }
      }
    }

    const row = new Array(lastCol).fill('');
    const put = (aliases, value) => { const i = getCol(aliases); if (i >= 0 && value !== undefined && value !== null) row[i] = value; };
    put(['SR No', 'SR No.', 'Serial No', 'S No'], nextSerial_(sheet, getCol(['SR No', 'SR No.', 'Serial No', 'S No'])));
    put(['Outlet Name', 'Outlet', 'Restaurant Name'], body.outlet_name);
    put(['Tax Configuration', 'Tax Config', 'GST Configuration'], body.tax_configuration || '');
    put(['Email', 'E-mail'], body.email || '');
    put(['Contact', 'Mobile', 'Phone'], body.contact || '');
    put(['Package', 'Plan'], body.package || '');
    put(['Username', 'User Name', 'Login Username'], body.username || '');
    put(['Password', 'Login Password'], body.password || '');
    put(['Billing Status', 'Onboarding Status', 'Status'], body.billing_status || 'Onboarding complete');
    put(['Store ID', 'TMBill Store ID'], body.store_id || '');
    put(['Onboarding Completed At', 'Completed At', 'Timestamp'], body.completed_at || new Date().toISOString());
    sheet.appendRow(row);
    return json_({ ok: true, row: sheet.getLastRow(), message: 'Client added to INDIA Client.' });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}

function nextSerial_(sheet, srIndex) {
  if (srIndex < 0) return '';
  const last = sheet.getLastRow();
  if (last < 2) return 1;
  const vals = sheet.getRange(2, srIndex + 1, last - 1, 1).getValues().flat();
  let max = 0;
  vals.forEach(v => { const n = Number(v); if (Number.isFinite(n) && n > max) max = n; });
  return max + 1;
}
function constantTimeEquals_(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Anonymous lessons from the extension -> your PRIVATE GitHub repo (token stays here, never in the extension).
 * Script Properties: LEARN_KEY (required), GITHUB_TOKEN + GITHUB_REPO (e.g. saheel-word/tmbill-learning).
 * If GitHub is not set, lessons are appended to a "Learning" tab in the spreadsheet instead. */
function handleLearning_(body, props) {
  const key = props.getProperty('LEARN_KEY') || '';
  if (!key || !body._learnKey || !constantTimeEquals_(String(body._learnKey), key)) return json_({ ok: false, error: 'Unauthorized.' });
  const raw = JSON.stringify(body.payload || {});
  if (raw.length > 40000) return json_({ ok: false, error: 'Payload too large.' });
  const p = body.payload || {};
  const clean = { schema: 1, version: String(p.version || '').slice(0, 20), device: String(body.device || p.device || '').slice(0, 12), sentAt: new Date().toISOString(),
    corrections: Array.isArray(p.corrections) ? p.corrections.slice(0, 200) : [], errors: Array.isArray(p.errors) ? p.errors.slice(0, 60) : [], runSteps: Array.isArray(p.runSteps) ? p.runSteps.slice(0, 60) : [] };
  const token = props.getProperty('GITHUB_TOKEN'), repo = props.getProperty('GITHUB_REPO');
  if (token && repo) {
    const month = clean.sentAt.slice(0, 7);
    const path = 'learning/' + month + '/' + (clean.device || 'dev') + '-' + clean.sentAt.replace(/[:.]/g, '-') + '.json';
    const res = UrlFetchApp.fetch('https://api.github.com/repos/' + repo + '/contents/' + path, {
      method: 'put', contentType: 'application/json', muteHttpExceptions: true,
      headers: { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json' },
      payload: JSON.stringify({ message: 'learning ' + clean.version, content: Utilities.base64Encode(JSON.stringify(clean, null, 2), Utilities.Charset.UTF_8) })
    });
    const code = res.getResponseCode();
    if (code >= 200 && code < 300) return json_({ ok: true });
    return json_({ ok: false, error: 'GitHub ' + code });
  }
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sh = ss.getSheetByName('Learning') || ss.insertSheet('Learning');
  if (sh.getLastRow() === 0) sh.appendRow(['sentAt', 'version', 'device', 'json']);
  sh.appendRow([clean.sentAt, clean.version, clean.device, JSON.stringify(clean)]);
  return json_({ ok: true });
}
