// Loading screen, click feedback and "working" animations. Pure UI - no effect on the onboarding logic.
(function () {
  const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // 1) Loading screen: shows while the panel starts, then fades out
  const splash = document.getElementById("splash");
  if (splash) {
    const t0 = performance.now();
    const hide = () => {
      splash.classList.add("hide");
      setTimeout(() => splash.remove(), 450);
    };
    const go = () => setTimeout(hide, Math.max(0, (reduce ? 150 : 900) - (performance.now() - t0)));
    if (document.readyState === "complete") go(); else window.addEventListener("load", go);
    setTimeout(hide, 4000); // never block the panel
  }

  // 2) Click ripple on every button
  document.addEventListener("pointerdown", (e) => {
    if (reduce) return;
    const b = e.target.closest && e.target.closest("button, .btn-tile");
    if (!b || b.disabled || b.classList.contains("info-btn") || b.classList.contains("modal-close")) return;
    const r = b.getBoundingClientRect();
    const size = Math.max(r.width, r.height) * 1.6;
    const s = document.createElement("span");
    s.className = "ripple";
    s.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
    if (getComputedStyle(b).position === "static") b.style.position = "relative";
    b.style.overflow = "hidden";
    b.appendChild(s);
    setTimeout(() => s.remove(), 600);
  }, true);

  // 3) "Working" state: spinner on the current step + moving bar while an onboarding / Full Setup run is active
  const startBtn = document.getElementById("startBtn");
  const fsBtn = document.getElementById("fullSetupBtn");
  const bar = document.querySelector(".floating-bar-bottom");
  let lastBusy = false, t0 = 0, tick = null;
  const timeEl = document.getElementById("statusTime");
  const fmt = (ms) => { const s = Math.floor(ms / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
  function burst() {
    const card = document.getElementById("statusCard");
    if (!card || reduce) return;
    const colors = ["#8DC231", "#1D4A35", "#F5C542", "#E86A5B", "#4FB0C6"];
    for (let i = 0; i < 26; i++) {
      const s = document.createElement("i");
      s.className = "confetti";
      const ang = (Math.PI * 2 * i) / 26 + Math.random() * 0.4, dist = 40 + Math.random() * 70;
      s.style.cssText = `background:${colors[i % colors.length]};--dx:${Math.cos(ang) * dist}px;--dy:${Math.sin(ang) * dist - 24}px;--rot:${Math.round(Math.random() * 540)}deg;left:50%;top:50%`;
      card.appendChild(s);
      setTimeout(() => s.remove(), 1500);
    }
  }
  function sync() {
    const busy = !!(startBtn && startBtn.disabled) || !!(fsBtn && fsBtn.dataset.running === "1");
    if (busy === lastBusy) return;
    lastBusy = busy;
    document.body.classList.toggle("is-busy", busy);
    if (bar) bar.classList.toggle("working", busy);
    if (busy) { t0 = Date.now(); if (timeEl) timeEl.textContent = "0:00"; clearInterval(tick); tick = setInterval(() => { if (timeEl) timeEl.textContent = fmt(Date.now() - t0); }, 1000); }
    else { clearInterval(tick); if (timeEl && t0) timeEl.textContent = fmt(Date.now() - t0); }
    if (typeof renderChecklist === "function") renderChecklist();
    if (!busy) {
      if (t0 && !document.querySelector(".ck.failed") && document.querySelectorAll(".ck.done").length >= 2) burst();
      try { if (window.tmbillCorr) window.tmbillCorr.autoSend(); } catch (e) { /* optional */ }
      const st = document.getElementById("statusCard");
      if (st && !reduce) { st.classList.remove("flash"); void st.offsetWidth; st.classList.add("flash"); }
    }
  }
  if (startBtn) new MutationObserver(sync).observe(startBtn, { attributes: true, attributeFilter: ["disabled"] });
  setInterval(sync, 600);
})();

// Ctrl+Enter starts onboarding from anywhere (not while a popup is open)
document.addEventListener("keydown", (e) => {
  if (!(e.ctrlKey || e.metaKey) || e.key !== "Enter") return;
  if (document.querySelector('.modal-overlay[style*="flex"]')) return;
  const b = document.getElementById("startBtn");
  if (b && !b.disabled) { e.preventDefault(); b.click(); }
});
