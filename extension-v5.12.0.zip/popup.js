const inputEl = document.getElementById("input");
const outputEl = document.getElementById("output");
const statusEl = document.getElementById("status");
const parseBtn = document.getElementById("parseBtn");
const startBtn = document.getElementById("startBtn");
const logInputEl = document.getElementById("logInput");
const diagnoseBtn = document.getElementById("diagnoseBtn");
const diagnosisOutputEl = document.getElementById("diagnosisOutput");
const masterEmailEl = document.getElementById("masterEmail");
const masterPasswordEl = document.getElementById("masterPassword");
const rememberPasswordEl = document.getElementById("rememberPassword");
const forgetLoginBtn = document.getElementById("forgetLoginBtn");
const savedTagEl = document.getElementById("savedTag");
const autoPilotModeEl = document.getElementById("autoPilotMode");
const brandIdOverrideEl = document.getElementById("brandIdOverride");
const marketIdOverrideEl = document.getElementById("marketIdOverride");

const autoCreateMarketEl = document.getElementById("autoCreateMarket");
const newMarketNameEl = document.getElementById("newMarketName");
const autoCreateBrandEl = document.getElementById("autoCreateBrand");
const newBrandNameEl = document.getElementById("newBrandName");
const setupPosTablesEl = document.getElementById("setupPosTables");
const posDeptSelectEl = document.getElementById("posDeptSelect");
const posDeptNameEl = document.getElementById("posDeptName");
const posTableNamesEl = document.getElementById("posTableNames");
const posTableCountEl = document.getElementById("posTableCount");
const setupMenuEl = document.getElementById("setupMenu");
const posMenuNameEl = document.getElementById("posMenuName");
const setupPaymentModesEl = document.getElementById("setupPaymentModes");
const setupDigitalOrderingEl = document.getElementById("setupDigitalOrdering");
const setupDesignationEl = document.getElementById("setupDesignation");
const designationNameEl = document.getElementById("designationName");
const setupDiscountsEl = document.getElementById("setupDiscounts");
const setupUsersEl = document.getElementById("setupUsers");
const discountPercentNameEl = document.getElementById("discountPercentName");
const discountPercentRateEl = document.getElementById("discountPercentRate");
const discountFixedNameEl = document.getElementById("discountFixedName");
const discountFixedRateEl = document.getElementById("discountFixedRate");
const fullSetupBtn = document.getElementById("fullSetupBtn");
const fullSetupStatusEl = document.getElementById("fullSetupStatus");
const fullSetupOutputEl = document.getElementById("fullSetupOutput");
const checklistBoxEl = document.getElementById("checklistBox");
const missingFieldsRowEl = document.getElementById("missingFieldsRow");
const missingFieldsBoxEl = document.getElementById("missingFieldsBox");

let parsed = {};
const ASSIGNMENT_QUERY = new URLSearchParams(location.search);
const QUICK_ASSIGNMENT_MODE = ASSIGNMENT_QUERY.get("assignment") === "1" && ASSIGNMENT_QUERY.get("quick") === "1";
let quickProgressEl = null;
function ensureQuickProgress() {
  if (quickProgressEl) return quickProgressEl;
  quickProgressEl = document.createElement("div");
  quickProgressEl.id = "quickAssignmentOverlay";
  quickProgressEl.innerHTML = `<div class="quick-card"><div class="quick-spinner"></div><div class="quick-title">TMBill Onboarding</div><div class="quick-status" id="quickAssignmentStatus">Starting…</div><div class="quick-sub" id="quickAssignmentSub">Please keep Chrome open. Every completed step is verified.</div></div>`;
  document.body.appendChild(quickProgressEl);
  return quickProgressEl;
}
function quickProgress(title, sub="") {
  const el = ensureQuickProgress();
  const t = el.querySelector(".quick-status"); const s = el.querySelector(".quick-sub");
  if (t) t.textContent = title || "Working…"; if (s) s.textContent = sub || "Every completed step is verified before the next step.";
  el.style.display = "flex";
  try { chrome.runtime.sendMessage({ action: "AGENT_PROGRESS", patch: { status: "running", step: String(title || "Working…"), detail: String(sub || "") } }).catch(() => {}); } catch (e) {}
}
function quickProgressDone(ok, title, sub="") {
  const el = ensureQuickProgress();
  const spin = el.querySelector(".quick-spinner"); if (spin) spin.classList.toggle("done", !!ok);
  quickProgress(title, sub);
  try { chrome.runtime.sendMessage({ action: "AGENT_FINISH", patch: { status: ok ? "completed" : "attention", result: String(title || ""), detail: String(sub || ""), finishedAt: Date.now() } }).catch(() => {}); } catch (e) {}
}

// Values the user typed by hand for fields the pasted message didn't have
// (e.g. Owner Name / Mobile missing from the WhatsApp text). Kept separate
// from `parsed` so they survive a re-Parse of the same message and get
// re-merged in, instead of getting wiped out and re-triggering the same
// "Missing: ..." error every time.
let manualOverrides = {};

// State from the last PARSE (unknown "Label: value" lines + every value seen per field)
let lastUnmapped = [];
let lastAlts = {};

const REVIEW_FIELD_CHOICES = [
  ["outlet_name", "Outlet Name"],
  ["owner_name", "Owner Name"],
  ["mobile", "Mobile"],
  ["email", "Email"],
  ["address", "Address"],
  ["pincode", "Pincode"],
  ["username", "Username"],
  ["password", "Password"],
  ["gst", "GST No"],
];

function normalizeMobileClient(v) {
  const c = phoneCanonical(v);
  return c.kind === "bad" ? String(v || "").trim() : c.number;
}

function setOverride(key, value) {
  let v = String(value || "").trim();
  if (key === "mobile" && v) v = normalizeMobileClient(v);
  if (v) manualOverrides[key] = v;
  else delete manualOverrides[key];
}

// Re-run the field check with whatever is typed in the boxes (on blur).
let reviewRefreshBusy = false;
async function refreshReview() {
  if (reviewRefreshBusy || !parsed || !Object.keys(parsed).length) return;
  reviewRefreshBusy = true;
  try {
    const merged = applyManualOverrides({ ...parsed });
    merged.masterEmail = masterEmailEl.value.trim();
    merged.masterPassword = masterPasswordEl.value;
    await checkMissingFields(merged);
  } finally {
    reviewRefreshBusy = false;
  }
}

function renderMissingFields(missingLabeled, review) {
  missingLabeled = Array.isArray(missingLabeled) ? missingLabeled : [];
  review = Array.isArray(review) ? review : [];
  if (!review.length && !missingLabeled.length && !lastUnmapped.length) {
    missingFieldsRowEl.style.display = "none";
    missingFieldsBoxEl.innerHTML = "";
    document.getElementById("unmappedBox").innerHTML = "";
    return;
  }

  const rowHtml = (r) => {
    const cur = manualOverrides[r.key] !== undefined ? manualOverrides[r.key] : r.value || "";
    const alts = (lastAlts[r.key] || []).filter((x) => x && x !== cur);
    const chips = alts.length
      ? `<div class="rv-alts">${alts
          .map((x) => `<button type="button" class="rv-chip" data-alt-key="${r.key}" data-alt-val="${escapeHtml(x).replace(/"/g, "&quot;")}">Also in the message: ${escapeHtml(x)}</button>`)
          .join("")}</div>`
      : "";
    const star = r.status === "missing" ? ' <span class="rv-req">*</span>' : "";
    return `<div class="rv-row rv-${r.status}" data-status="${r.status}">
      <label for="manual_${r.key}">${escapeHtml(r.label)}${star}</label>
      <input type="text" id="manual_${r.key}" data-key="${r.key}" value="${escapeHtml(cur).replace(/"/g, "&quot;")}" placeholder="Enter value here" autocomplete="off" />
      ${r.msg ? `<div class="rv-msg">${escapeHtml(r.msg)}</div>` : ""}${chips}
    </div>`;
  };
  const extraRows = missingLabeled
    .filter((m) => !review.some((r) => r.key === m.key))
    .map((m) => rowHtml({ key: m.key, label: m.label, value: "", status: "missing", msg: "" }));

  missingFieldsBoxEl.innerHTML = review.map(rowHtml).concat(extraRows).join("");

  missingFieldsBoxEl.querySelectorAll("input[data-key]").forEach((el) => {
    el.addEventListener("input", () => {
      setOverride(el.dataset.key, el.value);
      // Live status: a field that now has a value is no longer red / yellow.
      const row = el.closest(".rv-row"); if (!row) return;
      const has = el.value.trim() !== "";
      const orig = row.dataset.status || "";
      row.classList.toggle("rv-missing", orig === "missing" && !has);
      row.classList.toggle("rv-warn", orig === "warn" && !has);
      row.classList.toggle("rv-filled", has);
      const msg = row.querySelector(".rv-msg"); if (msg) msg.style.display = has ? "none" : "";
      const star = row.querySelector(".rv-req"); if (star) star.style.display = has ? "none" : "";
    });
    el.addEventListener("change", () => { setOverride(el.dataset.key, el.value); refreshReview(); });
  });
  missingFieldsBoxEl.querySelectorAll("button[data-alt-key]").forEach((btn) => {
    btn.addEventListener("click", () => {
      setOverride(btn.dataset.altKey, btn.dataset.altVal);
      refreshReview();
    });
  });

  // Labels we couldn't map: pick the field once, it is remembered next time.
  const unBox = document.getElementById("unmappedBox");
  if (lastUnmapped.length) {
    unBox.innerHTML =
      `<div class="rv-un-head">These lines were not recognised - which field are they?</div>` +
      lastUnmapped
        .map(
          (u, i) => `<div class="rv-un">
        <div class="rv-un-text"><b>${escapeHtml(u.label)}</b>: ${escapeHtml(u.value)}</div>
        <select data-un="${i}">
          <option value="">Choose a field (remembered next time)</option>
          ${REVIEW_FIELD_CHOICES.map(([k, l]) => `<option value="${k}">${l}</option>`).join("")}
          <option value="__ignore">Ignore</option>
        </select>
      </div>`
        )
        .join("");
    unBox.querySelectorAll("select[data-un]").forEach((sel) => {
      sel.addEventListener("change", async () => {
        const u = lastUnmapped[Number(sel.dataset.un)];
        if (!u || !sel.value) return;
        if (sel.value !== "__ignore") {
          setOverride(sel.value, u.value);
          await send("SAVE_ALIAS", { label: u.label, key: sel.value });
          statusEl.textContent = `"${u.label}" will now always be read as ${sel.options[sel.selectedIndex].text}`;
        }
        lastUnmapped = lastUnmapped.filter((x) => x !== u);
        await refreshReview();
        if (!lastUnmapped.length) renderMissingFields(missingLabeled, review);
      });
    });
  } else {
    unBox.innerHTML = "";
  }

  missingFieldsRowEl.style.display = "";
  const firstBad = missingFieldsBoxEl.querySelector(".rv-missing input[data-key]");
  if (firstBad && !missingFieldsRowEl.contains(document.activeElement)) firstBad.focus();
}

// A fresh paste means a different client/outlet -- old manually-typed
// fixes (e.g. a previous outlet's Owner Name) shouldn't silently carry over
// and get attributed to the new one.
inputEl.addEventListener("input", () => {
  manualOverrides = {};
  lastUnmapped = [];
  lastAlts = {};
  renderMissingFields([]);
});

function applyManualOverrides(data) {
  for (const [key, val] of Object.entries(manualOverrides)) {
    if (val) data[key] = val; // what the user typed/fixed beats what was parsed
  }
  return data;
}

// Checks required fields for the current mode (Test/Resume/full) against
// `data`, already merged with any manually-typed overrides. Returns the
// missing list (empty = ready to go) and renders/hides the manual-entry box
// accordingly, so the user fixes it inline instead of hitting an alert().
// PARSE + remember the unknown lines / alternative values for the review panel.
async function parseText() {
  const resp = await send("PARSE", { text: inputEl.value });
  if (resp && resp.ok) {
    lastUnmapped = Array.isArray(resp.unmapped) ? resp.unmapped : [];
    lastAlts = resp.alts && typeof resp.alts === "object" ? resp.alts : {};
    // POC names may sit before or after their label, or on the next line.
    const ex = pocExtract(inputEl.value);
    if (resp.data) {
      if (ex.primary) resp.data.primary_poc = ex.primary;
      if (ex.secondary) resp.data.secondary_poc = ex.secondary;
    }
  }
  return resp;
}

// Shows who was picked as Primary / Secondary POC (from the message, or the
// defaults) and lets the user change it before anything is sent.
async function renderPocReview(data) {
  const box = document.getElementById("pocReviewBox");
  if (!box) return;
  await loadPoc();
  const d = data || {};
  const merged = applyManualOverrides({ ...d });
  const res = pocResolve(merged, pocState);
  const attr = (v) => escapeHtml(v).replace(/"/g, "&quot;");
  const names = pocState.roster.map((e) => e.name);
  const roleRow = (role, key, person, msgRaw, defName) => {
    const overridden = manualOverrides[key] !== undefined;
    const opts = ['<option value="">(from message / default)</option>']
      .concat(names.map((n) => `<option value="${attr(n)}" ${overridden && manualOverrides[key] === n ? "selected" : ""}>${escapeHtml(n)}</option>`))
      .join("");
    const detail = person
      ? [person.name, person.shift && `${person.shift} IST`, person.weekOff && `Off: ${person.weekOff}`, person.contact].filter(Boolean).join(" · ")
      : "";
    let msg;
    let cls = "ok";
    if (overridden) msg = `You chose: ${detail}`;
    else if (msgRaw && person && person.shift) msg = `From the message: "${msgRaw}" → ${detail}`;
    else if (msgRaw && person) { msg = `The message names "${msgRaw}", but they are not in the roster - only the name will be printed (add them with the POC button or choose someone here)`; cls = "warn"; }
    else if (person) msg = `No ${role} POC in the message - using the default: ${detail}`;
    else { msg = `No ${role} POC in the message - no ${role} POC will be added to the output`; cls = role === "Primary" ? "warn" : "optional"; }
    if (person && !pocContactOk(person.contact)) {
      cls = "missing";
      msg = `${person.name}: no contact number (required). Turn ON "POC details edit" in Settings (⚙), then add the number in the POC roster.`;
    }
    return `<div class="rv-row rv-${cls}">
      <label for="poc_sel_${key}">${role} POC</label>
      <select id="poc_sel_${key}" data-poc="${key}">${opts}</select>
      <div class="rv-msg">${escapeHtml(msg)}</div>
    </div>`;
  };
  box.innerHTML =
    `<div class="rv-un-head">POC (added under the login credentials)</div>` +
    roleRow("Primary", "primary_poc", res.primary, d.primary_poc, pocState.defaultPrimary) +
    roleRow("Secondary", "secondary_poc", res.secondary, d.secondary_poc, pocState.defaultSecondary);
  box.querySelectorAll("select[data-poc]").forEach((sel) => {
    sel.addEventListener("change", () => {
      setOverride(sel.dataset.poc, sel.value);
      renderPocReview(data);
    });
  });
}

async function checkMissingFields(data) {
  const resp = await send("CHECK_MISSING", { data });
  if (!resp.ok) return { missing: [], data };
  renderMissingFields(resp.missingLabeled, resp.review);
  renderPocReview(resp.data);
  return { missing: resp.missing || [], data: resp.data, existingStoreId: resp.existingStoreId || "", review: resp.review || [] };
}

// ── Setup checklist: shows what's done, what failed, what wasn't run ──────
const CHECKLIST_ITEMS = [
  { key: "outlet", label: "Outlet create/update" },
  { key: "user", label: "Owner/Manager user" },
  { key: "posTables", label: "POS Tables" },
  { key: "menu", label: "POS Menu" },
  { key: "paymentModes", label: "Payment Modes" },
  { key: "digitalOrdering", label: "Digital Ordering" },
  { key: "designation", label: "Designation" },
  { key: "users", label: "Users" },
  { key: "discounts", label: "Discounts" },
];
const FULL_SETUP_KEYS = ["posTables", "menu", "paymentModes", "digitalOrdering", "designation", "users", "discounts"];
const STATUS_ICON = { pending: "", done: "", failed: "", skipped: "" };

let checklist = {};

function resetChecklist() {
  checklist = {};
  for (const item of CHECKLIST_ITEMS) checklist[item.key] = { status: "pending", note: "" };
  renderChecklist();
}

function setChecklist(key, status, note) {
  checklist[key] = { status, note: note || "" };
  renderChecklist();
  logRunStep(key, status, note);
}

// ── Run log: every onboarding / Full Setup result, saved outlet-wise ───────
const RUN_LOG_KEY = "tmbill_run_log";
const RUN_LOG_MAX = 40;
let currentRun = null;
let runSaveTimer = null;

function currentOutletLabel() {
  const sel = document.getElementById("fsOutletSelect");
  const selText = sel && sel.value && sel.selectedOptions[0] ? sel.selectedOptions[0].text : "";
  return (typeof parsed !== "undefined" && parsed && parsed.outlet_name) || selText || "";
}

function startRun(outletName, storeId) {
  currentRun = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
    ts: Date.now(),
    outlet: String(outletName || "").trim(),
    storeId: String(storeId || "").trim(),
    steps: {},
  };
}

function logRunStep(key, status, note) {
  if (!currentRun || status === "pending") return;
  const name = currentOutletLabel();
  if (name && !currentRun.outlet) currentRun.outlet = name;
  if (typeof parsed !== "undefined" && parsed && parsed.store_id && !currentRun.storeId) currentRun.storeId = String(parsed.store_id);
  currentRun.steps[key] = { status, note: note || "" };
  currentRun.ts = Date.now();
  clearTimeout(runSaveTimer);
  runSaveTimer = setTimeout(persistRun, 250);
}

async function persistRun() {
  if (!currentRun) return;
  try {
    const stored = await chrome.storage.local.get(RUN_LOG_KEY);
    const list = Array.isArray(stored[RUN_LOG_KEY]) ? stored[RUN_LOG_KEY] : [];
    const i = list.findIndex((r) => r.id === currentRun.id);
    if (i >= 0) list[i] = currentRun;
    else list.unshift(currentRun);
    await chrome.storage.local.set({ [RUN_LOG_KEY]: list.slice(0, RUN_LOG_MAX) });
  } catch (e) { /* ignore */ }
}

function renderChecklist() {
  checklistBoxEl.innerHTML = CHECKLIST_ITEMS.map((item) => {
    const c = checklist[item.key] || { status: "pending", note: "" };
    const noteHtml = c.note ? `<span class="note">${escapeHtml(c.note)}</span>` : "";
    return `<div class="checklist-item ${c.status}"><span>${escapeHtml(item.label)}</span>${noteHtml}</div>`;
  }).join("");
}

resetChecklist();

// ── Pre-check: predicts pass/fail for every checklist step BEFORE running ──
const PRED_CLASS = { ok: "pred-ok", warn: "pred-warn", fail: "pred-fail", skip: "skipped" };
const PRED_PREFIX = { ok: "Will pass - ", warn: "Check - ", fail: "Will fail - ", skip: "" };

function applyPreflightToChecklist(steps) {
  for (const item of CHECKLIST_ITEMS) {
    const p = steps && steps[item.key];
    if (!p) continue;
    checklist[item.key] = { status: PRED_CLASS[p.level] || "pending", note: (PRED_PREFIX[p.level] || "") + (p.message || "") };
  }
  renderChecklist();
}

function buildTableFields(data) {
  const typedNames = posTableNamesEl.value.split(",").map((s) => s.trim()).filter(Boolean);
  const raw = posTableCountEl.value.trim();
  const count = raw ? parseInt(raw, 10) : 0;
  data.posDeptName = posDeptNameEl.value.trim() || "Dine In";
  if (typedNames.length) {
    const finalNames = continueTableNaming(typedNames, count);
    data.tableNames = finalNames;
    data.posTableCount = String(finalNames.length);
  } else {
    data.posTableCount = raw || "4";
  }
}

// useDropdown=true -> Full Setup mode (outlet chosen in the dropdown).
async function runPreflightUI(data, useDropdown) {
  try {
    const d = { ...data };
    d.masterEmail = masterEmailEl.value.trim();
    d.masterPassword = masterPasswordEl.value;
    buildTableFields(d);
    d.paymentModes = currentPayModes();
    d.paymentMasterLoaded = payMaster.length > 0;
    d.extraUsers = extraUsers.map((u) => ({ ...u, flags: { ...u.flags } }));
    const outletSelect = document.getElementById("fsOutletSelect");
    const storeId = useDropdown ? (outletSelect && outletSelect.value) || d.store_id || "" : "";
    const resp = await send("PREFLIGHT", { data: d, opts: currentFullSetupOpts(), storeId });
    if (resp.ok) applyPreflightToChecklist(resp.steps);
    // Missing outlet/user fields -> show the "Enter value here" boxes right now,
    // so they can be typed in and Pre-check run again.
    if (!useDropdown) await checkMissingFields({ ...d });
    return resp;
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
}

document.getElementById("precheckBtn").addEventListener("click", async () => {
  const btn = document.getElementById("precheckBtn");
  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = "Checking...";
  try {
    const parseResp = await parseText();
    const base = parseResp.ok ? applyManualOverrides(applyOverrides(parseResp.data)) : applyOverrides({ ...parsed });
    base.resumeStoreId = String(manualOverrides.resumeStoreId || "").trim();
    const outletSelect = document.getElementById("fsOutletSelect");
    const useDropdown = !inputEl.value.trim() && !!(outletSelect && outletSelect.value);
    const r = await runPreflightUI(base, useDropdown);
    statusEl.textContent = r.ok ? "Pre-check done - see the checklist" : "Pre-check failed: " + (r.error || "");
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
});

function send(action, data = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action, ...data }, (resp) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(resp || { ok: false, error: "Empty response (service worker asleep?). Try again." });
    });
  });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.action === "PROGRESS" && msg.text) {
    statusEl.textContent = msg.text;
  }
});

const MASTER_LOGIN_KEY = "tmbill_master_login";
const TEST_SETTINGS_KEY = "tmbill_test_settings";
const FULL_SETUP_KEY = "tmbill_full_setup_settings";
let saveTimer = null;
let testSaveTimer = null;
let fullSetupSaveTimer = null;

async function loadMasterLogin() {
  const stored = await chrome.storage.local.get([MASTER_LOGIN_KEY, TEST_SETTINGS_KEY, FULL_SETUP_KEY]);
  const creds = stored[MASTER_LOGIN_KEY];
  if (creds && creds.email) {
    masterEmailEl.value = creds.email;
    savedTagEl.textContent = creds.rememberPassword && creds.password ? "(login saved)" : "(email saved)";
    if (creds.rememberPassword && creds.password) {
      masterPasswordEl.value = creds.password;
      rememberPasswordEl.checked = true;
    }
    // Older builds may have stored a password without explicit opt-in. Remove
    // it unless the user has explicitly enabled Remember password on this device.
    if (Object.prototype.hasOwnProperty.call(creds, "password") && !creds.rememberPassword) {
      await chrome.storage.local.set({ [MASTER_LOGIN_KEY]: { email: creds.email } });
    }
  }
  const test = stored[TEST_SETTINGS_KEY];
  if (test) {
    brandIdOverrideEl.value = test.brandId || "";
    marketIdOverrideEl.value = test.marketId || "";
  }
  const fs = stored[FULL_SETUP_KEY];
  if (fs) {
    autoCreateMarketEl.checked = fs.autoCreateMarket !== false; // default ON
    newMarketNameEl.value = "India"; // default market is India
    autoCreateBrandEl.checked = !!fs.autoCreateBrand;
    newBrandNameEl.value = "";
    setupPosTablesEl.checked = fs.setupPosTables !== false;
    posDeptNameEl.value = fs.posDeptName || "";
    posTableNamesEl.value = fs.posTableNames || "";
    posTableCountEl.value = fs.posTableCount || "";
    setupMenuEl.checked = fs.setupMenu !== false;
    posMenuNameEl.value = fs.posMenuName || "";
    setupPaymentModesEl.checked = fs.setupPaymentModes !== false;
    setupDigitalOrderingEl.checked = !!fs.setupDigitalOrdering;
    setupDesignationEl.checked = !!fs.setupDesignation;
    designationNameEl.value = fs.designationName || "";
    setupDiscountsEl.checked = !!fs.setupDiscounts;
    if (fs.discountPercentName !== undefined) discountPercentNameEl.value = fs.discountPercentName;
    if (fs.discountPercentRate !== undefined) discountPercentRateEl.value = fs.discountPercentRate;
    if (fs.discountFixedName !== undefined) discountFixedNameEl.value = fs.discountFixedName;
    if (fs.discountFixedRate !== undefined) discountFixedRateEl.value = fs.discountFixedRate;
  }
  await refreshSessionTag();
}

function saveFullSetupSettingsDebounced() {
  clearTimeout(fullSetupSaveTimer);
  fullSetupSaveTimer = setTimeout(async () => {
    await chrome.storage.local.set({
      [FULL_SETUP_KEY]: {
        autoCreateMarket: autoCreateMarketEl.checked,
        autoCreateBrand: autoCreateBrandEl.checked,
        setupPosTables: setupPosTablesEl.checked,
        posDeptName: posDeptNameEl.value.trim(),
        posTableNames: posTableNamesEl.value.trim(),
        posTableCount: posTableCountEl.value.trim(),
        setupMenu: setupMenuEl.checked,
        posMenuName: posMenuNameEl.value.trim(),
        setupPaymentModes: setupPaymentModesEl.checked,
        setupDigitalOrdering: setupDigitalOrderingEl.checked,
        setupDesignation: setupDesignationEl.checked,
        designationName: designationNameEl.value.trim(),
        setupDiscounts: setupDiscountsEl.checked,
        discountPercentName: discountPercentNameEl.value.trim(),
        discountPercentRate: discountPercentRateEl.value.trim(),
        discountFixedName: discountFixedNameEl.value.trim(),
        discountFixedRate: discountFixedRateEl.value.trim(),
      },
    });
  }, 400);
}

[
  autoCreateMarketEl,
  newMarketNameEl,
  autoCreateBrandEl,
  newBrandNameEl,
  setupPosTablesEl,
  posDeptNameEl,
  posTableNamesEl,
  posTableCountEl,
  setupMenuEl,
  posMenuNameEl,
  setupPaymentModesEl,
  setupDigitalOrderingEl,
  setupDesignationEl,
  designationNameEl,
  setupDiscountsEl,
  discountPercentNameEl,
  discountPercentRateEl,
  discountFixedNameEl,
  discountFixedRateEl,
].forEach((el) => {
  el.addEventListener("input", saveFullSetupSettingsDebounced);
  el.addEventListener("change", saveFullSetupSettingsDebounced);
});

async function refreshSessionTag() {
  const resp = await send("CHECK_SESSION");
  if (resp.ok && resp.authenticated) {
    const extra = savedTagEl.textContent.includes("saved") ? "(saved, session active)" : "(session active)";
    savedTagEl.textContent = extra;
    // NEW: Once we know the session is valid, try to populate the outlet
    // dropdown so the user can select an outlet without pasting a message.
    loadOutletList();
  }
}

// NEW: Populate the Full Setup outlet dropdown from the backoffice outlet list.
async function loadOutletList() {
  const outletSelect = document.getElementById("fsOutletSelect");
  if (!outletSelect) return;
  const resp = await send("FETCH_OUTLETS");
  if (!resp.ok || !Array.isArray(resp.outlets)) return;
  while (outletSelect.options.length > 1) outletSelect.remove(1);
  resp.outlets.forEach((o) => {
    const option = document.createElement("option");
    option.value = o.store_id;
    option.textContent = `${o.outlet_name} (${o.store_id})`;
    outletSelect.appendChild(option);
  });
}

// NEW: When the user picks an outlet from the dropdown directly (without
// parsing a message first), fetch that outlet's table departments too.
(function wireOutletSelectChange() {
  const outletSelect = document.getElementById("fsOutletSelect");
  if (!outletSelect) return;
  outletSelect.addEventListener("change", () => {
    const optText = outletSelect.selectedOptions[0] ? outletSelect.selectedOptions[0].text : "";
    if (outletSelect.value && optText) autofillMarketBrand({ outlet_name: optText });
    if (outletSelect.value && typeof loadPayMaster === "function") loadPayMaster(outletSelect.value, true);
    if (outletSelect.value) {
      fetchDepartmentsForOutlet(outletSelect.value);
      fullSetupBtn.disabled = false;
    }
  });
})();

function saveMasterLoginDebounced() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const email = masterEmailEl.value.trim();
    const password = masterPasswordEl.value;
    if (!email) {
      await chrome.storage.local.remove(MASTER_LOGIN_KEY);
      savedTagEl.textContent = "";
      return;
    }
    const record = { email };
    if (rememberPasswordEl.checked && password) {
      record.password = password;
      record.rememberPassword = true;
    } else {
      record.rememberPassword = false;
    }
    await chrome.storage.local.set({ [MASTER_LOGIN_KEY]: record });
    savedTagEl.textContent = record.rememberPassword ? "(login saved)" : "(email saved)";
  }, 500);
}

function saveTestSettingsDebounced() {
  clearTimeout(testSaveTimer);
  testSaveTimer = setTimeout(async () => {
    await chrome.storage.local.set({
      [TEST_SETTINGS_KEY]: {
        brandId: brandIdOverrideEl.value.trim(),
        marketId: marketIdOverrideEl.value.trim(),
      },
    });
  }, 400);
}

masterEmailEl.addEventListener("input", saveMasterLoginDebounced);
masterPasswordEl.addEventListener("input", saveMasterLoginDebounced);
rememberPasswordEl.addEventListener("change", saveMasterLoginDebounced);
brandIdOverrideEl.addEventListener("input", saveTestSettingsDebounced);
marketIdOverrideEl.addEventListener("input", saveTestSettingsDebounced);

forgetLoginBtn.addEventListener("click", async () => {
  await chrome.storage.local.remove(MASTER_LOGIN_KEY);
  masterEmailEl.value = "";
  masterPasswordEl.value = "";
  rememberPasswordEl.checked = false;
  savedTagEl.textContent = "";
});

loadMasterLogin();

// Market / Brand names follow the outlet name (unless typed by hand).
function autofillMarketBrand(data) {
  const outlet = String((data && data.outlet_name) || "").trim();
  if (!outlet) return;
  if (!newMarketNameEl.dataset.manual) newMarketNameEl.value = (data.market_name || outlet);

  // Auto-create one POS billing user (same username as backoffice, password "1234")
  // so the client's sharing message always shows a POS login without manual steps.
  if (!newBrandNameEl.dataset.manual) newBrandNameEl.value = (data.brand_name || outlet);
}
for (const el of [newMarketNameEl, newBrandNameEl]) {
  el.addEventListener("input", () => {
    if (el.value.trim()) el.dataset.manual = "1";
    else delete el.dataset.manual;
  });
}

function applyOverrides(data) {
  const brand = brandIdOverrideEl.value.trim();
  const market = marketIdOverrideEl.value.trim();
  if (brand) data.brand_id = brand;
  if (market) data.market_id = market;
  data.testMode = false;
  data.testOutletId = "";

  data.autoCreateMarket = autoCreateMarketEl.checked;
  if (!data.market_name && newMarketNameEl.value.trim()) data.market_name = newMarketNameEl.value.trim();
  data.autoCreateBrand = autoCreateBrandEl.checked;
  if (!data.brand_name && newBrandNameEl.value.trim()) data.brand_name = newBrandNameEl.value.trim();
  // No name typed/parsed -> use the outlet's own name for market + brand.
  if (!data.market_name && data.outlet_name) data.market_name = data.outlet_name;
  if (!data.brand_name && data.outlet_name) data.brand_name = data.outlet_name;

  data.posDeptName = posDeptNameEl.value.trim() || "Dine In";
  data.posTableCount = posTableCountEl.value.trim() || "4";
  data.posMenuName = posMenuNameEl.value.trim() || "POS Menu";
  data.designationName = designationNameEl.value.trim() || "Manager, Cashier, Captain, Waiter";
  data.discountPercentName = discountPercentNameEl.value.trim();
  data.discountPercentRate = discountPercentRateEl.value.trim();
  data.discountFixedName = discountFixedNameEl.value.trim();
  data.discountFixedRate = discountFixedRateEl.value.trim();
  return data;
}

function currentFullSetupOpts() {
  return {
    posTables: setupPosTablesEl.checked,
    menu: setupMenuEl.checked,
    paymentModes: setupPaymentModesEl.checked && currentPayModes().length > 0,
    digitalOrdering: setupDigitalOrderingEl.checked,
    designation: setupDesignationEl.checked,
    users: setupUsersEl.checked,
    discounts: setupDiscountsEl.checked,
  };
}

function showParsed(data) {
  const shown = { ...data };
  delete shown.password;
  delete shown.pos_password;
  delete shown.masterPassword;
  outputEl.value = JSON.stringify(shown, null, 2);

  // Auto-populate outlet selector + department dropdown from parsed data
  updateOutletSelector(data);
}

// Update outlet selector from parsed data (adds/selects the current outlet)
function updateOutletSelector(data) {
  const outletSelect = document.getElementById("fsOutletSelect");
  if (!outletSelect) return;

  if (data.outlet_name || data.store_id) {
    const value = data.store_id || data.outlet_name || "";
    const label = `${data.outlet_name || "Current"} (${data.store_id || "ID pending"})`;
    let option = Array.from(outletSelect.options).find((o) => o.value === value);
    if (!option) {
      option = document.createElement("option");
      option.value = value;
      outletSelect.appendChild(option);
    }
    option.textContent = label;
    outletSelect.value = value;
  }

  if (data.store_id) {
    fetchDepartmentsForOutlet(data.store_id);
  }
}

// Fetch existing table departments for an outlet and fill the dropdown.
// Picking one from the dropdown copies its name into the plain text field
// (posDeptName) — that text field is what's actually sent to the backend,
// so there is only ONE source of truth for the department name.
async function fetchDepartmentsForOutlet(storeId) {
  if (!storeId) return;
  const deptSelect = posDeptSelectEl;
  if (!deptSelect) return;

  while (deptSelect.options.length > 1) deptSelect.remove(1);

  try {
    const resp = await send("FETCH_DEPARTMENTS", { store_id: storeId });
    if (resp.ok && Array.isArray(resp.departments)) {
      resp.departments.forEach((dept) => {
        const option = document.createElement("option");
        option.value = dept.name;
        option.textContent = dept.name;
        deptSelect.appendChild(option);
      });
    }
  } catch (e) {
    console.warn("Could not fetch departments:", e);
  }
}

// Selecting an existing department from the dropdown fills the plain text
// field with its exact name (which is what actually gets used/created).
if (posDeptSelectEl) {
  posDeptSelectEl.addEventListener("change", () => {
    if (posDeptSelectEl.value) {
      posDeptNameEl.value = posDeptSelectEl.value;
      saveFullSetupSettingsDebounced();
    }
  });
}

// Takes the names you actually typed (e.g. ["B1", "B2"]) and, if a target
// count is given and it's larger than what you typed, continues the SAME
// prefix+number pattern for the rest (B3, B4, B5, ...). If the last typed
// name doesn't end in a number (e.g. "Corner Booth"), nothing is guessed —
// only what you typed is used, since there's no safe pattern to continue.
// Leading zeros are preserved (e.g. "B01" continues as B02, B03, ...).
function continueTableNaming(typedNames, desiredCount) {
  if (!desiredCount || desiredCount <= typedNames.length) {
    return typedNames;
  }

  const last = typedNames[typedNames.length - 1];
  const match = /^(.*?)(\d+)$/.exec(last);
  if (!match) {
    // Can't detect a number to continue from — just use what was typed.
    return typedNames;
  }

  const prefix = match[1];
  const digits = match[2];
  const width = digits.length;
  let num = parseInt(digits, 10);

  const result = typedNames.slice();
  while (result.length < desiredCount) {
    num += 1;
    const numStr = String(num).padStart(width, "0");
    result.push(`${prefix}${numStr}`);
  }
  return result;
}

parseBtn.addEventListener("click", async () => {
  const slackCaptured = window.tmbillSlack ? window.tmbillSlack.capture() : null; // which Slack thread is this request from
  statusEl.textContent = "Fetching...";
  resetChecklist();
  const resp = await parseText();
  if (!resp.ok) {
    statusEl.textContent = "Fetch failed";
    alert(resp.error);
    return;
  }
  parsed = applyManualOverrides(applyOverrides(resp.data));
  parsed.resumeStoreId = "";
  if (window.tmbillSlack) await window.tmbillSlack.saveAfterParse(slackCaptured);
  showParsed(parsed);
  // All fields are now optional - no mandatory field check needed
  autofillMarketBrand(parsed);
  statusEl.textContent = `Fetched ${Object.keys(parsed).length} fields ✓ - reading details...`;
  await runPreflightUI({ ...parsed }, false);
  // Popup: check the detected details (POC etc.), press OK, then the process continues.
  await reviewPopup();
  statusEl.textContent = `Details confirmed ✓ - running pre-check...`;
  await runPreflightUI({ ...parsed }, false);
  statusEl.textContent = `Fetched ${Object.keys(parsed).length} fields ✓ - see the predicted pass/fail in the checklist`;
});

// Shows "Detected details - check & fix" as a popup; resolves when OK is pressed.
function reviewPopup() {
  return new Promise((resolve) => {
    const modal  = document.getElementById("reviewModal");
    const body   = document.getElementById("reviewModalBody");
    // Check if there's anything meaningful to show
    const mfb   = document.getElementById("missingFieldsBox");
    const pocb  = document.getElementById("pocReviewBox");
    const unmb  = document.getElementById("unmappedBox");
    const hasContent = (mfb && mfb.innerHTML.trim()) || (pocb && pocb.innerHTML.trim()) || (unmb && unmb.innerHTML.trim());
    if (!modal || !hasContent) { resolve(); return; }
    // Move content boxes into the modal body if not already there
    [mfb, unmb, pocb].forEach((el) => { if (el && !body.contains(el)) body.appendChild(el); });
    modal.style.display = "flex";
    document.body.classList.add("review-modal-open");
    const okBtn     = document.getElementById("reviewOkBtn");
    const cancelBtn = document.getElementById("reviewCancelBtn");
    const close = (confirmed) => {
      modal.style.display = "none";
      document.body.classList.remove("review-modal-open");
      okBtn     && okBtn.removeEventListener("click", onOk);
      cancelBtn && cancelBtn.removeEventListener("click", onCancel);
      resolve(confirmed);
    };
    const onOk     = () => close(true);
    const onCancel = () => close(false);
    okBtn     && okBtn.addEventListener("click", onOk);
    cancelBtn && cancelBtn.addEventListener("click", onCancel);
    // ESC to cancel
    const onKey = (e) => { if (e.key === "Escape") { document.removeEventListener("keydown", onKey); close(false); } };
    document.addEventListener("keydown", onKey);
    // Focus first input in modal
    setTimeout(() => { const first = modal.querySelector("input, select, textarea"); if (first) first.focus(); }, 60);
  });
}

let onboardingBusy = false;

startBtn.addEventListener("click", async () => {
  if (QUICK_ASSIGNMENT_MODE) quickProgress("Reading client assignment…", "Parsing Slack request and validating client details.");
  const masterEmail = masterEmailEl.value.trim();
  const masterPassword = masterPasswordEl.value;

  if (onboardingBusy) return;
  onboardingBusy = true;
  startBtn.disabled = true;
  try {
    const parseResp = await parseText();
    if (!parseResp.ok) {
      alert(parseResp.error);
      return;
    }
    parsed = applyManualOverrides(applyOverrides(parseResp.data));
    autofillMarketBrand(parsed);
    startRun(parsed.outlet_name, parsed.store_id);

    // Assignment notifications can be opened while Back Office is logged out.
    // Open/reuse the Back Office tab and wait for a verified session before any writes.
    if (QUICK_ASSIGNMENT_MODE) {
      if (typeof quickProgress === "function") quickProgress("Checking Back Office login…", "No active session detected. Opening Back Office; please sign in there. Onboarding will resume automatically after the session is verified.");
      statusEl.textContent = "Checking Back Office session…";
      const enforce = !!window.__enforceLogin; window.__enforceLogin = false;
      let sessionCheck = await send("CHECK_SESSION", { masterEmail, masterPassword, enforce });
      if (enforce && sessionCheck && sessionCheck.forced && !sessionCheck.authenticated) {
        const why = sessionCheck.error || "Back Office did not accept the username / password.";
        if (typeof quickProgressDone === "function") quickProgressDone(false, "Back Office login failed", why + " Check the username / password and press Start Onboarding again. No onboarding changes were made.");
        statusEl.textContent = "Back Office login failed - no changes made";
        return;
      }
      if (!sessionCheck || !sessionCheck.ok || !sessionCheck.authenticated) {
        await send("OPEN_BACKOFFICE_LOGIN");
        let authenticated = false;
        const deadline = Date.now() + 120000;
        while (Date.now() < deadline) {
          await new Promise(resolve => setTimeout(resolve, 2500));
          sessionCheck = await send("CHECK_SESSION");
          if (sessionCheck && sessionCheck.ok && sessionCheck.authenticated) {
            authenticated = true;
            break;
          }
        }
        if (!authenticated) {
          if (typeof quickProgressDone === "function") quickProgressDone(false, "Back Office login required", "Please sign in to backoffice.tmbill.com in the opened tab, then click Start Onboarding again. No onboarding changes were made.");
          statusEl.textContent = "Back Office login not verified — no changes made";
          return;
        }
      }
      // Explicit human confirmation before any onboarding write. Never claim a manually
      // established session's identity unless the extension can reliably identify it.
      const detectedIdentity = sessionCheck && sessionCheck.identity ? String(sessionCheck.identity) : "";
      const ACCT_KEY = "tmbill_acct_confirmed";
      let recentOk = false;
      try { const a = await chrome.storage.local.get(ACCT_KEY); recentOk = !!(a[ACCT_KEY] && Date.now() - a[ACCT_KEY] < 12 * 3600 * 1000); } catch (e) { /* ask again */ }
      if (!recentOk) {
        const ok = await uiConfirm(
          "Back Office is signed in.\n\n" + (detectedIdentity ? `Account: ${detectedIdentity}\n\n` : "") + "Check the account shown in the Back Office tab. Continue onboarding with it?\n\n(You will not be asked again for 12 hours.)",
          { title: "Confirm Back Office account", okText: "Yes, continue", cancelText: "Cancel" }
        );
        if (!ok) {
          if (typeof quickProgressDone === "function") quickProgressDone(false, "Confirmation required", "You cancelled account confirmation. No onboarding changes were made.");
          statusEl.textContent = "Cancelled before changes - account not confirmed";
          return;
        }
        try { await chrome.storage.local.set({ [ACCT_KEY]: Date.now() }); } catch (e) { /* ignore */ }
      }
      if (typeof quickProgress === "function") quickProgress("Back Office connected", "Account confirmation received. Continuing onboarding.");
    }
    parsed.masterEmail = masterEmail;
    parsed.masterPassword = masterPassword;
    parsed.resumeStoreId = String(manualOverrides.resumeStoreId || "").trim();

    // "Create Outlet" unticked: outlet already exists -> skip it, continue with the later steps.
    const createOutletEl = document.getElementById("createOutletMode");
    if (createOutletEl && !createOutletEl.checked) {
      const sel = document.getElementById("fsOutletSelect");
      const cand = [sel && sel.value, parsed.resumeStoreId, parsed.store_id].map((x) => String(x || "").trim());
      const sid = cand.find((x) => /^\d{6,}$/.test(x));
      if (!sid) {
        alert('"Outlet" is unticked in Full Setup, so pick the existing outlet in "Select Outlet" first.');
        statusEl.textContent = "Select the existing outlet, then press Start again";
        return;
      }
      parsed.store_id = sid;
      parsed.resumeStoreId = sid;
      fullSetupBtn.disabled = false;
      statusEl.textContent = `Outlet creation skipped (Store ID ${sid}) - running the next steps...`;
      setChecklist("outlet", "done", `Skipped - existing ${sid}`);
      const r = await runFullSetupFlow({ silent: false, storeId: sid });
      statusEl.textContent = r === "failed" ? `Some steps failed - Store ID ${sid}` : `DONE (outlet skipped) - Store ID ${sid}`;
      return;
    }

    // Partial onboarding is allowed (tables only, user only, ...). But if an
    // outlet is being created and outlet fields are missing, ask for them
    // here (manual-entry box) instead of failing halfway. If the outlet
    // already exists, skip creating it and continue with the rest.
    if (QUICK_ASSIGNMENT_MODE) quickProgress("Verifying client details…", "Checking required fields, existing outlet matches and POC contacts.");
    statusEl.textContent = "Running pre-check...";
    await runPreflightUI({ ...parsed }, false);

    statusEl.textContent = "Checking outlet details...";
    const chk = await checkMissingFields(parsed);
    if (chk.missing.length) {
      statusEl.textContent = "Missing fields - fill the box below, then press Start Onboarding again";
      setChecklist("outlet", "failed", "Missing: " + chk.missing.join(", "));
      return;
    }
    // POC contact numbers are mandatory for every POC that will be printed.
    await loadPoc();
    const pocBad = pocProblems(applyManualOverrides({ ...(chk.data || parsed) }), pocState);
    if (pocBad.length) {
      const msg =
        "A POC contact number is required:\n\n" +
        pocBad.map((p) => `- ${p.role} POC (${p.name}): ${p.reason}`).join("\n") +
        "\n\nTurn ON \"POC details edit\" in Settings (⚙), add the numbers in the POC roster, then press Start again.";
      statusEl.textContent = "POC contact number missing - onboarding stopped";
      setChecklist("outlet", "failed", "POC contact number missing");
      alert(msg);
      return;
    }
    const suspicious = (chk.review || []).filter((r) => r.status === "warn");
    if (suspicious.length) {
      if (QUICK_ASSIGNMENT_MODE) {
        quickProgressDone(false, "Verification required", suspicious.map((r) => `${r.label}: ${r.value} (${r.msg})`).join(" • "));
        statusEl.textContent = "Quick onboarding paused - details need verification";
        return;
      }
      const okGo = await uiConfirm(
        "These details look wrong:\n\n" +
          suspicious.map((r) => `- ${r.label}: ${r.value} (${r.msg})`).join("\n") +
          "\n\nContinue anyway, or go back and fix them first?",
        { title: "Check these details", okText: "Continue anyway", cancelText: "Go back & fix" }
      );
      if (!okGo) {
        statusEl.textContent = "Cancelled - fix the details and press Start again";
        return;
      }
    }
    parsed = chk.data || parsed;
    // Back Office username / password come from the message / Slack thread only - never invented.
    if (!parsed.username || !parsed.password) {
      statusEl.textContent = "Looking for the Back Office login in the Slack thread...";
      const tc = window.tmbillSlack && window.tmbillSlack.credsFromThread ? await window.tmbillSlack.credsFromThread() : null;
      if (tc) { parsed.username = parsed.username || tc.username; parsed.password = parsed.password || tc.password; }
    }
    if (!parsed.username || !parsed.password) {
      const typed = await askOwnerCreds(parsed.username, parsed.password);
      if (typed) { parsed.username = typed.username; parsed.password = typed.password; }
    }
    if (parsed.username && parsed.password) {
      try { showParsed(parsed); } catch (e) { /* ignore */ }
      await patchOwnerCredsInOutput(parsed.username, parsed.password);
    } else {
      statusEl.textContent = "Back Office username / password not provided - the owner login will not be created.";
    }
    if (chk.existingStoreId) {
      parsed.resumeStoreId = chk.existingStoreId;
      statusEl.textContent = `Outlet already exists (Store ID ${chk.existingStoreId}) - skipping outlet create...`;
    }

    if (QUICK_ASSIGNMENT_MODE) quickProgress("Preparing TMBill…", "Checking session, brand and market before any write operation.");
    statusEl.textContent = "Preparing (session / brand / market)...";
    const prepared = await send("PREPARE_ONBOARDING", { data: parsed });
    if (!prepared.ok) {
      statusEl.textContent = "Prepare failed";
      setChecklist("outlet", "failed", prepared.error);
      await showFailure(prepared.error);
      return;
    }

    const warnings = prepared.warnings || [];
    if (warnings.length) {
      if (QUICK_ASSIGNMENT_MODE) {
        quickProgressDone(false, "Verification required", warnings.join(" • "));
        statusEl.textContent = "Quick onboarding paused - pre-check warning";
        return;
      }
      const ok = await uiConfirm(warnings.join("\n") + "\n\nContinue?", { title: "Please confirm", okText: "Yes, continue" });
      if (!ok) {
        statusEl.textContent = "Cancelled";
        return;
      }
    }

    if (QUICK_ASSIGNMENT_MODE) quickProgress("Creating client…", "Writing outlet/user data and waiting for a verified Store ID.");
    statusEl.textContent = "Creating outlet + user...";
    const resp = await send("COMMIT_ONBOARDING", { data: parsed, prepared: prepared.prepared });
    if (!resp.ok) {
      statusEl.textContent = "Onboarding failed";
      setChecklist("outlet", "failed", resp.error);
      await showFailure(resp.error);
      return;
    }
    parsed = resp.data;
    setOutputText(resp.output);
    // Best-effort Sheet sync after TMBill confirms the outlet/user creation.
    // Do not fail onboarding if Google Sheets is unavailable.
    try {
      const sheetResult = await syncOnboardingToIndiaClient(parsed);
      if (sheetResult && !sheetResult.skipped) {
        if (sheetResult.ok) statusEl.textContent = `TMBill onboarding done – Store ID: ${parsed.store_id} · INDIA Client Sheet synced`;
        else statusEl.textContent = `TMBill onboarding done – Store ID: ${parsed.store_id} · Sheet sync failed: ${sheetResult.error || "check Settings"}`;
      }
    } catch (sheetError) {
      statusEl.textContent = `TMBill onboarding done – Store ID: ${parsed.store_id} · Sheet sync error: ${sheetError.message}`;
    }
    // Save the login-credentials output to History right away (outlet-wise),
    // instead of waiting for a manual Copy.
    try {
      const histOutlet = (resp.data && resp.data.outlet_name) || (parsed && parsed.outlet_name) || "";
      await addToHistory(outputEl.value, histOutlet, { phones: window.tmbillWA ? window.tmbillWA.collect() : [] });
    } catch (e) { /* history is best-effort */ }
    const extra = resp.userSkipped ? " (user skipped)" : "";
    statusEl.textContent = `DONE – Store ID: ${resp.data.store_id}${extra}`;
    setChecklist("outlet", "done", `Store ID ${resp.data.store_id}`);
    if (resp.userSkipped) {
      const d = resp.data || {};
      const need = [["owner_name", "owner name"], ["email", "email"], ["mobile", "mobile"], ["username", "username"], ["password", "password"]].filter(([k]) => !d[k]).map(([, l]) => l);
      setChecklist("user", "skipped", "Owner user NOT created" + (need.length ? " - missing: " + need.join(", ") : ""));
    } else {
      setChecklist("user", "done", resp.alreadyCreatedUser ? "Already existed" : "");
    }
    if (resp.data && resp.data.store_id) {
      fullSetupBtn.disabled = false;
      fullSetupStatusEl.textContent = "Store ready — Full Setup can be run now.";
    }

    if ((autoPilotModeEl.checked || QUICK_ASSIGNMENT_MODE) && resp.data && resp.data.store_id) {
      if (QUICK_ASSIGNMENT_MODE) quickProgress("Running Full Setup…", "Completing selected setup modules and verifying each result.");
      statusEl.textContent = "Auto-Pilot: Running Full Setup...";
      const setupResult = await runFullSetupFlow({ silent: true, storeId: String(resp.data.store_id) });
      if (setupResult === "done") {
        statusEl.textContent = `DONE (Auto-Pilot) – Store ID: ${resp.data.store_id}${extra}`;
        if (QUICK_ASSIGNMENT_MODE) await finishQuickAssignment(resp.data, "Full Setup verified");
        else { await offerWhatsApp(); await offerSlackPost(); }
      } else if (setupResult === "failed") {
        statusEl.textContent = `Onboarding DONE, but some Full Setup steps failed in Auto-Pilot — Store ID: ${resp.data.store_id}`;
        if (QUICK_ASSIGNMENT_MODE) { quickProgressDone(false, "Full Setup needs attention", "The client was created, but one or more selected setup steps failed. No completion message was sent to Slack."); }
        else { alert("Outlet/user created, but some Full Setup steps failed in Auto-Pilot — see the Full Setup output below."); await offerWhatsApp(); }
      } else {
        if (QUICK_ASSIGNMENT_MODE) await finishQuickAssignment(resp.data, "Client created and verified");
        else await offerWhatsApp();
      }
    } else {
      if (QUICK_ASSIGNMENT_MODE) await finishQuickAssignment(resp.data, "Client created and verified");
      else await offerWhatsApp(); // manual flow: WhatsApp now, the Slack post is offered after Submit
    }
  } finally {
    startBtn.disabled = false;
    onboardingBusy = false;
    refreshSessionTag();
  }
});

fullSetupBtn.addEventListener("click", async () => {
  const r = await runFullSetupFlow({ silent: false });
  if (r === "done") await offerSlackPost();
});

async function runFullSetupFlow(options) {
  const silent = !!(options && options.silent);

  // Outlet: use the dropdown selection if picked, otherwise fall back to
  // whatever was parsed/created earlier in this session.
  const outletSelect = document.getElementById("fsOutletSelect");
  // Auto-Pilot passes the outlet that was JUST created/reused; never let a
  // previously selected dropdown value hijack it.
  const selectedStoreId = (options && options.storeId) || outletSelect?.value || parsed?.store_id;

  if (!selectedStoreId) {
    if (!silent) alert("Select an outlet in Full Setup (or create one with Start Onboarding), then press Submit.");
    return "no-op";
  }

  const opts = currentFullSetupOpts();
  if (QUICK_ASSIGNMENT_MODE) opts.users = true;
  if (!Object.values(opts).some(Boolean)) {
    if (!silent) alert("Tick at least one step in Full Setup (or use Select all).");
    return "no-op";
  }

  // Auto-Pilot continues the run that onboarding just started; a manual
  // Submit starts a fresh one for the selected outlet.
  if (!silent || !currentRun) startRun(currentOutletLabel(), selectedStoreId);
  if (currentRun && !currentRun.storeId) currentRun.storeId = String(selectedStoreId);
  const dataForSetup = applyOverrides({ ...parsed });
  dataForSetup.store_id = selectedStoreId;
  dataForSetup.masterEmail = masterEmailEl.value.trim();
  dataForSetup.masterPassword = masterPasswordEl.value;
  // Always inject POS credentials so the sharing / buildOutput message is correct:
  // username = same as backoffice owner (or auto-created billing row), password = "1234"
  {
    const billingRow = extraUsers.find((u) => u.typeKey === "billing");
    const posUser = (billingRow && billingRow.username) || dataForSetup.username || "";
    dataForSetup.pos_username = posUser;
    dataForSetup.pos_password = "1234";
  }

  // Tables: type the first few names yourself, and the rest continue in
  // the SAME pattern automatically — e.g. type "B1, B2" + count 5, and
  // B3, B4, B5 are added on their own so you don't have to type every one.
  if (opts.posTables) {
    dataForSetup.posDeptName = posDeptNameEl.value.trim() || "Dine In";
    const typedNames = posTableNamesEl.value
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    const desiredCountRaw = posTableCountEl.value.trim();
    const desiredCount = desiredCountRaw ? parseInt(desiredCountRaw, 10) : 0;

    if (typedNames.length) {
      const finalNames = continueTableNaming(typedNames, desiredCount);
      dataForSetup.tableNames = finalNames;
      dataForSetup.posTableCount = String(finalNames.length);
    } else {
      dataForSetup.posTableCount = desiredCountRaw || "4";
    }
  }

  if (opts.paymentModes) {
    dataForSetup.paymentModes = currentPayModes();
    dataForSetup.paymentMasterLoaded = payMaster.length > 0;
  }

  if (opts.users) {
    const rows = extraUsers.filter((u) => u.typeKey !== "pos").map((u) => ({ ...u, flags: { ...u.flags } }));
    // Ticking "Create Users" always creates the POS billing user by itself:
    // username = Back Office username (+1, +2 ... if that name is taken), password 1234.
    if (!rows.some((u) => u._defaultPos)) {
      const ownerU = String(dataForSetup.username || usersOwnerUsername() || "").trim() || usersBaseName();
      rows.unshift({ typeKey: "pos", username: ownerU, password: "1234", name: "POS Billing", designation: "cashier", flags: userFlagsFor("pos"), _defaultPos: true });
    }
    const check = userValidate(rows, usersOwnerUsername() || dataForSetup.username || "");
    if (!rows.length || check.errors.length) {
      const msg = !rows.length
        ? "Add at least one user row (or untick Create Users)."
        : "Fix these before creating users:\n\n- " + check.errors.join("\n- ");
      if (!silent) { alert(msg); return "no-op"; }
      opts.users = false; // Auto-Pilot: skip only this step, the rest still runs
      setChecklist("users", "failed", !rows.length ? "No user rows added" : check.errors[0]);
    } else {
      dataForSetup.extraUsers = rows;
      if (!silent && !(await uiConfirm(usersConfirmText(rows, check.warnings), { title: "Create these users?", okText: "Create users" }))) return "no-op";
    }
  }

  if (!silent) await runPreflightUI(dataForSetup, true);

  fullSetupBtn.disabled = true;
  fullSetupStatusEl.textContent = "Running full setup...";
  fullSetupOutputEl.innerHTML = "";
  try {
    const resp = await send("RUN_FULL_SETUP", { data: dataForSetup, opts });
    if (!resp.ok) {
      fullSetupStatusEl.textContent = "Full setup failed";
      fullSetupOutputEl.innerHTML = `<div class="match"><div class="why">❌ ${escapeHtml(resp.error)}</div></div>`;
      return "failed";
    }
    const results = Array.isArray(resp.results) ? resp.results : [];
    const errors = Array.isArray(resp.errors) ? resp.errors : [];
    if (Array.isArray(resp.createdUsers) && resp.createdUsers.length) {
      const added = await attachUsersToOutput(resp.createdUsers);
      results.push(added ? `✅ ${resp.createdUsers.length} user login(s) added to the credentials message and History` : "ℹ️ Created user logins were not added to a message (no onboarding output for this outlet)");
    }
    fullSetupStatusEl.textContent = `Done — ${results.length} ok, ${errors.length} failed`;
    fullSetupOutputEl.innerHTML = [...results, ...errors]
      .map((line) => `<div class="match"><div class="why">${escapeHtml(line)}</div></div>`)
      .join("");

    for (const key of FULL_SETUP_KEYS) {
      const stepResult = resp.steps && resp.steps[key];
      if (stepResult) {
        setChecklist(key, stepResult.ok ? "done" : "failed", stepResult.message);
      } else if (!opts[key] && checklist[key] && checklist[key].status === "pending") {
        setChecklist(key, "skipped", "Not selected");
      }
    }
    return errors.length ? "failed" : "done";
  } finally {
    fullSetupBtn.disabled = false;
  }
}

async function showFailure(error) {
  logInputEl.value = error || "";
  const diagResp = await send("DIAGNOSE_LOG", { text: error || "" });
  if (diagResp.ok) renderDiagnosis(diagResp.matches, error);
  alert(error);
}

function renderDiagnosis(matches) {
  matches = Array.isArray(matches) ? matches : [];
  if (!matches.length) {
    diagnosisOutputEl.innerHTML = `<div class="none">This specific error was not recognized. Send me this text as-is, I can add the pattern.</div>`;
    return;
  }
  diagnosisOutputEl.innerHTML = matches
    .map(
      (m) => `<div class="match"><div class="why">⚠️ ${escapeHtml(m.why)}</div><div class="fix">👉 ${escapeHtml(m.fix)}</div></div>`
    )
    .join("");
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s == null ? "" : String(s);
  return div.innerHTML;
}

diagnoseBtn.addEventListener("click", async () => {
  const text = logInputEl.value.trim();
  if (!text) {
    alert("Please paste error/log text first.");
    return;
  }
  const resp = await send("DIAGNOSE_LOG", { text });
  if (!resp.ok) {
    alert(resp.error);
    return;
  }
  renderDiagnosis(resp.matches);
});

// ===== POC roster (editable). Matching/formatting lives in poc.js =====
const POC_KEY2 = "tmbill_poc_v2";
const POC_KEY_OLD = "tmbill_poc"; // earlier single-POC version
let pocState = pocDefaultState();

async function loadPoc() {
  try {
    const st = await chrome.storage.local.get([POC_KEY2, POC_KEY_OLD]);
    const v2 = st[POC_KEY2];
    if (v2 && Array.isArray(v2.roster) && v2.roster.length) {
      pocState = pocMigrate(v2); // an older saved roster is upgraded to the current official list
      if ((v2.version || 1) < POC_ROSTER_VERSION) {
        try { await chrome.storage.local.set({ [POC_KEY2]: pocState }); } catch (e) { /* ignore */ }
      }
      return;
    }
    pocState = pocDefaultState();
    const old = st[POC_KEY_OLD]; // carry over what was saved before
    if (old && old.name) {
      const first = String(old.name).trim().toLowerCase().split(" ")[0];
      const hit = pocState.roster.find((e) => e.name.toLowerCase().split(" ")[0] === first);
      if (hit) {
        if (old.shift) hit.shift = old.shift;
        if (old.weekOff) hit.weekOff = old.weekOff;
        if (old.contact) hit.contact = old.contact;
        pocState.defaultPrimary = hit.name;
      } else {
        pocState.roster.push({ name: old.name, shift: old.shift || "", weekOff: old.weekOff || "", contact: old.contact || "" });
        pocState.defaultPrimary = old.name;
      }
    }
  } catch (e) { /* keep defaults */ }
}

// Idempotent: replaces any old POC block with the one for the CURRENT message's Primary/Secondary POC.
function withPoc(text) {
  return pocApply(text, (typeof parsed !== "undefined" && parsed) || {}, pocState);
}

function setOutputText(text) {
  outputEl.value = withPoc(text);
  const t = String(text || "");
  if (/Back Office \/ Owner Panel/.test(t)) {
    const miss = pocResolve((typeof parsed !== "undefined" && parsed) || {}, pocState).unmatched;
    if (miss.length) statusEl.textContent = `Not found in the POC roster: ${miss.join(", ")} (only the name is printed) - add them with the POC button`;
  }
}

// Stored history text already has its own POC block; never rewrite it.
function setOutputRaw(text) {
  outputEl.value = text;
}

// ===== Settings (⚙): ON = POC details + WhatsApp message editable, OFF = locked =====
const SETTINGS_KEY = "tmbill_settings";
let appSettings = { pocEdit: false, payEdit: false, slackAssignment: false, slackMentions: true, slackPocName: "", agentMode: "smart_auto" };
async function loadSettings() {
  try {
    const st = await chrome.storage.local.get(SETTINGS_KEY);
    appSettings = { pocEdit: false, payEdit: false, slackAssignment: false, slackMentions: true, slackPocName: "", agentMode: "smart_auto", ...(st[SETTINGS_KEY] || {}) };
  } catch (e) { /* keep defaults */ }
  return appSettings;
}
const isEditMode = () => !!appSettings.pocEdit;

(function initSettingsModal() {
  const modal = document.getElementById("settingsModal");
  const box = document.getElementById("setPocEdit");
  const slackAssignBox = document.getElementById("setSlackAssignment");
  const slackMentionsBox = document.getElementById("setSlackMentions");
  const slackPocNameEl = document.getElementById("slackPocName");
  const agentModeEl = document.getElementById("agentMode");
  const sheetsUrlEl = document.getElementById("sheetsWebAppUrl");
  const sheetsSecretEl = document.getElementById("sheetsSecret");
  const sheetsEnabledEl = document.getElementById("sheetsSyncEnabled");
  const sheetsTestBtn = document.getElementById("sheetsTestBtn");
  const sheetsMsgEl = document.getElementById("sheetsSyncMsg");
  const agentStatusEl = document.getElementById("agentStatus");
  const agentJobEl = document.getElementById("agentJob");
  const agentTestBtn = document.getElementById("agentTestBtn");
  const agentRefreshBtn = document.getElementById("agentRefreshBtn");
  const close = () => { modal.style.display = "none"; };
  document.getElementById("settingsBtn").addEventListener("click", async () => {
    await loadSettings();
    box.checked = isEditMode();
    slackAssignBox.checked = !!appSettings.slackAssignment;
    if (slackMentionsBox) slackMentionsBox.checked = appSettings.slackMentions !== false;
    slackPocNameEl.value = appSettings.slackPocName || "";
    if (agentModeEl) agentModeEl.value = appSettings.agentMode || "smart_auto";
    if (sheetsUrlEl) sheetsUrlEl.value = appSettings.sheetsWebAppUrl || "";
    if (sheetsSecretEl) sheetsSecretEl.value = appSettings.sheetsSecret || "";
    if (sheetsEnabledEl) sheetsEnabledEl.checked = !!appSettings.sheetsSyncEnabled;
    if (sheetsMsgEl) sheetsMsgEl.textContent = appSettings.sheetsSyncEnabled ? "Auto-sync enabled. A row is sent after successful client creation." : "Auto-sync is off until you enable it.";
    await refreshAgentPanel();
    if (window.tmbillSlack && window.tmbillSlack.loadToken) await window.tmbillSlack.loadToken();
    modal.style.display = "flex";
  });
  // Settings is deliberately low-key: a faint gear in the corner (shows on hover)
  // and a keyboard shortcut, Ctrl+Alt+S.
  document.addEventListener("keydown", (e) => {
    if (e.ctrlKey && e.altKey && (e.key === "s" || e.key === "S")) {
      e.preventDefault();
      document.getElementById("settingsBtn").click();
    }
  });
  document.getElementById("settingsCloseBtn").addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
  box.addEventListener("change", async () => {
    appSettings = { ...appSettings, pocEdit: box.checked };
    try { await chrome.storage.local.set({ [SETTINGS_KEY]: appSettings }); } catch (e) { /* ignore */ }
    statusEl.textContent = box.checked ? "POC details edit ON - the roster and the WhatsApp message can be edited" : "POC details edit OFF - locked";
  });
  async function refreshAgentPanel() {
    try {
      const r = await send("AGENT_GET_STATE");
      const mode = String((r && r.settings && r.settings.agentMode) || appSettings.agentMode || "smart_auto");
      if (agentModeEl) agentModeEl.value = mode;
      const job = r && r.job;
      if (agentJobEl) {
        if (!job) agentJobEl.textContent = "No active agent job.";
        else agentJobEl.textContent = `${job.outlet || "Client"} — ${job.status || "unknown"}${job.updatedAt ? ` · ${new Date(job.updatedAt).toLocaleTimeString()}` : ""}`;
      }
      if (agentStatusEl) agentStatusEl.textContent = appSettings.slackAssignment ? `Agent monitoring ON · ${mode.replace("_", " ")}` : "Agent monitoring OFF";
    } catch (e) { if (agentStatusEl) agentStatusEl.textContent = "Agent status unavailable"; }
  }

  agentModeEl && agentModeEl.addEventListener("change", async () => {
    const mode = agentModeEl.value;
    appSettings = { ...appSettings, agentMode: mode };
    await chrome.storage.local.set({ [SETTINGS_KEY]: appSettings });
    await send("AGENT_SET_MODE", { mode });
    refreshAgentPanel();
  });
  agentRefreshBtn && agentRefreshBtn.addEventListener("click", refreshAgentPanel);
  agentTestBtn && agentTestBtn.addEventListener("click", async () => {
    if (agentStatusEl) agentStatusEl.textContent = "Running Slack agent check…";
    const r = await send("AGENT_TEST");
    if (agentStatusEl) agentStatusEl.textContent = r && r.ok ? `Agent check complete · ${r.notified || 0} new assignment(s)` : `Agent check failed · ${(r && r.error) || "unknown error"}`;
    refreshAgentPanel();
  });

  slackMentionsBox && slackMentionsBox.addEventListener("change", async () => {
    appSettings = { ...appSettings, slackMentions: slackMentionsBox.checked };
    try { await chrome.storage.local.set({ [SETTINGS_KEY]: appSettings }); } catch (e) {}
    chrome.runtime.sendMessage({ action: "SLACK_ASSIGNMENT_SETTINGS_CHANGED" }, () => void chrome.runtime.lastError);
    statusEl.textContent = slackMentionsBox.checked ? "Slack mention alerts ON — Smart Summary enabled" : "Slack mention alerts OFF";
    refreshAgentPanel();
  });

  slackAssignBox.addEventListener("change", async () => {
    appSettings = { ...appSettings, slackAssignment: slackAssignBox.checked, slackPocName: String(slackPocNameEl.value || "").trim() };
    try { await chrome.storage.local.set({ [SETTINGS_KEY]: appSettings }); } catch (e) { /* ignore */ }
    chrome.runtime.sendMessage({ action: "SLACK_ASSIGNMENT_SETTINGS_CHANGED" }, () => void chrome.runtime.lastError);
    statusEl.textContent = slackAssignBox.checked ? "Smart Agent monitoring ON" : "Smart Agent monitoring OFF";
    refreshAgentPanel();
  });
  slackPocNameEl.addEventListener("change", async () => {
    appSettings = { ...appSettings, slackPocName: String(slackPocNameEl.value || "").trim() };
    try { await chrome.storage.local.set({ [SETTINGS_KEY]: appSettings }); } catch (e) { /* ignore */ }
    chrome.runtime.sendMessage({ action: "SLACK_ASSIGNMENT_SETTINGS_CHANGED" }, () => void chrome.runtime.lastError);
  });
  const saveSheetsSettings = async () => {
    appSettings = { ...appSettings,
      sheetsWebAppUrl: String(sheetsUrlEl?.value || "").trim(),
      sheetsSecret: String(sheetsSecretEl?.value || "").trim(),
      sheetsSyncEnabled: !!sheetsEnabledEl?.checked
    };
    try { await chrome.storage.local.set({ [SETTINGS_KEY]: appSettings }); } catch (e) {}
  };
  [sheetsUrlEl, sheetsSecretEl, sheetsEnabledEl].filter(Boolean).forEach(el => {
    el.addEventListener("change", saveSheetsSettings);
    el.addEventListener("blur", saveSheetsSettings);
  });
  sheetsTestBtn && sheetsTestBtn.addEventListener("click", async () => {
    await saveSheetsSettings();
    if (!appSettings.sheetsWebAppUrl || !appSettings.sheetsSecret) {
      if (sheetsMsgEl) sheetsMsgEl.textContent = "Enter the Web App URL and shared secret first.";
      return;
    }
    if (sheetsMsgEl) sheetsMsgEl.textContent = "Sending test request…";
    const result = await sendToIndiaClientSheet({ test: true, outlet_name: "TMBill Connection Test", _secret: appSettings.sheetsSecret }, appSettings.sheetsWebAppUrl);
    if (sheetsMsgEl) sheetsMsgEl.textContent = result.ok ? "Test request accepted by the endpoint. No client row should be added." : `Test failed: ${result.error || "unknown error"}`;
    if (!result.ok && window.tmbillLearning) window.tmbillLearning.record("google_sheets_test_failed", result.error || "Connection test failed", "google_sheets");
  });
  loadSettings();
})();

// Google Sheets sync helper. Uses the user-deployed Apps Script web app URL.
async function sendToIndiaClientSheet(payload, urlOverride) {
  const st = await chrome.storage.local.get(SETTINGS_KEY);
  const cfg = st[SETTINGS_KEY] || {};
  const url = String(urlOverride || cfg.sheetsWebAppUrl || "").trim();
  if (!url) return { ok: false, error: "Apps Script Web App URL is not configured" };
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload),
      redirect: "follow"
    });
    const text = await response.text();
    let data = {}; try { data = JSON.parse(text); } catch (_) {}
    if (!response.ok || data.ok === false) { const err = data.error || `HTTP ${response.status}`; if (window.tmbillLearning) window.tmbillLearning.record("google_sheets_request_failed", err, "google_sheets"); return { ok: false, error: err }; }
    return { ok: data.ok !== false, ...data };
  } catch (e) {
    const err = `Network/CORS error: ${e.message}. Confirm the Apps Script is deployed as a Web App and try again.`; if (window.tmbillLearning) window.tmbillLearning.record("google_sheets_network_failed", err, "google_sheets"); return { ok: false, error: err };
  }
}

async function syncOnboardingToIndiaClient(data) {
  const st = await chrome.storage.local.get(SETTINGS_KEY);
  const cfg = st[SETTINGS_KEY] || {};
  if (!cfg.sheetsSyncEnabled) return { skipped: true };
  const payload = {
    _secret: String(cfg.sheetsSecret || ""),
    event_id: `${String(data.store_id || "")}:${String(data.outlet_name || "").trim().toLowerCase()}`,
    outlet_name: data.outlet_name || "",
    tax_configuration: data.tax_configuration || data.tax_config || data.gst || "",
    email: data.email || "",
    contact: data.mobile || data.contact || data.phone || "",
    package: data.package || data.package_name || data.plan || "",
    username: data.username || "",
    password: data.password || "",
    billing_status: "Onboarding complete",
    store_id: data.store_id || "",
    source: "TMBill Smart Onboarding Agent 5.0",
    completed_at: new Date().toISOString()
  };
  if (!payload.outlet_name) return { ok: false, error: "Outlet name is missing; not sent to Sheet." };
  return await sendToIndiaClientSheet(payload);
}

// ===== Extra users (POS billing, captain, KDS, OrderHub ...) =====
let extraUsers = []; // { typeKey, username, password, name, designation, flags } - never persisted (holds passwords)
const USER_FLAG_SHORT = { web: "Back office", terminal: "POS billing", captain: "Captain", kds: "KDS", selfOrder: "Self order", hub: "OrderHub" };

function usersOwnerUsername() {
  return String((typeof manualOverrides !== "undefined" && manualOverrides.username) || (parsed && parsed.username) || "").trim();
}
function usersBaseName() {
  const owner = usersOwnerUsername();
  if (owner) return owner;
  const outlet = String((typeof manualOverrides !== "undefined" && manualOverrides.outlet_name) || (parsed && parsed.outlet_name) || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  return outlet || "user";
}
function usersLast4() {
  const mobile = String((typeof manualOverrides !== "undefined" && manualOverrides.mobile) || (parsed && parsed.mobile) || "").replace(/\D/g, "");
  return mobile.length >= 4 ? mobile.slice(-4) : String(Math.floor(1000 + Math.random() * 9000));
}

function addExtraUsers(typeKey, count) {
  const type = userTypeByKey(typeKey);
  // Username = same as backoffice owner username (no suffix needed for 1 user;
  // suffix 1,2,3... only when adding multiples of the same type).
  // Password = "1234" always — simple, consistent, matches buildOutput default.
  const base = usersOwnerUsername() || usersBaseName();
  const taken = new Set(extraUsers.map((u) => u.username.toLowerCase()));
  const ownerU = usersOwnerUsername().toLowerCase();
  if (ownerU) taken.add(ownerU);
  const n = Math.max(1, Math.min(20, parseInt(count, 10) || 1));
  for (let i = 0; i < n; i++) {
    // First user gets the plain base name; subsequent users get base1, base2 …
    // background.js createExtraUsers will also retry with suffixes if the server
    // rejects the username as already taken.
    let idx = 0;
    let username = base;
    while (taken.has(username.toLowerCase())) {
      idx++;
      username = `${base}${idx}`;
    }
    taken.add(username.toLowerCase());
    const label = `${type.label.replace(/\s*\(.*\)$/, "")}${idx ? " " + idx : ""}`.trim();
    extraUsers.push({
      typeKey,
      username,
      password: "1234",
      name: label,
      designation: type.designation,
      flags: userFlagsFor(typeKey),
      _auto: idx === 0 && extraUsers.length === 0,
    });
  }
  renderExtraUsers();
}

function usersSummaryNote() {
  const note = document.getElementById("userNote");
  if (!note) return;
  if (!extraUsers.length) { note.textContent = "Only the automatic POS billing user will be created (Back Office username, or username + 1 if taken; password 1234). Add rows here only for extra users."; return; }
  const v = userValidate(extraUsers, usersOwnerUsername());
  const parts = [`${extraUsers.length} user(s) added.`];
  note.innerHTML = escapeHtml(parts[0]) +
    v.errors.map((e) => `<div class="user-note-err">✗ ${escapeHtml(e)}</div>`).join("") +
    v.warnings.map((w) => `<div class="user-note-warn">⚠ ${escapeHtml(w)}</div>`).join("");
  document.querySelectorAll("#userRows .user-row").forEach((row, i) => {
    const u = extraUsers[i];
    const probs = userValidate([u], usersOwnerUsername()).errors;
    row.classList.toggle("bad", probs.length > 0 || v.errors.some((e) => e.startsWith(`User ${i + 1}`)));
  });
}

function renderExtraUsers() {
  const box = document.getElementById("userRows");
  const dl = document.getElementById("userDesignations");
  if (!box) return;
  const attr = (v) => escapeHtml(v).replace(/"/g, "&quot;");
  const desig = new Set(["manager", "cashier", "captain", "waiter"]);
  String((designationNameEl && designationNameEl.value) || "").split(/[,\n]/).map((x) => x.trim().toLowerCase()).filter(Boolean).forEach((x) => desig.add(x));
  if (dl) dl.innerHTML = [...desig].map((d) => `<option value="${attr(d)}"></option>`).join("");
  box.innerHTML = extraUsers
    .map(
      (u, i) => `<div class="user-row" data-i="${i}">
      <div class="user-row-top">
        <select data-u="typeKey" aria-label="User type">${USER_TYPES.filter((t) => t.key !== "pos").map((t) => `<option value="${t.key}" ${t.key === u.typeKey ? "selected" : ""}>${escapeHtml(t.label)}</option>`).join("")}</select>
        <button type="button" class="poc-del" data-u-del="${i}" title="Remove user" aria-label="Remove user">✕</button>
      </div>
      <div class="user-row-mid">
        <input type="text" data-u="username" placeholder="Username" value="${attr(u.username)}" autocomplete="off" />
        <input type="text" data-u="password" placeholder="Password" value="${attr(u.password)}" autocomplete="off" />
      </div>
      <div class="user-row-mid">
        <input type="text" data-u="name" placeholder="Display name" value="${attr(u.name)}" autocomplete="off" />
        <input type="text" data-u="designation" list="userDesignations" placeholder="Designation" value="${attr(u.designation)}" autocomplete="off" />
      </div>
      <div class="user-flags">${USER_FLAG_DEFS.map((f) => `<label><input type="checkbox" data-flag="${f.key}" ${u.flags[f.key] ? "checked" : ""} />${escapeHtml(USER_FLAG_SHORT[f.key] || f.label)}</label>`).join("")}</div>
    </div>`
    )
    .join("");
  usersSummaryNote();
}

(function initExtraUsers() {
  const typeSel = document.getElementById("userQuickType");
  const countEl = document.getElementById("userQuickCount");
  const addBtn = document.getElementById("userQuickAdd");
  const rowsEl = document.getElementById("userRows");
  if (!typeSel || !countEl || !addBtn || !rowsEl) return;
  typeSel.innerHTML = USER_TYPES.filter((t) => t.key !== "pos").map((t) => `<option value="${t.key}">${escapeHtml(t.label)}</option>`).join("");
  addBtn.addEventListener("click", () => {
    addExtraUsers(typeSel.value, countEl.value);
    setupUsersEl.checked = true; // adding users means you want them created
  });
  rowsEl.addEventListener("input", (e) => {
    const el = e.target;
    const row = el.closest(".user-row");
    if (!row) return;
    const u = extraUsers[Number(row.dataset.i)];
    if (el.dataset.u && el.dataset.u !== "typeKey") { u[el.dataset.u] = el.value; usersSummaryNote(); }
  });
  rowsEl.addEventListener("change", (e) => {
    const el = e.target;
    const row = el.closest(".user-row");
    if (!row) return;
    const u = extraUsers[Number(row.dataset.i)];
    if (el.dataset.flag) { u.flags[el.dataset.flag] = el.checked ? 1 : 0; usersSummaryNote(); return; }
    if (el.dataset.u === "typeKey") {
      const oldLabel = userTypeByKey(u.typeKey).label.replace(/\s*\(.*\)$/, "");
      const t = userTypeByKey(el.value);
      // a type change re-applies that type's permissions + designation; an untouched default name follows the type
      if (new RegExp(`^${oldLabel.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")} \\d+$`).test(u.name)) u.name = `${t.label.replace(/\s*\(.*\)$/, "")} ${u.name.split(" ").pop()}`;
      u.typeKey = t.key;
      u.flags = userFlagsFor(t.key);
      u.designation = t.designation;
      renderExtraUsers();
    }
  });
  rowsEl.addEventListener("click", (e) => {
    const del = e.target.closest("button[data-u-del]");
    if (!del) return;
    extraUsers.splice(Number(del.dataset.uDel), 1);
    renderExtraUsers();
  });
  renderExtraUsers();
})();

function usersConfirmText(rows, warnings) {
  const lines = rows.map((u) => {
    const perms = USER_FLAG_DEFS.filter((f) => u.flags[f.key]).map((f) => USER_FLAG_SHORT[f.key] || f.label).join(", ") || "NO permissions";
    return `• ${u.username} - ${userTypeByKey(u.typeKey).label}\n   designation: ${u.designation || "manager"}; access: ${perms}`;
  });
  return `These users will be created on the selected outlet:\n\n${lines.join("\n")}` +
    (warnings.length ? `\n\nWarnings:\n- ${warnings.join("\n- ")}` : "") + "\n\nContinue?";
}

// Add the created logins to the credentials message (and its History entry) so they are not lost.
// Writes the Back Office username / password into the client message (and its history entry) once they are known.
function patchOwnerCreds(text, u, pw) {
  return String(text || "").replace(/(\*Back Office \/ Owner Panel\*[\s\S]*?\*• Username\* : )[^\n]*(\n\*• Password\* : )[^\n]*/, (m, a, b) => `${a}${u}${b}${pw}`);
}
async function patchOwnerCredsInOutput(u, pw) {
  try {
    if (/Back Office \/ Owner Panel/.test(outputEl.value)) outputEl.value = patchOwnerCreds(outputEl.value, u, pw);
    const name = String(currentOutletLabel() || "").trim().toLowerCase();
    if (!name) return;
    const list = await loadHistory();
    const i = list.findIndex((it) => /Back Office \/ Owner Panel/.test(it.text || "") && String(it.name || "").trim().toLowerCase() === name);
    if (i >= 0) { list[i].text = patchOwnerCreds(list[i].text, u, pw); await saveHistory(list); }
  } catch (e) { /* best-effort */ }
}
async function attachUsersToOutput(created) {
  const owner = usersOwnerUsername().toLowerCase();
  if (!created.length) return false;
  const outletName = String(currentOutletLabel() || "").trim().toLowerCase();
  const isCreds = (t) => /Back Office \/ Owner Panel/.test(String(t || ""));
  // Owner username known -> match by it; otherwise match this outlet's message by outlet name.
  const mine = (t, name) => isCreds(t) && (owner ? String(t).toLowerCase().includes(owner) : !!outletName && String(name || "").trim().toLowerCase() === outletName);
  let changed = false;
  if (isCreds(outputEl.value) && (owner ? mine(outputEl.value) : true)) { outputEl.value = userMergeBlock(outputEl.value, created); changed = true; }
  try {
    const list = await loadHistory();
    const i = list.findIndex((it) => mine(it.text, it.name));
    if (i >= 0) { list[i].text = userMergeBlock(list[i].text, created); await saveHistory(list); changed = true; }
  } catch (e) { /* history is best-effort */ }
  return changed;
}

// ===== Payment modes: which modes Full Setup adds (locked defaults unless Settings allows editing) =====
const PAY_DEFAULTS_BUILTIN = ["Cash", "Card", "GooglePay", "Paytm", "Credit"];
const PAY_DEF_KEY = "tmbill_pay_defaults";
const PAY_MASTER_KEY = "tmbill_pay_master";
let payDefaults = PAY_DEFAULTS_BUILTIN.slice();
let payMaster = []; // every mode the backoffice offers (loaded from an outlet)

async function loadPayState() {
  try {
    const st = await chrome.storage.local.get([PAY_DEF_KEY, PAY_MASTER_KEY]);
    if (Array.isArray(st[PAY_DEF_KEY]) && st[PAY_DEF_KEY].length) payDefaults = st[PAY_DEF_KEY];
    if (st[PAY_MASTER_KEY] && Array.isArray(st[PAY_MASTER_KEY].names)) payMaster = st[PAY_MASTER_KEY].names;
  } catch (e) { /* keep defaults */ }
}

// What Full Setup / Pre-check will use.
const payOff = new Set(); // modes un-ticked for this run (everything is ticked every time the panel opens)
function currentPayModes() {
  return payDefaults.filter((n) => !payOff.has(n.toLowerCase()));
}
function renderPayPick() {
  const box = document.getElementById("payPickBox");
  if (!box) return;
  const attr = (v) => escapeHtml(v).replace(/"/g, "&quot;");
  box.innerHTML = payDefaults
    .map((n) => { const on = !payOff.has(n.toLowerCase()); return `<label class="pay-chip ${on ? "on" : ""}"><input type="checkbox" data-pay-pick="${attr(n)}" ${on ? "checked" : ""} />${escapeHtml(n)}</label>`; })
    .join("");
}
document.addEventListener("change", (e) => {
  const c = e.target.closest && e.target.closest("input[data-pay-pick]");
  if (!c) return;
  const k = c.dataset.payPick.toLowerCase();
  if (c.checked) payOff.delete(k); else payOff.add(k);
  c.closest(".pay-chip").classList.toggle("on", c.checked);
});

let payListOpen = false;
let payActive = -1;
const payNorm = (v) => String(v || "").toLowerCase().replace(/[^a-z0-9]/g, "");

// master list first, then any chosen default the master doesn't have
function payAllNames() {
  const seen = new Set();
  const out = [];
  for (const n of [...payMaster, ...payDefaults]) {
    const k = n.toLowerCase();
    if (!seen.has(k)) { seen.add(k); out.push(n); }
  }
  return out;
}
const payIsOn = (n) => payDefaults.some((d) => d.toLowerCase() === String(n).toLowerCase());

function closePayList() {
  const list = document.getElementById("payModeList");
  if (list) list.style.display = "none";
  payListOpen = false;
  payActive = -1;
}

// The dropdown: filtered by what is typed in the search box ("sod" -> Sodexo, "goo" -> GooglePay)
function renderPayList() {
  const list = document.getElementById("payModeList");
  const input = document.getElementById("payModeSearch");
  if (!list || !input) return;
  const attr = (v) => escapeHtml(v).replace(/"/g, "&quot;");
  const q = payNorm(input.value);
  const masterKeys = new Set(payMaster.map(payNorm));
  const items = payAllNames().filter((n) => !q || payNorm(n).includes(q));
  list.innerHTML = items.length
    ? items
        .map((n) => {
          const on = payIsOn(n);
          const missing = payMaster.length && !masterKeys.has(payNorm(n)) ? "<small>not in master</small>" : "";
          return `<div class="pay-opt ${on ? "on" : ""}" role="option" aria-selected="${on}" data-pay-opt="${attr(n)}"><span class="pay-tick">${on ? "✓" : ""}</span><span class="pay-name">${escapeHtml(n)}</span>${missing}</div>`;
        })
        .join("")
    : `<div class="pay-empty">"${escapeHtml(input.value)}" has no matching payment mode${payMaster.length ? "" : " (master list not loaded yet - press 'Load master list' below)"}</div>`;
  list.style.display = "block";
  payListOpen = true;
  payActive = -1;
}

function renderPayModes() {
  renderPayPick();
  const box = document.getElementById("payModeBox");
  const note = document.getElementById("payModeNote");
  const input = document.getElementById("payModeSearch");
  const caret = document.getElementById("payModeCaret");
  if (!box || !note || !input || !caret) return;
  const edit = true;
  const attr = (v) => escapeHtml(v).replace(/"/g, "&quot;");
  // Only what is SELECTED shows as chips, so the area stays small however long the master list is.
  box.innerHTML =
    payDefaults
      .map((n) => `<span class="pay-chip on ${edit ? "" : "locked"}">${escapeHtml(n)}${edit ? `<button type="button" class="pay-x" data-pay-remove="${attr(n)}" title="Hatao" aria-label="${attr(n)} hatao">×</button>` : ""}</span>`)
      .join("") + `<span class="pay-count">${payDefaults.length} selected</span>`;
  input.disabled = !edit;
  caret.disabled = !edit;
  input.placeholder = edit
    ? `Search, or open the list with ▾ (${payAllNames().length} modes)`
    : 'Locked - turn ON "Default payment modes edit" in Settings';
  if (!edit) { input.value = ""; closePayList(); }
  else if (payListOpen) renderPayList();
  const masterInfo = payMaster.length ? `Master list: ${payMaster.length} modes` : "Master list not loaded yet (select an outlet or press the button below)";
  note.innerHTML =
    "Tick / untick here = the default list. Outside, you only tick which ones to use. " +
    `<br>${escapeHtml(masterInfo)} ` +
    `<button type="button" class="link-btn" data-pay-act="load">Load master list</button>` +
    (edit ? `<button type="button" class="link-btn" data-pay-act="reset">Reset to original defaults</button>` : "");
}

// tick/untick one mode (a selected mode is removed, an unselected one is added)
async function payToggle(name) {
  const on = payIsOn(name);
  const next = on ? payDefaults.filter((d) => d.toLowerCase() !== String(name).toLowerCase()) : [...payDefaults, name];
  if (!next.length) {
    alert("Keep at least one payment mode. (To skip the whole step, untick 'Default Payment Modes' above.)");
    return;
  }
  await savePayDefaults(next);
  renderPayModes();
}

async function savePayDefaults(list) {
  payDefaults = list;
  try { await chrome.storage.local.set({ [PAY_DEF_KEY]: payDefaults }); } catch (e) { /* ignore */ }
}

async function loadPayMaster(storeId, silent) {
  if (!storeId) {
    if (!silent) alert("First choose an outlet in 'Select Outlet' above, then load the master list.");
    return;
  }
  const r = await send("FETCH_PAYMENT_MODES", { store_id: storeId, masterEmail: masterEmailEl.value.trim(), masterPassword: masterPasswordEl.value });
  if (r && r.ok && Array.isArray(r.names) && r.names.length) {
    payMaster = r.names;
    try { await chrome.storage.local.set({ [PAY_MASTER_KEY]: { names: payMaster, ts: Date.now() } }); } catch (e) { /* ignore */ }
    renderPayModes();
    if (!silent) statusEl.textContent = `Payment modes master list loaded: ${payMaster.length} modes`;
  } else if (!silent) {
    statusEl.textContent = "Could not load payment modes: " + ((r && r.error) || "unknown error");
  }
}

(function initPayModes() {
  const box = document.getElementById("payModeBox");
  const note = document.getElementById("payModeNote");
  const input = document.getElementById("payModeSearch");
  const caret = document.getElementById("payModeCaret");
  const list = document.getElementById("payModeList");
  const combo = document.getElementById("payCombo");
  if (!box || !note || !input || !caret || !list || !combo) return;
  const isEdit = () => true;

  // open on focus / click / typing; ▾ toggles
  input.addEventListener("focus", () => { if (isEdit()) renderPayList(); });
  input.addEventListener("click", () => { if (isEdit() && !payListOpen) renderPayList(); });
  input.addEventListener("input", () => { if (isEdit()) renderPayList(); });
  caret.addEventListener("click", () => {
    if (!isEdit()) return;
    if (payListOpen) closePayList();
    else { renderPayList(); input.focus(); }
  });

  // keyboard: ↑ ↓ move, Enter ticks the highlighted (or the only match), Esc closes
  input.addEventListener("keydown", async (e) => {
    if (!isEdit()) return;
    const opts = [...list.querySelectorAll(".pay-opt")];
    if (e.key === "Escape") { closePayList(); return; }
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (!payListOpen) renderPayList();
      const items = [...list.querySelectorAll(".pay-opt")];
      if (!items.length) return;
      payActive = (payActive + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
      items.forEach((el, i) => el.classList.toggle("active", i === payActive));
      items[payActive].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") {
      e.preventDefault();
      const pick = opts[payActive] || (opts.length === 1 ? opts[0] : null);
      if (pick) await payToggle(pick.dataset.payOpt);
    }
  });

  // keep focus in the search box while clicking list items
  list.addEventListener("mousedown", (e) => e.preventDefault());
  list.addEventListener("click", async (e) => {
    const opt = e.target.closest(".pay-opt");
    if (opt && isEdit()) await payToggle(opt.dataset.payOpt);
  });
  box.addEventListener("click", async (e) => {
    const x = e.target.closest("button[data-pay-remove]");
    if (x && isEdit()) await payToggle(x.dataset.payRemove);
  });
  document.addEventListener("mousedown", (e) => {
    if (payListOpen && !combo.contains(e.target)) closePayList();
  });

  note.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-pay-act]");
    if (!btn) return;
    if (btn.dataset.payAct === "load") {
      const sel = document.getElementById("fsOutletSelect");
      await loadPayMaster((sel && sel.value) || (parsed && parsed.store_id) || "", false);
    } else if (btn.dataset.payAct === "reset") {
      await savePayDefaults(PAY_DEFAULTS_BUILTIN.slice());
      renderPayModes();
    }
  });
  (async () => {
    if (typeof loadSettings === "function") await loadSettings();
    await loadPayState();
    renderPayModes();
  })();
})();

(function initPocModal() {
  const modal = document.getElementById("pocModal");
  const listEl = document.getElementById("pocRoster");
  const defP = document.getElementById("pocDefPrimary");
  const defS = document.getElementById("pocDefSecondary");
  const lockNote = document.getElementById("pocLockNote");
  const countNote = document.getElementById("pocCountNote");
  const addBtn = document.getElementById("pocAddBtn");
  const resetBtn = document.getElementById("pocResetBtn");
  const saveBtn = document.getElementById("pocSaveBtn");
  let draft = [];
  let draftP = "";
  let draftS = "";
  let editMode = false;
  const attr = (v) => escapeHtml(v).replace(/"/g, "&quot;");

  function updateCount() {
    const missing = draft.filter((e) => e.name.trim() && !pocContactOk(e.contact)).length;
    countNote.textContent = missing
      ? `⚠ ${missing} executive(s) still need a contact number (required)`
      : "✓ All executives have contact numbers";
    countNote.style.color = missing ? "var(--danger)" : "var(--green-dark)";
  }

  function applyLock() {
    lockNote.style.display = editMode ? "none" : "block";
    for (const b of [addBtn, resetBtn, saveBtn]) b.style.display = editMode ? "" : "none";
    defP.disabled = !editMode;
    defS.disabled = !editMode;
  }

  function fillDefaults() {
    const opts = ['<option value="">(none)</option>']
      .concat(draft.filter((e) => e.name.trim()).map((e) => `<option value="${attr(e.name)}">${escapeHtml(e.name)}</option>`))
      .join("");
    defP.innerHTML = opts;
    defS.innerHTML = opts;
    defP.value = draftP;
    defS.value = draftS;
    if (defP.value !== draftP) { draftP = ""; defP.value = ""; }
    if (defS.value !== draftS) { draftS = ""; defS.value = ""; }
  }

  function renderRows() {
    const dis = editMode ? "" : "disabled";
    listEl.innerHTML = draft
      .map(
        (e, i) => `<div class="poc-row ${pocContactOk(e.contact) ? "" : "poc-bad"}" data-i="${i}">
      <div class="poc-row-top">
        <input type="text" data-f="name" placeholder="Executive name" value="${attr(e.name)}" ${dis} />
        ${editMode ? `<button type="button" class="poc-del" data-del="${i}" title="Remove" aria-label="Remove">✕</button>` : ""}
      </div>
      <div class="poc-row-mid">
        <input type="text" class="poc-shift" data-f="shift" placeholder="02:00 PM to 11:00 PM" value="${attr(e.shift)}" ${dis} />
        <input type="text" data-f="weekOff" placeholder="Week off" value="${attr(e.weekOff)}" ${dis} />
      </div>
      <input type="text" data-f="contact" placeholder="Contact number (required) e.g. 98765 43210" value="${attr(e.contact)}" ${dis} />
    </div>`
      )
      .join("");
    listEl.querySelectorAll(".poc-row").forEach((row) => {
      const i = Number(row.dataset.i);
      row.querySelectorAll("input[data-f]").forEach((inp) => {
        inp.addEventListener("input", () => {
          draft[i][inp.dataset.f] = inp.value;
          if (inp.dataset.f === "contact") {
            row.classList.toggle("poc-bad", !pocContactOk(inp.value));
            updateCount();
          }
        });
        if (inp.dataset.f === "name") inp.addEventListener("change", fillDefaults);
      });
    });
    listEl.querySelectorAll("button[data-del]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const [gone] = draft.splice(Number(btn.dataset.del), 1);
        if (gone && gone.name === draftP) draftP = "";
        if (gone && gone.name === draftS) draftS = "";
        renderRows();
        fillDefaults();
      });
    });
    updateCount();
  }

  document.getElementById("pocBtn").addEventListener("click", async () => {
    await loadPoc();
    await loadSettings();
    editMode = isEditMode();
    draft = pocState.roster.map((e) => ({ name: e.name || "", shift: e.shift || "", weekOff: e.weekOff || "", contact: e.contact || "" }));
    draftP = pocState.defaultPrimary || "";
    draftS = pocState.defaultSecondary || "";
    applyLock();
    renderRows();
    fillDefaults();
    defP.disabled = !editMode;
    defS.disabled = !editMode;
    modal.style.display = "flex";
  });
  const close = () => { modal.style.display = "none"; };
  document.getElementById("pocCloseBtn").addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
  defP.addEventListener("change", () => { draftP = defP.value; });
  defS.addEventListener("change", () => { draftS = defS.value; });

  addBtn.addEventListener("click", () => {
    if (!editMode) return;
    draft.push({ name: "", shift: "", weekOff: "", contact: "" });
    renderRows();
    listEl.scrollTop = listEl.scrollHeight;
    const rows = listEl.querySelectorAll(".poc-row input[data-f=name]");
    if (rows.length) rows[rows.length - 1].focus();
  });
  resetBtn.addEventListener("click", async () => {
    if (!editMode) return;
    if (!(await uiConfirm("Reset the roster to the default 16 executives? Your edits (including numbers) will be lost.", { title: "Reset roster?", okText: "Reset", cancelText: "Keep my edits", danger: true }))) return;
    const d = pocDefaultState();
    draft = d.roster;
    draftP = d.defaultPrimary;
    draftS = d.defaultSecondary;
    renderRows();
    fillDefaults();
  });
  saveBtn.addEventListener("click", async () => {
    if (!editMode) return;
    const roster = draft
      .map((e) => ({ name: e.name.trim(), shift: e.shift.trim(), weekOff: e.weekOff.trim(), contact: e.contact.trim() }))
      .filter((e) => e.name);
    if (!roster.length) { alert("Keep at least one executive."); return; }
    // Contact number is mandatory for every executive.
    const bad = roster.filter((e) => !pocContactOk(e.contact));
    if (bad.length) {
      alert("Every executive needs a contact number. These are missing:\n\n- " + bad.map((e) => e.name).join("\n- "));
      renderRows();
      const first = listEl.querySelector(".poc-bad [data-f=contact]");
      if (first) first.focus();
      return;
    }
    pocState = {
      version: POC_ROSTER_VERSION,
      roster: roster.map((e) => ({ ...e, contact: pocNormalizeContact(e.contact) })),
      defaultPrimary: roster.some((e) => e.name === draftP) ? draftP : "",
      defaultSecondary: roster.some((e) => e.name === draftS) ? draftS : "",
    };
    try { await chrome.storage.local.set({ [POC_KEY2]: pocState }); } catch (e) { /* ignore */ }
    statusEl.textContent = "POC roster saved - it applies from the next output";
    close();
  });
  loadPoc();
})();

// ===== WhatsApp: save contact (outlet name) + send login credentials =====
(function initWhatsApp() {
  const WA_SENT_KEY = "tmbill_wa_sent";
  const modal = document.getElementById("waModal");
  const infoEl = document.getElementById("waInfo");
  const numListEl = document.getElementById("waNumList");
  const addNumEl = document.getElementById("waAddNum");
  const nameEl = document.getElementById("waContactName");
  const msgEl = document.getElementById("waMessage");
  const warnEl = document.getElementById("waWarn");
  let busy = false;
  const sendBtn = document.getElementById("waSendBtn");
  const diagBtn = document.getElementById("waDiagBtn");
  const resultsEl = document.getElementById("waResults");
  const btn = document.getElementById("waBtn");
  let nums = []; // { label, number, checked }
  let waText = "";

  const digits = (v) => String(v || "").replace(/\D/g, "");
  const isCreds = (t) => /Back Office \/ Owner Panel/.test(String(t || ""));
  const hashStr = (s) => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return String(h >>> 0); };

  function outletNameForWa() {
    const sel = document.getElementById("fsOutletSelect");
    const selText = sel && sel.value && sel.selectedOptions[0] ? sel.selectedOptions[0].text : "";
    return String(manualOverrides.outlet_name || (parsed && parsed.outlet_name) || selText || "").trim();
  }

  // Client numbers from the message: parsed owner mobile first, then any other
  // number in the text that is not a POC / support / sales line. Any style
  // (+91 / 91 / 0 / spaces / dashes / dots / +971 ...) is understood and the
  // same number written two ways is listed once.
  function collectClientNumbers() {
    const out = [];
    const seen = new Set();
    const push = (label, raw) => {
      const c = phoneCanonical(raw);
      if (c.kind === "bad" || seen.has(c.full)) return;
      seen.add(c.full);
      out.push({ label, number: c.number, full: c.full, checked: out.length === 0 });
    };
    const main = manualOverrides.mobile || (parsed && parsed.mobile);
    if (main) push("Owner / Outlet mobile", main);
    const NOT = /poc|support|sales|helpline|team|tmbill|accounts?\b|billing/i;
    for (const line of String(inputEl.value || "").split("\n")) {
      if (NOT.test(line)) continue;
      for (const f of phoneExtract(line)) {
        const label = line.slice(0, f.index).replace(/[^A-Za-z/ ]/g, " ").trim().split(/\s+/).slice(-4).join(" ") || "Number";
        push(label, f.raw);
      }
    }
    return out;
  }

  // The credentials text that belongs to THIS client (never another outlet's).
  async function credentialsForClient() {
    const user = String(manualOverrides.username || (parsed && parsed.username) || "").trim().toLowerCase();
    const mine = (t) => !user || String(t || "").toLowerCase().includes(user);
    if (isCreds(outputEl.value) && mine(outputEl.value)) return { text: outputEl.value, exact: !!user };
    if (user) {
      const list = await loadHistory();
      const hit = list.find((it) => isCreds(it.text) && mine(it.text));
      if (hit) return { text: hit.text, exact: true };
    }
    return { text: "", exact: false };
  }

  async function loadSent() {
    try { const st = await chrome.storage.local.get(WA_SENT_KEY); return st[WA_SENT_KEY] || {}; } catch (e) { return {}; }
  }
  async function markSent(text, phones) {
    const sent = await loadSent();
    const th = hashStr(text);
    const now = Date.now();
    for (const p of phones) sent[th + "|" + digits(p)] = now;
    for (const k of Object.keys(sent)) if (now - sent[k] > 24 * 3600 * 1000) delete sent[k];
    try { await chrome.storage.local.set({ [WA_SENT_KEY]: sent }); } catch (e) { /* ignore */ }
  }

  function renderNums() {
    numListEl.innerHTML = nums.length
      ? nums
          .map((n, i) => `<label class="qr-opt"><input type="checkbox" data-i="${i}" ${n.checked ? "checked" : ""} /><span>${escapeHtml(n.number)}<small>${escapeHtml(n.label)}</small></span></label>`)
          .join("")
      : '<p class="hint small">No mobile number found in the message - add one below.</p>';
    numListEl.querySelectorAll("input[data-i]").forEach((cb) => {
      cb.addEventListener("change", () => { nums[Number(cb.dataset.i)].checked = cb.checked; });
    });
  }

  function showResults(resp, items) {
    const rows = [];
    if (!resp || !resp.ok) {
      rows.push(`<div class="wa-res bad">${escapeHtml((resp && resp.error) || "No response from WhatsApp")}</div>`);
      if (resp && resp.diag) rows.push(`<div class="wa-diag">${escapeHtml(JSON.stringify(resp.diag, null, 2))}</div>`);
    } else {
      for (const r of resp.results || []) {
        const it = items.find((x) => x.phone === r.phone) || {};
        const shown = it.display || r.phone;
        if (r.ok) {
          let saveLine;
          if (r.keptName !== undefined) saveLine = `The number is already saved ("${escapeHtml(r.keptName)}") - name kept, message sent`;
          else if (r.saved) saveLine = `Contact "${escapeHtml(it.name || "")}" saved`;
          else saveLine = `Contact not saved${r.saveError ? ": " + escapeHtml(r.saveError) : ""}`;
          const conf = r.confirmed === false ? " · WhatsApp has not confirmed yet (no tick) - check the chat; the number may not be on WhatsApp or the connection may be slow" : "";
          rows.push(`<div class="wa-res ok">✓ ${escapeHtml(shown)} - message sent<small>${saveLine}${conf}</small></div>`);
        } else {
          rows.push(`<div class="wa-res bad">✗ ${escapeHtml(shown)} - ${escapeHtml(r.error || "fail")}${r.saveError ? `<small>${escapeHtml(r.saveError)}</small>` : ""}</div>`);
        }
      }
    }
    resultsEl.innerHTML = rows.join("");
  }

  // Send is blocked while a POC in the message has no contact number (mandatory).
  function refreshState() {
    const problems = pocMessageProblems(waText);
    warnEl.innerHTML = problems.length
      ? escapeHtml(problems.join(" · ")) + "<br>Turn ON POC edit in Settings (⚙) and add the number in the roster / message."
      : "";
    sendBtn.disabled = busy || problems.length > 0;
  }

  async function openModal(text, outlet) {
    await loadSettings();
    waText = text;
    nameEl.value = outlet || "";
    msgEl.value = text;
    msgEl.readOnly = !isEditMode();
    msgEl.title = isEditMode() ? "Edit mode ON - you can change the message" : "Locked - turn ON POC details edit in Settings to edit";
    resultsEl.innerHTML = "";
    renderNums();
    refreshState();
    modal.style.display = "flex";
  }
  const closeModal = () => { modal.style.display = "none"; };

  async function runWa(items, text) {
    const sent = await loadSent();
    const th = hashStr(text);
    const now = Date.now();
    const dup = items.filter((it) => sent[th + "|" + digits(it.phone)] && now - sent[th + "|" + digits(it.phone)] < 30 * 60 * 1000);
    if (dup.length && !(await uiConfirm(`This message was already sent to: ${dup.map((d) => d.phone).join(", ")}\n\nSend again?`, { title: "Already sent", okText: "Send again", cancelText: "Don't send" }))) return null;
    statusEl.textContent = "WhatsApp: saving the contact and sending the message...";
    btn.disabled = true;
    busy = true;
    sendBtn.disabled = true;
    try {
      const resp = await send("WA_SEND", { items, text });
      const okPhones = resp && resp.ok ? (resp.results || []).filter((r) => r.ok).map((r) => r.phone) : [];
      if (okPhones.length) await markSent(text, okPhones);
      const total = resp && resp.ok ? (resp.results || []).length : items.length;
      statusEl.textContent = `WhatsApp: ${okPhones.length}/${total} sent`;
      return resp;
    } finally {
      btn.disabled = false;
      busy = false;
      refreshState();
    }
  }

  // WhatsApp button: ALWAYS shows the confirmation popup first (number, contact
  // name and the exact message), nothing is sent until "Save contact + Send".
  btn.addEventListener("click", async () => {
    const { text } = await credentialsForClient();
    if (!text) {
      alert("The login credentials for this client have not been generated yet. Run the onboarding first (the output is also saved in History), then press WhatsApp.");
      return;
    }
    nums = collectClientNumbers();
    await openModal(text, outletNameForWa());
  });

  // History entry -> same confirmation popup
  async function openForHistory(item) {
    if (!item || !isCreds(item.text)) {
      alert("This history entry has no login credentials.");
      return;
    }
    let list = Array.isArray(item.phones)
      ? item.phones.map((p, i) => ({ label: p.label || "Number", number: p.number, full: p.full, checked: i === 0 }))
      : [];
    if (!list.length) {
      // Older entries have no saved numbers: reuse the current message's numbers only if it is the same client.
      const u = ((String(item.text).match(/Username\*?\s*:\s*\*?\s*([^\n*]+)/i) || [])[1] || "").trim().toLowerCase();
      const cur = String(manualOverrides.username || (parsed && parsed.username) || "").trim().toLowerCase();
      if (u && u === cur) list = collectClientNumbers();
    }
    nums = list;
    await openModal(item.text, item.name || "");
  }
  window.tmbillWA = {
    openForHistory,
    // numbers for the History entry (plain data, no UI state)
    collect: () => collectClientNumbers().map((n) => ({ label: n.label, number: n.number, full: n.full })),
  };

  addNumEl.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const c = phoneCanonical(addNumEl.value);
    if (c.kind === "bad") { alert("The number does not look valid. Enter 10 digits (starting with 6-9), or use +country code for another country."); return; }
    const hit = nums.find((x) => x.full === c.full);
    if (hit) hit.checked = true;
    else nums.push({ label: "Manual", number: c.number, full: c.full, checked: true });
    addNumEl.value = "";
    renderNums();
  });

  sendBtn.addEventListener("click", async () => {
    const chosen = nums.filter((n) => n.checked);
    const name = nameEl.value.trim();
    if (!chosen.length) { alert("Select at least one number."); return; }
    if (!name) { alert("Enter the contact name (outlet name)."); return; }
    const overwrite = document.getElementById("waOverwrite").checked;
    const items = chosen.map((n, i) => ({
      phone: n.full,
      display: n.number,
      name: i === 0 ? name : `${name} - ${n.label}`,
      label: n.label,
      overwrite,
    }));
    resultsEl.innerHTML = '<div class="wa-res">Sending...</div>';
    const finalText = msgEl.value;
    if (!finalText.trim()) { alert("The message is empty."); return; }
    if (pocMessageProblems(finalText).length) { refreshState(); alert("A POC in the message has no contact number - cannot send."); return; }
    waText = finalText;
    const resp = await runWa(items, waText);
    if (resp) showResults(resp, items);
    else resultsEl.innerHTML = "";
  });

  document.getElementById("waCopyBtn").addEventListener("click", async () => {
    const ok = await copyTextToClipboard(msgEl.value);
    statusEl.textContent = ok ? "Message copied - you can send it by SMS / call" : "Copy failed";
  });

  diagBtn.addEventListener("click", async () => {
    resultsEl.innerHTML = '<div class="wa-res">Checking...</div>';
    const resp = await send("WA_DIAG", {});
    resultsEl.innerHTML = resp && resp.ok
      ? `<div class="wa-diag">${escapeHtml(JSON.stringify(resp.diag, null, 2))}</div>`
      : `<div class="wa-res bad">${escapeHtml((resp && resp.error) || "Diagnose fail")}</div>`;
  });

  msgEl.addEventListener("input", () => { waText = msgEl.value; refreshState(); });
  document.getElementById("waCloseBtn").addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });

  // One-click assignment bridge: bypasses the manual confirmation modal but keeps
  // the same contact-save and message-verification engine.
  window.tmbillQuickWhatsApp = async function () {
    const { text } = await credentialsForClient();
    if (!text) return { ok: false, error: "Verified credentials output is missing." };
    const items = collectClientNumbers().map(n => ({ phone: n.full, name: outletNameForWa(), overwrite: false, display: n.number }));
    if (!items.length) return { ok: false, error: "No valid CX mobile number was found." };
    return await send("WA_SEND_QUICK", { items, text, openIfMissing: true });
  };
})();

// Keep the fixed top/bottom bars from covering content, however they wrap.
(function syncBars() {
  const top = document.querySelector(".floating-bar-top");
  const bottom = document.querySelector(".floating-bar-bottom");
  const fab = document.getElementById("diagnoseFab");
  if (!top || !bottom) return;
  const apply = () => {
    document.body.style.paddingTop = top.offsetHeight + "px";
    document.body.style.paddingBottom = bottom.offsetHeight + 8 + "px";
    if (fab) fab.style.bottom = bottom.offsetHeight + 10 + "px";
  };
  if (typeof ResizeObserver !== "undefined") {
    const ro = new ResizeObserver(apply);
    ro.observe(top);
    ro.observe(bottom);
  }
  window.addEventListener("resize", apply);
  apply();

})();

// ===== Copy + local History (chrome.storage.local) =====
const HISTORY_KEY = "tmbill_copy_history";
const HISTORY_MAX = 500;

async function loadHistory() {
  try {
    const stored = await chrome.storage.local.get(HISTORY_KEY);
    return Array.isArray(stored[HISTORY_KEY]) ? stored[HISTORY_KEY] : [];
  } catch (e) {
    return [];
  }
}

async function saveHistory(list) {
  try {
    await chrome.storage.local.set({ [HISTORY_KEY]: list.slice(0, HISTORY_MAX) });
  } catch (e) {
    console.warn("History save failed", e);
  }
}

async function addToHistory(text, name, extra) {
  const list = await loadHistory();
  const phones = extra && Array.isArray(extra.phones) && extra.phones.length ? extra.phones : null;
  // Same text copied again back-to-back: just refresh its time, no duplicate.
  if (list.length && list[0].text === text) {
    list[0].ts = Date.now();
    if (name) list[0].name = name;
    if (phones) list[0].phones = phones;
  } else {
    const item = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), ts: Date.now(), text, name: name || "" };
    if (phones) item.phones = phones;
    list.unshift(item);
  }
  await saveHistory(list);
  updateHistoryCount(list.length);
}

function updateHistoryCount(n) {
  const el = document.getElementById("historyCount");
  if (el) el.textContent = n ? `(${n})` : "";
}

// Copies plain text to the clipboard (with a fallback for side-panel contexts).
async function copyTextToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    ta.remove();
    return ok;
  }
}

async function copyOutput() {
  const text = outputEl.value.trim();
  if (!text) {
    alert("Please Fetch or do Onboarding first.");
    return;
  }
  const ok = await copyTextToClipboard(outputEl.value);
  if (ok) {
    const sel = document.getElementById("fsOutletSelect");
    const selText = sel && sel.value && sel.selectedOptions[0] ? sel.selectedOptions[0].text : "";
    const histName = (parsed && (parsed.outlet_name || "")) || selText || (parsed && parsed.brand_name) || "";
    await addToHistory(outputEl.value, histName);
    statusEl.textContent = "Output copied & saved to history";
  } else {
    statusEl.textContent = "Copy failed";
  }
}


// ===== Output (eye) / History popup =====
(function wireOutputModal() {
  const modal = document.getElementById("outputModal");
  const eyeBtn = document.getElementById("viewOutputBtn");
  const histBtn = document.getElementById("historyBtn");
  const closeBtn = document.getElementById("outputCloseBtn");
  const tabOutput = document.getElementById("tabOutputBtn");
  const tabHistory = document.getElementById("tabHistoryBtn");
  const outputPane = document.getElementById("outputPane");
  const historyPane = document.getElementById("historyPane");
  const modalCopyBtn = document.getElementById("modalCopyBtn");
  const searchEl = document.getElementById("historySearch");
  const listEl = document.getElementById("historyList");
  const clearBtn = document.getElementById("historyClearBtn");
  if (!modal || !eyeBtn || !histBtn) return;

  const tabStatus = document.getElementById("tabStatusBtn");
  const statusPane = document.getElementById("statusPane");
  const statusListEl = document.getElementById("statusList");

  const MARK = { done: "✓", failed: "✗", skipped: "–" };
  async function renderStatus() {
    let list = [];
    try {
      const st = await chrome.storage.local.get(RUN_LOG_KEY);
      list = Array.isArray(st[RUN_LOG_KEY]) ? st[RUN_LOG_KEY] : [];
    } catch (e) { list = []; }
    // Outlet-wise: newest run per outlet.
    const seen = new Set();
    const latest = [];
    for (const r of list.slice().sort((a, b) => b.ts - a.ts)) {
      const k = r.storeId || r.outlet || r.id;
      if (seen.has(k)) continue;
      seen.add(k);
      latest.push(r);
    }
    if (!latest.length) {
      statusListEl.innerHTML = '<p class="hint">No onboarding / Full Setup run yet.</p>';
      return;
    }
    statusListEl.innerHTML = latest.map((r) => {
      const steps = CHECKLIST_ITEMS.filter((it) => r.steps && r.steps[it.key]);
      const failed = steps.filter((it) => r.steps[it.key].status === "failed").length;
      const done = steps.filter((it) => r.steps[it.key].status === "done").length;
      const cls = failed ? "run-fail" : done ? "run-ok" : "";
      const badge = failed ? `${failed} fail` : done ? "sab OK" : "";
      const rows = steps.map((it) => {
        const s0 = r.steps[it.key];
        return `<div class="run-step st-${s0.status}"><span class="mark">${MARK[s0.status] || "•"}</span><span class="txt">${escapeHtml(it.label)}${s0.note ? `<small>${escapeHtml(s0.note)}</small>` : ""}</span></div>`;
      }).join("");
      return `<div class="run-card ${cls}">
        <div class="run-head"><strong>${escapeHtml(r.outlet || "Outlet name not found")}</strong><span class="run-time">${escapeHtml(fmtTime(r.ts))}</span></div>
        <div class="run-sub">${r.storeId ? "Store ID " + escapeHtml(r.storeId) : ""}${badge ? (r.storeId ? " · " : "") + badge : ""}</div>
        ${rows || '<div class="run-sub">No steps recorded.</div>'}
      </div>`;
    }).join("");
  }

  function showTab(name) {
    const isHistory = name === "history";
    const isOutput = name === "output";
    const isStatus = !isHistory && !isOutput;
    statusPane.style.display = isStatus ? "" : "none";
    outputPane.style.display = isOutput ? "" : "none";
    historyPane.style.display = isHistory ? "" : "none";
    tabStatus.classList.toggle("active", isStatus);
    tabOutput.classList.toggle("active", isOutput);
    tabHistory.classList.toggle("active", isHistory);
    if (isStatus) renderStatus();
    if (isHistory) {
      renderHistory();
      searchEl.focus();
    }
  }
  tabStatus.addEventListener("click", () => showTab("status"));
  function open(tab) {
    modal.style.display = "flex";
    showTab(tab);
  }
  function close() {
    modal.style.display = "none";
  }

  function usernameOf(text) {
    const m = String(text || "").match(/Username\*?\s*:\s*\*?\s*([^\n*]+)/i);
    return m && m[1].trim() ? m[1].trim() : "";
  }
  function titleOf(it) {
    if (it.name && String(it.name).trim()) return String(it.name).trim();
    const text = it.text || "";
    const m = text.match(/outlet\s*name\s*[:\-]\s*(.+)/i);
    if (m && m[1].trim()) return m[1].trim();
    return "No outlet name - press 'Outlet name'";
  }
  function fmtTime(ts) {
    try {
      return new Date(ts).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    } catch (e) {
      return "";
    }
  }

  async function renderHistory() {
    const all = await loadHistory();
    updateHistoryCount(all.length);
    const q = searchEl.value.trim().toLowerCase();
    const items = q
      ? all.filter((it) => (it.text + " " + (it.name || "")).toLowerCase().includes(q))
      : all;
    if (!items.length) {
      listEl.innerHTML = `<div class="history-empty">${all.length ? "No match found." : "Nothing saved yet. Onboarding results are saved here automatically."}</div>`;
      return;
    }
    listEl.innerHTML = items
      .map(
        (it) => `
      <div class="history-item" data-id="${it.id}">
        <div class="history-item-head">
          <strong>${escapeHtml(titleOf(it))}</strong>
          <span class="history-time">${escapeHtml(fmtTime(it.ts))}</span>
        </div>
        ${usernameOf(it.text) ? `<div class="history-sub">Username: ${escapeHtml(usernameOf(it.text))}</div>` : ""}
        <pre class="history-preview">${escapeHtml(it.text.slice(0, 400))}</pre>
        <div class="history-actions">
          <button type="button" class="btn-primary" data-act="copy">Copy</button>
          <button type="button" class="btn-soft" data-act="edit">View / Edit</button>
          <button type="button" class="btn-soft" data-act="rename">Outlet name</button>
          <button type="button" class="btn-soft btn-wa" data-act="wa">WhatsApp</button>
        </div>
      </div>`
      )
      .join("");
  }

  listEl.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const id = btn.closest(".history-item").dataset.id;
    const list = await loadHistory();
    const item = list.find((it) => it.id === id);
    if (!item) return;
    const act = btn.dataset.act;
    if (act === "copy") {
      const ok = await copyTextToClipboard(item.text);
      const old = btn.textContent;
      btn.textContent = ok ? "Copied" : "Copy failed";
      setTimeout(() => { btn.textContent = old; }, 1200);
    } else if (act === "edit") {
      setOutputRaw(item.text);
      showTab("output");
    } else if (act === "wa") {
      modal.style.display = "none"; // close History, then show the WhatsApp confirmation popup
      if (window.tmbillWA) await window.tmbillWA.openForHistory(item);
    } else if (act === "rename") {
      const nm = prompt("Outlet name (for identification):", item.name || "");
      if (nm !== null) {
        item.name = nm.trim();
        await saveHistory(list);
        renderHistory();
      }
    }
  });

  searchEl.addEventListener("input", renderHistory);
  clearBtn.addEventListener("click", async () => {
    if (!(await uiConfirm("This will permanently delete the entire copy history.", { title: "Clear all history?", okText: "Delete all", cancelText: "Keep", danger: true }))) return;
    await saveHistory([]);
    renderHistory();
  });

  eyeBtn.addEventListener("click", () => open("status"));
  histBtn.addEventListener("click", () => open("history"));
  tabOutput.addEventListener("click", () => showTab("output"));
  tabHistory.addEventListener("click", () => showTab("history"));
  modalCopyBtn.addEventListener("click", copyOutput);
  closeBtn.addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });

  loadHistory().then((l) => updateHistoryCount(l.length));
})();


// ===== Diagnose modal (floating icon opens it, X / outside click / Esc close it) =====
(function wireDiagnoseModal() {
  const fab = document.getElementById("diagnoseFab");
  const modal = document.getElementById("diagnoseModal");
  const closeBtn = document.getElementById("diagnoseCloseBtn");
  if (!fab || !modal || !closeBtn) return;
  const open = () => { modal.style.display = "flex"; document.getElementById("logInput")?.focus(); };
  const close = () => { modal.style.display = "none"; };
  fab.addEventListener("click", open);
  closeBtn.addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
})();


// =====================================================================
// 🔳 QR button — SEPARATE feature. Runs only when this button is clicked;
// it is not part of Start Onboarding / Auto-Pilot / Submit.
// Uses the outlet chosen in "Select Outlet" (or the one just onboarded),
// generates every table's QR codes (only the types that outlet has turned
// on in TMBill) and saves them as ONE ZIP + a summary CSV in
// Downloads/TMBill_QR/.
// =====================================================================
(function setupQrButton() {
  const qrBtn = document.getElementById("qrBtn");
  if (!qrBtn) return;

  const QR_PACING_MS = 700;
  const QR_TYPES = {
    tableOrder: { folderTag: "dinein_postpaid" },
    selfOrder: { folderTag: "selforder_prepaid" },
  };

  const safePart = (v) =>
    (v || "table").toString().trim().replace(/[^A-Za-z0-9._-]+/g, "_").slice(0, 60) || "table";
  const stamp = () => new Date().toISOString().replace(/[:.]/g, "-");
  const csvCell = (v) => {
    const s = v === undefined || v === null ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const say = (t) => { statusEl.textContent = t; };

  function planFor(qrConfig) {
    const c = qrConfig || {};
    const plan = [
      { qrType: "tableOrder", wantQr: !!c.tableOrderQrCode, wantWa: !!c.tableOrderWhatsAppQrCode },
      { qrType: "selfOrder", wantQr: !!c.selfOrderQrCode, wantWa: !!c.selfOrderWhatsAppQrCode },
    ].filter((p) => p.wantQr || p.wantWa);
    // Outlet has no QR type switched on -> fall back to the plain Dine-In QR.
    return plan.length ? plan : [{ qrType: "tableOrder", wantQr: true, wantWa: false }];
  }

  async function oneTable(table, ctx) {
    const folder = safePart(table.department);
    const files = [];
    for (const { qrType, wantQr, wantWa } of ctx.plan) {
      const resp = await send("QR_TABLE", {
        params: {
          tableId: table.id,
          tableName: table.name,
          restName: ctx.restName,
          storeId: ctx.storeId,
          qrType,
          generateWhatsapp: wantWa,
        },
      });
      if (!resp.ok) throw new Error(resp.error || "QR request failed");
      const body = resp.body || {};
      const base = `${folder}/${safePart(table.id)}_${safePart(table.name)}_${QR_TYPES[qrType].folderTag}`;
      if (wantQr && body.url) files.push({ name: `${base}_qr.png`, data: body.url });
      if (wantWa && body.whatsAppQr && body.whatsAppQr.url) files.push({ name: `${base}_whatsapp.png`, data: body.whatsAppQr.url });
    }
    if (!files.length) throw new Error("No QR image returned in response");
    for (const f of files) {
      const comma = f.data.indexOf(",");
      ctx.zip.file(f.name, comma >= 0 ? f.data.slice(comma + 1) : f.data, { base64: true });
    }
    return files.length;
  }

  // ---- modal: pick departments + QR types, then download ----
  const modal = document.getElementById("qrModal");
  const infoEl = document.getElementById("qrInfo");
  const bodyEl = document.getElementById("qrBody");
  const deptListEl = document.getElementById("qrDeptList");
  const typeListEl = document.getElementById("qrTypeList");
  const startBtn2 = document.getElementById("qrStartBtn");
  let qrState = null; // { storeId, restName, tables, qrConfig }

  const QR_CHOICES = [
    { id: "postpaid", label: "Postpaid QR (Dine-in)", sub: "Scan at the table, pay later", qrType: "tableOrder", kind: "qr", cfg: "tableOrderQrCode" },
    { id: "postpaidWa", label: "WhatsApp QR - Postpaid (Dine-in)", sub: "Table WhatsApp order QR", qrType: "tableOrder", kind: "wa", cfg: "tableOrderWhatsAppQrCode" },
    { id: "prepaid", label: "Prepaid QR (Self order)", sub: "Order and pay first", qrType: "selfOrder", kind: "qr", cfg: "selfOrderQrCode" },
    { id: "prepaidWa", label: "WhatsApp QR - Prepaid (Self order)", sub: "Self order WhatsApp QR", qrType: "selfOrder", kind: "wa", cfg: "selfOrderWhatsAppQrCode" },
  ];

  const closeModal = () => { modal.style.display = "none"; };
  document.getElementById("qrCloseBtn").addEventListener("click", closeModal);
  document.getElementById("qrCancelBtn").addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
  document.getElementById("qrDeptAll").addEventListener("click", () => {
    const boxes = [...deptListEl.querySelectorAll("input")];
    const allOn = boxes.every((b) => b.checked);
    boxes.forEach((b) => { b.checked = !allOn; });
  });

  const optHtml = (attrs, label, sub, checked) =>
    `<label class="qr-opt"><input type="checkbox" ${attrs} ${checked ? "checked" : ""} /><span>${escapeHtml(label)}${sub ? `<small>${escapeHtml(sub)}</small>` : ""}</span></label>`;

  qrBtn.addEventListener("click", async () => {
    const outletSelect = document.getElementById("fsOutletSelect");
    const storeId = String((outletSelect && outletSelect.value) || (parsed && parsed.store_id) || "").trim();
    if (!/^\d{5,}$/.test(storeId)) {
      alert("First choose an outlet in 'Select Outlet' above (or onboard one), then press the QR button.");
      return;
    }
    if (typeof JSZip === "undefined") {
      alert("The ZIP library did not load (vendor/jszip.min.js). Reload the extension and try again.");
      return;
    }
    modal.style.display = "flex";
    bodyEl.style.display = "none";
    infoEl.textContent = "Loading tables and departments...";
    qrBtn.disabled = true;
    try {
      const info = await send("QR_FETCH_TABLES", {
        store_id: storeId,
        masterEmail: masterEmailEl.value.trim(),
        masterPassword: masterPasswordEl.value,
      });
      if (!info.ok) throw new Error(info.error || "Could not fetch tables");
      const tables = (info.tables || []).filter((t) => t.isActive !== false);
      if (!tables.length) {
        infoEl.textContent = "This outlet has no active tables.";
        return;
      }
      qrState = { storeId, restName: info.restName || "TMBill", tables, qrConfig: info.qrConfig || {} };

      const depts = {};
      tables.forEach((t) => { depts[t.department] = (depts[t.department] || 0) + 1; });
      deptListEl.innerHTML = Object.keys(depts)
        .map((d) => optHtml(`data-dept="${escapeHtml(d).replace(/"/g, "&quot;")}"`, d, `${depts[d]} tables`, true))
        .join("");

      const anyOn = QR_CHOICES.some((c) => qrState.qrConfig[c.cfg]);
      typeListEl.innerHTML = QR_CHOICES.map((c) => {
        const on = !!qrState.qrConfig[c.cfg];
        return optHtml(`data-qr="${c.id}"`, c.label, c.sub + (on ? " - outlet me ON" : ""), anyOn ? on : c.id === "postpaid");
      }).join("");

      infoEl.textContent = `${qrState.restName} - ${tables.length} tables. Choose departments and QR types, then press Download ZIP.`;
      bodyEl.style.display = "block";
    } catch (err) {
      infoEl.textContent = `QR load failed: ${err.message || err}`;
    } finally {
      qrBtn.disabled = false;
    }
  });

  startBtn2.addEventListener("click", async () => {
    if (!qrState) return;
    const chosenDepts = [...deptListEl.querySelectorAll("input:checked")].map((b) => b.dataset.dept);
    const chosenTypes = [...typeListEl.querySelectorAll("input:checked")].map((b) => b.dataset.qr);
    if (!chosenDepts.length) { alert("Select at least one department."); return; }
    if (!chosenTypes.length) { alert("Select at least one QR type."); return; }

    const tables = qrState.tables.filter((t) => chosenDepts.includes(t.department));
    // Group the ticked boxes by qrType so each table needs at most 2 API calls.
    const plan = [];
    for (const qrType of ["tableOrder", "selfOrder"]) {
      const wantQr = QR_CHOICES.some((c) => c.qrType === qrType && c.kind === "qr" && chosenTypes.includes(c.id));
      const wantWa = QR_CHOICES.some((c) => c.qrType === qrType && c.kind === "wa" && chosenTypes.includes(c.id));
      if (wantQr || wantWa) plan.push({ qrType, wantQr, wantWa });
    }
    closeModal();

    qrBtn.disabled = true;
    startBtn2.disabled = true;
    try {
      const ctx = { storeId: qrState.storeId, restName: qrState.restName, plan, zip: new JSZip() };
      const rows = [];
      let ok = 0;
      const failedList = [];

      for (let i = 0; i < tables.length; i++) {
        const t = tables[i];
        say(`QR: ${i + 1}/${tables.length} — ${t.name}`);
        try {
          const n = await oneTable(t, ctx);
          ok++;
          rows.push([t.id, t.name, t.department, "ok", n, ""]);
        } catch (err) {
          const msg = err.message || String(err);
          failedList.push(t);
          rows.push([t.id, t.name, t.department, "failed", "", msg]);
          if (/session expired/i.test(msg)) break; // dead session, no point continuing
        }
        if (i < tables.length - 1) await sleep(QR_PACING_MS);
      }

      // Retry each failed table once (same as the standalone QR extension).
      if (failedList.length && !rows.some((r) => /session expired/i.test(r[5]))) {
        for (let i = 0; i < failedList.length; i++) {
          const t = failedList[i];
          say(`QR: retry ${i + 1}/${failedList.length} — ${t.name}`);
          await sleep(QR_PACING_MS);
          try {
            const n = await oneTable(t, ctx);
            ok++;
            const idx = rows.findIndex((r) => r[0] === t.id && r[3] === "failed");
            if (idx >= 0) rows[idx] = [t.id, t.name, t.department, "ok (retry)", n, ""];
          } catch (err) {
            /* stays failed in the CSV */
          }
        }
      }

      const failed = rows.filter((r) => r[3] === "failed").length;
      const fileCount = Object.keys(ctx.zip.files).filter((n) => !ctx.zip.files[n].dir).length;

      if (fileCount > 0) {
        say("QR: building the ZIP...");
        const blob = await ctx.zip.generateAsync({ type: "blob" });
        chrome.downloads.download({
          url: URL.createObjectURL(blob),
          filename: `TMBill_QR/TMBill_QR_${safePart(ctx.restName)}_${stamp()}.zip`,
          conflictAction: "uniquify",
        });
      }

      const csv = [["Table ID", "Table Name", "Department", "Status", "Files Saved", "Error"], ...rows]
        .map((r) => r.map(csvCell).join(","))
        .join("\n");
      chrome.downloads.download({
        url: URL.createObjectURL(new Blob([csv], { type: "text/csv" })),
        filename: `TMBill_QR/summary_${stamp()}.csv`,
        conflictAction: "uniquify",
      });

      say(`QR done: ${ok} ok, ${failed} failed (of ${tables.length}) — Downloads/TMBill_QR/`);
    } catch (err) {
      say(`QR failed: ${err.message || err}`);
    } finally {
      qrBtn.disabled = false;
      startBtn2.disabled = false;
    }
  });
})();


// ===== Slack: post "Onboarding is done" in the thread the request came from =====
(function initSlack() {
  const btn = document.getElementById("slackBtn");
  const modal = document.getElementById("slackModal");
  if (!btn || !modal) return;
  const threadEl = document.getElementById("slackThread");
  const msgEl = document.getElementById("slackMessage");
  const warnEl = document.getElementById("slackWarn");
  const forceRow = document.getElementById("slackForceRow");
  const forceEl = document.getElementById("slackForce");
  const postBtn = document.getElementById("slackPostBtn");
  const resultEl = document.getElementById("slackResult");
  const SLACK_KEY = "tmbill_slack_threads";
  const preferTab = Number(new URLSearchParams(location.search).get("tab")) || undefined;
  let captured = null; // { url, preview, at }
  let busy = false;
  const linkEl = document.getElementById("slackLink");
  const tokenEl = document.getElementById("slackToken");
  const hintEl = document.getElementById("slackModeHint");
  const TOKEN_KEY = "tmbill_slack_token";
  let token = "";

  // Accepts a permalink (.../archives/C123/p1700000000123456[?thread_ts=...]) or a web-client thread URL
  function parseRef(url) {
    const u = String(url || "").trim();
    let m = u.match(/\/archives\/([A-Z0-9]+)\/p(\d{10})(\d{6})(?:[^#]*[?&]thread_ts=(\d+\.\d+))?/i);
    if (m) return { channel: m[1], ts: m[4] || `${m[2]}.${m[3]}` };
    m = u.match(/\/client\/([A-Z0-9]+)\/([A-Z0-9]+)\/thread\/[A-Z0-9]+-(\d+\.\d+)/i);
    if (m) return { team: m[1], channel: m[2], ts: m[3] };
    return null;
  }
  function currentRef(saved) {
    return parseRef(linkEl.value) || (saved && parseRef(saved.url)) || null;
  }
  function updateHint() {
    hintEl.textContent = token
      ? "Mode: Slack API - posts as YOU to the thread (desktop/web/mobile all show it)."
      : "Mode: browser Slack tab. Add your token in Settings (gear) to post to the Slack desktop app.";
  }

  function outletName() {
    const sel = document.getElementById("fsOutletSelect");
    const selText = sel && sel.value && sel.selectedOptions[0] ? sel.selectedOptions[0].text : "";
    return String(manualOverrides.outlet_name || (parsed && parsed.outlet_name) || selText || "").trim();
  }
  function needles() {
    const list = [outletName(), manualOverrides.mobile || (parsed && parsed.mobile) || ""];
    return list.map((x) => String(x || "").trim()).filter(Boolean);
  }
  function defaultMessage() {
    const n = outletName();
    return n ? `Onboarding is done for *${n}* \u2705` : "Onboarding is done \u2705";
  }

  // Called when Fetch is pressed: a pasted Slack link wins; otherwise the thread open in browser Slack.
  let pastedLink = null; // set when details were loaded from a pasted link
  function capture() {
    if (pastedLink) {
      captured = { url: pastedLink, preview: "", at: Date.now() };
      pastedLink = null;
      return Promise.resolve(captured);
    }
    return send("SLACK_PEEK", { preferTab })
      .then((r) => {
        if (r && r.ok && r.thread) captured = { url: r.thread.url, preview: r.preview || "", at: Date.now() };
        return captured;
      })
      .catch(() => captured);
  }
  async function saveAfterParse(pending) {
    try {
      const c = pending && typeof pending.then === "function" ? await pending : pending;
      if (!c || !c.url) return;
      c.outlet = outletName();
      captured = c;
      const st = await chrome.storage.local.get(SLACK_KEY);
      const map = st[SLACK_KEY] || {};
      map[(c.outlet || "last").toLowerCase()] = c;
      await chrome.storage.local.set({ [SLACK_KEY]: map });
    } catch (e) { /* ignore */ }
  }
  // The thread belonging to the outlet currently shown
  async function pickSaved() {
    if (captured && (!captured.outlet || captured.outlet.toLowerCase() === outletName().toLowerCase())) return captured;
    return (await savedFor(outletName())) || captured;
  }

  async function savedFor(name) {
    try {
      const st = await chrome.storage.local.get(SLACK_KEY);
      const map = st[SLACK_KEY] || {};
      return map[String(name || "").toLowerCase()] || null;
    } catch (e) {
      return null;
    }
  }

  async function refresh() {
    threadEl.textContent = "Checking the Slack tab...";
    warnEl.textContent = "";
    forceRow.style.display = "none";
    forceEl.checked = false;
    const r = await send("SLACK_PEEK", { preferTab });
    const savedEarly = await pickSaved();
    if (!r || !r.ok) {
      if (token && currentRef(savedEarly)) {
        threadEl.innerHTML = `<span class="st-ok">Thread ready (Slack API)</span>`;
      } else if (token) {
        threadEl.innerHTML = `<span class="st-bad">Paste the Slack message link (Copy link) of the onboarding request in "Thread link".</span>`;
      } else {
        threadEl.innerHTML = `<span class="st-bad">${escapeHtml((r && r.error) || "Slack not reachable")}</span>`;
      }
      return;
    }
    const saved = await pickSaved();
    if (!linkEl.value && saved && saved.url) linkEl.value = saved.url;
    const html = [];
    if (token && currentRef(saved)) {
      html.push(`<span class="st-ok">Thread ready (Slack API)</span>`);
      if (r.preview) html.push(`<div class="st-prev">${escapeHtml(r.preview)}</div>`);
    } else if (r.hasPane) {
      html.push(`<span class="st-ok">Thread is open in Slack</span>`);
      if (r.preview) html.push(`<div class="st-prev">${escapeHtml(r.preview)}</div>`);
    } else if (saved && saved.url) {
      html.push(`<span class="st-ok">Saved thread will be opened</span>`);
      if (saved.preview) html.push(`<div class="st-prev">${escapeHtml(saved.preview)}</div>`);
    } else {
      html.push(`<span class="st-bad">No thread open.</span> Open the onboarding request's thread in Slack (click its replies), then press Refresh.`);
    }
    threadEl.innerHTML = html.join("");
  }

  async function post() {
    if (busy) return;
    const text = msgEl.value.trim();
    if (!text) { warnEl.textContent = "Message is empty."; return; }
    busy = true;
    postBtn.disabled = true;
    warnEl.textContent = "";
    resultEl.innerHTML = "";
    statusEl.textContent = "Posting in Slack thread...";
    const saved = await pickSaved();
    const ref = currentRef(saved);
    let r;
    if (token) {
      if (!ref) {
        busy = false;
        postBtn.disabled = false;
        warnEl.textContent = 'Paste the Slack message link of the onboarding request in "Thread link".';
        statusEl.textContent = "Thread link needed";
        return;
      }
      r = await send("SLACK_API_POST", { params: { token, channel: ref.channel, ts: ref.ts, text, needles: needles(), force: !!forceEl.checked } });
    } else r = await send("SLACK_POST", {
      params: {
        preferTabId: preferTab,
        threadUrl: saved && saved.url ? saved.url : "",
        text,
        needles: needles(),
        force: !!forceEl.checked,
      },
    });
    busy = false;
    postBtn.disabled = false;
    if (r && r.ok) {
      const note = r.confirmed ? "Posted in the thread \u2713" : "Sent - please glance at Slack to confirm it appeared";
      resultEl.innerHTML = `<div class="wa-res ${r.confirmed ? "ok" : "warn"}">${escapeHtml(note)}</div>`;
      statusEl.textContent = note;
      return;
    }
    const msg = (r && r.error) || "Could not post in Slack";
    warnEl.textContent = msg;
    statusEl.textContent = "Slack post failed";
    if (r && r.code === "WRONG_THREAD") forceRow.style.display = "flex";
    if (r && r.preview) resultEl.innerHTML = `<div class="wa-res bad">Open thread: ${escapeHtml(r.preview)}</div>`;
  }

  btn.addEventListener("click", async () => {
    await loadToken();
    linkEl.value = "";
    msgEl.value = defaultMessage();
    resultEl.innerHTML = "";
    modal.style.display = "flex";
    await refresh();
  });
  document.getElementById("slackCloseBtn").addEventListener("click", () => { modal.style.display = "none"; });
  document.getElementById("slackRefreshBtn").addEventListener("click", refresh);
  postBtn.addEventListener("click", post);
  const tokenMsgEl = document.getElementById("slackTokenMsg");
  async function loadToken() {
    try {
      const st = await chrome.storage.local.get(TOKEN_KEY);
      token = String(st[TOKEN_KEY] || "");
      tokenEl.value = token;
    } catch (e) { /* ignore */ }
    updateHint();
  }
  tokenEl.addEventListener("change", async () => {
    token = tokenEl.value.trim();
    try { await chrome.storage.local.set({ [TOKEN_KEY]: token }); } catch (e) { /* ignore */ }
    updateHint();
  });
  document.getElementById("slackTokenTest").addEventListener("click", async () => {
    const t = tokenEl.value.trim();
    if (!t) { tokenMsgEl.textContent = "Paste a token first."; return; }
    const r = await send("SLACK_AUTH_TEST", { token: t });
    if (r && r.ok && r.isBot) tokenMsgEl.textContent = `This is a BOT token (${r.user}) - messages would NOT go in your name. Use your user token (xoxp-).`;
    else tokenMsgEl.textContent = r && r.ok ? `Token OK - messages will be posted as YOU (${r.user} @ ${r.team})` : `Token problem: ${(r && r.error) || "unknown"}`;
  });
  document.getElementById("slackOpenBtn").addEventListener("click", async () => {
    const saved = await pickSaved();
    const ref = currentRef(saved);
    if (!ref) { warnEl.textContent = "No thread link yet."; return; }
    let team = ref.team;
    if (!team && token) { const a = await send("SLACK_AUTH_TEST", { token }); team = a && a.team_id; }
    if (!team) { warnEl.textContent = "Team id unknown - paste a token (Test) or open the thread once in browser Slack."; return; }
    // Opens the Slack desktop app at that thread
    chrome.tabs.create({ url: `slack://channel?team=${team}&id=${ref.channel}&message=${ref.ts}&thread_ts=${ref.ts}`, active: false }).catch(() => {});
  });
  document.getElementById("slackCopyBtn").addEventListener("click", async () => {
    const ok = await copyTextToClipboard(msgEl.value);
    statusEl.textContent = ok ? "Message copied" : "Copy failed";
  });

  // ---- Paste a Slack message link into the main box -> details load + Fetch runs ----
  const LINK_RE = /https?:\/\/[a-z0-9.-]*slack\.com\/archives\/[A-Z0-9]+\/p\d{16}[^\s]*/i;
  async function loadFromLink(url) {
    const ref = parseRef(url);
    if (!ref) return;
    try {
      const st = await chrome.storage.local.get(TOKEN_KEY);
      token = String(st[TOKEN_KEY] || "");
    } catch (e) { /* ignore */ }
    if (!token) {
      statusEl.textContent = "Slack token needed once - add it in Settings, then paste the link again";
      document.getElementById("settingsBtn").click();
      setTimeout(() => { tokenEl.focus(); tokenMsgEl.textContent = "Add your Slack user token here once, then paste the link again."; }, 50);
      return;
    }
    statusEl.textContent = "Reading the onboarding request from Slack...";
    const r = await send("SLACK_FETCH_MESSAGE", { params: { token, channel: ref.channel, ts: ref.ts } });
    if (!r || !r.ok) {
      statusEl.textContent = "Slack read failed";
      alert((r && r.error) || "Could not read the Slack message.");
      return;
    }
    inputEl.value = r.text;
    pastedLink = url;
    if (r.unresolved) {
      alert(`${r.unresolved} @mention name(s) in the message could not be read (POC names may be missing).\n\nAdd the "users:read" User Token Scope in your Slack app, reinstall, and paste the new token in Settings.`);
    }
    statusEl.textContent = "Details loaded from Slack - fetching...";
    parseBtn.click();
  }
  inputEl.addEventListener("paste", (e) => {
    const t = ((e.clipboardData && e.clipboardData.getData("text")) || "").trim();
    if (LINK_RE.test(t) && t.split(/\s+/).length === 1) {
      e.preventDefault();
      loadFromLink(t);
    }
  });
  inputEl.addEventListener("input", () => {
    const t = inputEl.value.trim();
    if (LINK_RE.test(t) && t.split(/\s+/).length === 1) loadFromLink(t);
  });

  // Reads the saved/pasted Slack thread (all replies) and returns the Back Office login found there
  async function credsFromThread() {
    try {
      if (!token) await loadToken();
      if (!token) return null;
      let ref = currentRef(await pickSaved());
      if (!ref) {
        const r = await send("SLACK_PEEK", { preferTab });
        if (r && r.ok && r.thread) ref = parseRef(r.thread.url);
      }
      if (!ref) return null;
      const r = await send("SLACK_FETCH_MESSAGE", { params: { token, channel: ref.channel, ts: ref.ts } });
      if (!r || !r.ok || typeof extractLoginCreds !== "function") return null;
      const c = extractLoginCreds(r.text).backoffice;
      return c && c.username && c.password ? c : null;
    } catch (e) { return null; }
  }
  window.tmbillSlack = { capture, saveAfterParse, loadToken, credsFromThread };
})();

// ── Full Setup UX: step counter, Select all / Clear, outlet toggle state ─────
(function () {
  const stepEls = [
    setupPosTablesEl, setupMenuEl, setupPaymentModesEl, setupDigitalOrderingEl,
    setupDesignationEl, setupUsersEl, setupDiscountsEl,
  ];
  const outletEl = document.getElementById("createOutletMode");
  const outletSel = document.getElementById("fsOutletSelect");
  const outletReq = document.getElementById("fsOutletReq");
  const outletHint = document.getElementById("outletModeHint");
  const outletGroup = outletEl.closest(".outlet-group");
  const countEl = document.getElementById("fsSelCount");

  function refresh() {
    const n = stepEls.filter((e) => e.checked).length;
    countEl.textContent = `${n} of ${stepEls.length} steps selected` + (outletEl.checked ? " + Outlet" : "");

    const creating = outletEl.checked;
    outletGroup.classList.toggle("is-off", !creating);
    outletHint.textContent = creating
      ? "A new outlet and its owner user will be created from the message. If the outlet already exists it is detected and reused - no duplicate."
      : "Outlet creation is OFF. Pick the existing outlet in Select Outlet below, then press Start Onboarding or Submit.";
    outletReq.classList.toggle("pulse", !creating && !outletSel.value);
    outletSel.classList.toggle("need", !creating && !outletSel.value);
    outletReq.title = creating ? "Optional now - filled automatically after the outlet is created" : "Required: choose the existing outlet";
  }

  stepEls.forEach((e) => e.addEventListener("change", refresh));
  outletEl.addEventListener("change", refresh);
  outletSel.addEventListener("change", refresh);
  new MutationObserver(refresh).observe(outletSel, { childList: true });

  document.getElementById("fsSelAll").addEventListener("click", () => { stepEls.forEach((e) => { e.checked = true; e.dispatchEvent(new Event("change", { bubbles: true })); }); refresh(); });
  document.getElementById("fsSelNone").addEventListener("click", () => { stepEls.forEach((e) => { e.checked = false; e.dispatchEvent(new Event("change", { bubbles: true })); }); refresh(); });

  refresh();
})();


async function finishQuickAssignment(details, setupLabel) {
  quickProgress("Sending CX credentials…", "Saving the client contact and sending the verified credentials message.");
  let wa = { ok: false, error: "WhatsApp automation unavailable" };
  try { if (window.tmbillQuickWhatsApp) wa = await window.tmbillQuickWhatsApp(); } catch (e) { wa = { ok: false, error: String(e && e.message || e) }; }
  if (!wa.ok || (wa.results || []).some(r => !r.ok || r.confirmed === false || (!r.saved && r.keptName === undefined))) {
    quickProgressDone(false, "WhatsApp verification required", (wa.error || "The contact/message could not be fully verified.") + " Slack completion update was not sent.");
    statusEl.textContent = "Onboarding created, but WhatsApp verification failed";
    return;
  }
  quickProgress("Updating Slack thread…", "Posting the completion status only after TMBill and WhatsApp verification pass.");
  try {
    const st = await chrome.storage.local.get(["tmbill_assignment_context", "tmbill_slack_token"]);
    const ctx = st.tmbill_assignment_context || {};
    const token = String(st.tmbill_slack_token || "").trim();
    if (!token || !ctx.channel || !ctx.ts) throw new Error("Slack thread context or User token is missing.");
    const outlet = details && details.outlet_name ? details.outlet_name : "Client";
    const text = `*${outlet} Outlet — Onboarding Completed*\nLogin credentials have been shared with the client.`;
    const r = await send("SLACK_API_POST", { params: { token, channel: ctx.channel, ts: ctx.ts, text, needles: [outlet, String(store)], force: false } });
    if (!r || !r.ok || r.confirmed === false) throw new Error((r && r.error) || "Slack thread update could not be verified.");
    await chrome.storage.local.remove("tmbill_assignment_context");
    quickProgressDone(true, "Onboarding complete ✓", "TMBill, WhatsApp and Slack thread updates were verified.");
    statusEl.textContent = `Quick onboarding complete — Store ID ${store}`;
  } catch (e) {
    quickProgressDone(false, "Slack update needs attention", String(e && e.message || e));
    statusEl.textContent = "Onboarding verified, but Slack update was not confirmed";
  }
}

// ===== Slack assignment notification handoff =====
(function initSlackAssignmentHandoff() {
  const KEY = "tmbill_pending_slack_assignment";
  async function consumePendingAssignment() {
    try {
      const st = await chrome.storage.local.get(KEY);
      const a = st[KEY];
      if (!a || !a.text) return;
      inputEl.value = a.text;
      try { await chrome.storage.local.remove(KEY); } catch (e) {}
      pastedLink = a.link || "";
      statusEl.textContent = `New Slack assignment loaded${a.outlet ? ` - ${a.outlet}` : ""}. Parsing...`;
      if (QUICK_ASSIGNMENT_MODE) {
        ensureQuickProgress();
        quickProgress("Starting one-click onboarding…", a.outlet ? `Client: ${a.outlet}` : "Slack assignment loaded");
        try { chrome.runtime.sendMessage({ action: "AGENT_PROGRESS", patch: { status: "starting", outlet: a.outlet || "", channel: a.channel || "", ts: a.ts || "" } }).catch(() => {}); } catch (e) {}
        // Let the page finish restoring saved login/settings before starting.
        setTimeout(async () => {
          try {
            // You verify (or edit) the Back Office login first; only then onboarding starts.
            try { await loadMasterLogin(); } catch (e) { /* use what is in the fields */ }
            const go = await askBackofficeLogin(a.outlet || "");
            if (!go) { quickProgressDone(false, "Cancelled", "No changes were made. Press Start Onboarding on the notification again when you are ready."); return; }
            startBtn.click();
          } catch (e) { quickProgressDone(false, "Could not start onboarding", String(e && e.message || e)); }
        }, 450);
      } else parseBtn.click();
    } catch (e) {}
  }
  consumePendingAssignment();
})();
// Asks for the client's Back Office (owner) username / password when neither the message nor the Slack thread has them.
function askOwnerCreds(u, pw) {
  return new Promise((resolve) => {
    const $ = (id) => document.getElementById(id);
    const modal = $("credAskModal");
    if (!modal) return resolve(null);
    $("credAskUser").value = u || "";
    $("credAskPass").value = pw || "";
    modal.style.display = "flex";
    setTimeout(() => $("credAskUser").focus(), 50);
    const done = (v) => {
      modal.style.display = "none";
      $("credAskOk").removeEventListener("click", onOk);
      $("credAskSkip").removeEventListener("click", onNo);
      $("credAskClose").removeEventListener("click", onNo);
      resolve(v);
    };
    const onOk = () => {
      const a = $("credAskUser").value.trim(), b = $("credAskPass").value.trim();
      if (!a || !b) { $("credAskWarn").textContent = "Enter both username and password, or press Skip."; return; }
      done({ username: a, password: b });
    };
    const onNo = () => done(null);
    $("credAskOk").addEventListener("click", onOk);
    $("credAskSkip").addEventListener("click", onNo);
    $("credAskClose").addEventListener("click", onNo);
  });
}
// Shows the Back Office login (prefilled from the saved login, editable). Resolves true on "Verify & Start".
function askBackofficeLogin(clientName) {
  return new Promise((resolve) => {
    const $ = (id) => document.getElementById(id);
    const modal = $("loginAskModal");
    if (!modal) return resolve(true);
    $("loginAskClient").textContent = clientName ? `Client: ${clientName}` : "New assignment";
    $("loginAskEmail").value = masterEmailEl.value || "";
    $("loginAskPass").value = masterPasswordEl.value || "";
    $("loginAskRemember").checked = rememberPasswordEl.checked;
    $("loginAskWarn").textContent = "";
    modal.style.display = "flex";
    setTimeout(() => { const f = $("loginAskEmail").value ? $("loginAskPass") : $("loginAskEmail"); f.focus(); }, 50);
    const done = (ok) => {
      modal.style.display = "none";
      $("loginAskOk").removeEventListener("click", onOk);
      $("loginAskCancel").removeEventListener("click", onNo);
      $("loginAskClose").removeEventListener("click", onNo);
      modal.removeEventListener("keydown", onKey);
      resolve(ok);
    };
    const onOk = () => {
      const em = $("loginAskEmail").value.trim(), pw = $("loginAskPass").value;
      masterEmailEl.value = em;
      masterPasswordEl.value = pw;
      rememberPasswordEl.checked = $("loginAskRemember").checked;
      ["input", "change"].forEach((t) => { masterEmailEl.dispatchEvent(new Event(t)); rememberPasswordEl.dispatchEvent(new Event(t)); });
      window.__enforceLogin = !!(em && pw); // log out any other Back Office account, then sign in with these
      // You just verified the account here, so the extra "is this the right account?" question is skipped.
      try { chrome.storage.local.set({ tmbill_acct_confirmed: Date.now() }); } catch (e) { /* ignore */ }
      done(true);
    };
    const onNo = () => done(false);
    const onKey = (e) => { if (e.key === "Enter") onOk(); else if (e.key === "Escape") onNo(); };
    $("loginAskOk").addEventListener("click", onOk);
    $("loginAskCancel").addEventListener("click", onNo);
    $("loginAskClose").addEventListener("click", onNo);
    modal.addEventListener("keydown", onKey);
  });
}

// ── Login bar: toggle collapse ──────────────────────────────────────────────
(function () {
  const btn = document.getElementById("loginBarBtn");
  const card = document.getElementById("loginCard");
  const caret = btn && btn.querySelector(".login-bar-caret");
  const savedTag = document.getElementById("savedTag");
  if (!btn || !card) return;
  function setOpen(open) {
    card.style.display = open ? "" : "none";
    btn.setAttribute("aria-expanded", open);
    if (caret) caret.style.transform = open ? "rotate(180deg)" : "";
  }
  btn.addEventListener("click", () => setOpen(card.style.display === "none"));
  setOpen(false); // always closed by default - opens only when you click it
  // When user saves credentials, show "saved" state and collapse
  document.getElementById("rememberPassword") && document.getElementById("rememberPassword").addEventListener("change", function() {
    if (!this.checked) return;
    setTimeout(() => setOpen(false), 600);
  });
})();

// ── Optional IDs: closed by default, click to open ─────────────────────────
(function () {
  const btn = document.getElementById("optIdsBtn");
  const card = document.getElementById("optIdsCard");
  const caret = btn && btn.querySelector(".login-bar-caret");
  if (!btn || !card) return;
  const setOpen = (open) => { card.style.display = open ? "" : "none"; btn.setAttribute("aria-expanded", open); if (caret) caret.style.transform = open ? "rotate(180deg)" : ""; };
  btn.addEventListener("click", () => setOpen(card.style.display === "none"));
  setOpen(false);
})();

// ── After onboarding: offer WhatsApp to the client, after Submit: offer the Slack thread post ──
function waitModalClosed(id) {
  return new Promise((resolve) => {
    const el = document.getElementById(id);
    if (!el) return resolve();
    const t = setInterval(() => { if (el.style.display === "none") { clearInterval(t); resolve(); } }, 400);
    setTimeout(() => { clearInterval(t); resolve(); }, 10 * 60 * 1000);
  });
}
async function offerWhatsApp() {
  if (QUICK_ASSIGNMENT_MODE) return;
  const b = document.getElementById("waBtn");
  if (!b || !outputEl.value.trim()) return;
  const ok = await uiConfirm("Onboarding is complete.\n\nSend the login details to the client on WhatsApp now?", { title: "Share on WhatsApp", okText: "Yes, open WhatsApp", cancelText: "Not now" });
  if (!ok) return;
  b.click();
  await new Promise((r) => setTimeout(r, 600));
  await waitModalClosed("waModal");
}
async function offerSlackPost() {
  if (QUICK_ASSIGNMENT_MODE) return;
  const b = document.getElementById("slackBtn");
  if (!b) return;
  const ok = await uiConfirm("Setup is submitted.\n\nPost \"Onboarding is done\" in the Slack thread this request came from?", { title: "Post in Slack thread", okText: "Yes, open Slack post", cancelText: "Not now" });
  if (ok) b.click();
}

// ── Review panel: Cancel button wires to hiding the panel ───────────────────
(function () {
  const cancelBtn = document.getElementById("reviewCancelBtn");
  const panel = document.getElementById("missingFieldsRow");
  if (cancelBtn && panel) {
    cancelBtn.addEventListener("click", () => { panel.style.display = "none"; });
  }
})();

// ── Unmapped lines: pop up a field-selector modal instead of inline selects ─
(function () {
  // Intercept the unmappedBox render to show a cleaner modal popup
  const origBox = document.getElementById("unmappedBox");
  if (!origBox) return;
  // We use a MutationObserver to watch for unmapped content appearing
  const observer = new MutationObserver(() => {
    const rows = origBox.querySelectorAll(".rv-un");
    if (!rows.length) return;
    // Wrap in a popup-style card if not already wrapped
    if (origBox.classList.contains("unmapped-popup-active")) return;
    origBox.classList.add("unmapped-popup-active");
    const head = origBox.querySelector(".rv-un-head");
    if (head) {
      head.innerHTML = '<span>⚠️ Unrecognised lines — assign each to a field</span><span class="unmapped-count">' + rows.length + ' item' + (rows.length > 1 ? "s" : "") + '</span>';
    }
  });
  observer.observe(origBox, { childList: true, subtree: true });
})();
