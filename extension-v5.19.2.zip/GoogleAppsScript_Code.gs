/**
 * ═══ EK HI PROJECT, EK HI doPost() ═══
 *  1) Daily Support Query Log (HTML page)  → daily Google Sheet      (urlencoded POST)
 *  2) TMBill Smart Onboarding Agent        → "INDIA Client" tab       (JSON POST + _secret)
 *  3) onEdit: column C bharte hi  A = timestamp,  B = serial
 *
 * ❗ Pehle 2 alag doPost() the (Auto Fill.gs aur Client Form.gs). Apps Script me same naam ke
 *    2 function hon to sirf aakhri file wala chalta hai, isliye daily form ka data onboarding
 *    wale code me jaakar chupchap fail ho raha tha. Ab sirf ye ek doPost() hai, jo request
 *    dekhkar sahi handler ko bhejta hai.
 *
 * SETUP
 *  1. Purani teeno files (Date_time_automation.gs, Auto Fill.gs, Client Form.gs) ka code hatao
 *     (ya files delete karo) aur sirf ye code rakho. Warna same naam phir se takraayenge.
 *  2. Project Settings > Script Properties me SHEETS_SHARED_SECRET hona chahiye (onboarding ke liye).
 *  3. Deploy > Manage deployments > pencil > Version: New version > Deploy  (URL wahi rahega).
 *
 * ── NEW: auto learning share ──
 *  • JSON with action:'learning' goes to handleLearning_ (Script Properties: LEARN_KEY, GITHUB_TOKEN, GITHUB_REPO).
 *    Daily form + onboarding sheet code below is unchanged.
 *
 * ── NEW (form v7) ──
 *  • Serial / short code: form Settings me "Auto-continue Sequence" ON karo -> last code ka agla
 *    code (TKT-0045 -> TKT-0046, ya 1930 -> 1931) chuni hui column me likha jata hai.
 *  • Form / Sheet delivery confirm: doGet ?act=chk. Form confirm ke liye FORM_EDIT_URL bharo.
 */

/* ───────── SETTINGS ───────── */
// Daily sheet: khali = wahi spreadsheet jisse ye script juda hai (Sheet me Extensions > Apps Script se bana ho).
// Agar project standalone hai to us Sheet ka ID yahan daalo.
const DAILY_SPREADSHEET_ID = '';
const GID = null; // khali = pehli tab. Khaas tab chahiye to uska gid number (sheet link me gid=...)

// Serial: agar column me koi purana number na mile to (SEQ_FALLBACK + 1) se shuru hoga (pehle 1927 tha).
const SEQ_FALLBACK = 1927;

// (optional) Company Form ki EDIT link: https://docs.google.com/forms/d/FORM_ID/edit
// Is Google account ko us Form ka editor access chahiye. Khali = Form confirm band.
const FORM_EDIT_URL = '';

// Onboarding tool → INDIA Client sheet
const SPREADSHEET_ID = '1rTtsPuXEC4Bzl0O5qLBZbtH1XDULUGUkbG31jOLJgVs';
const TARGET_SHEET_NAME = 'INDIA Client';

/* ───────── ROUTER ───────── */
function doPost(e) {
  try {
    const raw = (e && e.postData && e.postData.contents) || '';
    // Onboarding tool JSON bhejta hai ({...}); daily HTML form urlencoded bhejta hai (a=b&c=d).
    if (!/^\s*\{/.test(raw)) return handleDaily_(e);
    // JSON: either the anonymous learning data (own key) or the onboarding sheet row (SHEETS_SHARED_SECRET)
    let act = '';
    try { act = JSON.parse(raw).action || ''; } catch (_) {}
    if (act === 'learning') return handleLearning_(JSON.parse(raw), PropertiesService.getScriptProperties());
    return handleOnboarding_(e);
  } catch (err) {
    console.error('doPost failed: ' + (err && err.stack || err));
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

/* ───────── 1) DAILY FORM → daily sheet ───────── */
function dailySS_() {
  return DAILY_SPREADSHEET_ID ? SpreadsheetApp.openById(DAILY_SPREADSHEET_ID) : SpreadsheetApp.getActiveSpreadsheet();
}

function getSheet_(tab) {
  const ss = dailySS_();
  if (!ss) return null;
  if (tab) return ss.getSheetByName(tab);
  return ss.getSheets().find(s => s.getSheetId() === GID) || ss.getSheets()[0];
}

function colIdx_(c) {
  return String(c || '').toUpperCase().replace(/[^A-Z]/g, '')
    .split('').reduce((a, ch) => a * 26 + ch.charCodeAt(0) - 64, 0) - 1;
}

function handleDaily_(e) {
  const p = (e && e.parameter) || {};
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const cache = CacheService.getScriptCache();
    if (p.rid && cache.get(p.rid)) return json_({ ok: true, dup: true });
    const sh = getSheet_(p.tab);
    if (!sh) {
      console.error('Daily sheet not found. tab=' + (p.tab || '(first)'));
      return json_({ ok: false, error: 'Daily sheet/tab not found (tab: "' + (p.tab || 'pehli tab') + '"). Standalone project ho to DAILY_SPREADSHEET_ID bharo.' });
    }
    let map = {};
    try { map = JSON.parse(p.map || '{}'); } catch (_) {}
    const r = sh.getLastRow() + 1;
    const written = {};
    for (const k in map) {
      if (k === 'seq') continue;              // seq niche alag se likha jata hai
      const i = colIdx_(map[k]);
      if (i < 0 || p[k] === undefined) continue;
      sh.getRange(r, i + 1).setValue(p[k]);   // sirf mapped cells likho, baaki columns ko mat chhedo
      written[i + 1] = true;
    }
    // Auto-continue sequence / short code (form Settings se ON ho to)
    if (map.seq) {
      const si = colIdx_(map.seq);
      if (si >= 0) {
        sh.getRange(r, si + 1).setValue(nextSeq_(sh, si, r));
        written[si + 1] = true;
      }
    }
    // Script se likhne par onEdit nahi chalta, isliye wahi kaam yahan karo (column C bhara ho to).
    if (written[3]) autoFillRow_(sh, r);
    if (p.rid) cache.put(p.rid, '1', 600);
    return json_({ ok: true, row: r });
  } finally {
    lock.releaseLock();
  }
}

// Column me last code dhundo (neeche se upar) aur agla do. skipRow = jo row abhi ban rahi hai.
// TKT-0045 -> TKT-0046, 1930 -> 1931, A9 -> A10. Kuch na mile to SEQ_FALLBACK + 1.
function nextSeq_(sh, idx, skipRow) {
  const last = sh.getLastRow();
  if (last >= 2) {
    const vals = sh.getRange(2, idx + 1, last - 1, 1).getDisplayValues();   // row 1 = header, skip
    for (let i = vals.length - 1; i >= 0; i--) {
      if (i + 2 === skipRow) continue;
      const v = String(vals[i][0]).trim();
      const m = v.match(/^(.*?)(\d+)(\D*)$/);
      if (!m) continue;
      const n = String(parseInt(m[2], 10) + 1);
      const out = m[1] + (n.length < m[2].length ? '0'.repeat(m[2].length - n.length) + n : n) + m[3];
      return (m[1] === '' && m[3] === '' && !/^0\d/.test(out)) ? Number(out) : out;
    }
  }
  return SEQ_FALLBACK + 1;
}

// Aaj ki entries ka count: ?date=YYYY-MM-DD&dcol=A&tab=Sheet1
function countRows_(p) {
  const sh = getSheet_(p.tab);
  if (!sh || !p.date) return 0;
  const col = colIdx_(p.dcol || 'A') + 1;
  const last = sh.getLastRow();
  if (last < 1 || col < 1) return 0;
  const tz = sh.getParent().getSpreadsheetTimeZone();
  const vals = sh.getRange(1, col, last, 1).getValues();
  let n = 0;
  vals.forEach(r => {
    const v = r[0];
    const s = v instanceof Date ? Utilities.formatDate(v, tz, 'yyyy-MM-dd') : String(v).slice(0, 10);
    if (s === p.date) n++;
  });
  return n;
}

// Google Form ke recent responses (confirm ke liye). Access na ho to ok:false + reason.
function formInfo_(p) {
  if (!FORM_EDIT_URL) return { ok: false, err: 'FORM_EDIT_URL is blank in the script' };
  try {
    const f = FormApp.openByUrl(FORM_EDIT_URL);
    const rs = f.getResponses(new Date(+p.since || (Date.now() - 3 * 3600 * 1000)));
    const recent = rs.slice(-10).map(r => ({
      id: r.getId(),
      t: r.getTimestamp().getTime(),
      a: r.getItemResponses().map(ir => { const v = ir.getResponse(); return Array.isArray(v) ? v.join(', ') : String(v); })
    }));
    return { ok: true, recent: recent };
  } catch (err) {
    return { ok: false, err: String(err && err.message || err).slice(0, 120) };
  }
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.act === 'chk') {
    const o = { count: countRows_(p), form: formInfo_(p) };
    if (p.rid) o.sheetRid = !!CacheService.getScriptCache().get(p.rid);
    return json_(o);
  }
  return json_({ count: countRows_(p) });
}

/* ───────── 3) onEdit: Timestamp (A) + Serial (B) ───────── */
function onEdit(e) {
  if (!e || !e.range) return;
  if (e.range.getColumn() === 3) autoFillRow_(e.range.getSheet(), e.range.getRow());   // Column C
}

function autoFillRow_(sheet, row) {
  if (row <= 1) return; // header
  const timestampCell = sheet.getRange(row, 1); // Column A
  const serialCell = sheet.getRange(row, 2);    // Column B
  if (timestampCell.getValue() === '') {
    timestampCell.setValue(Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'dd-MM-yyyy HH:mm:ss'));
  }
  if (serialCell.getValue() === '') {
    serialCell.setValue(nextSeq_(sheet, 1, row));   // last serial + 1 (sirf upar wali row nahi, poora column dekhta hai)
  }
}

/* ───────── 2) TMBill Smart Onboarding Agent → INDIA Client ─────────
 * Deploy as a Web App, execute as your Google account, access: Anyone.
 * Protect the endpoint with Script Properties -> SHEETS_SHARED_SECRET.
 */
function handleOnboarding_(e) {
  const lock = LockService.getScriptLock();
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const expected = PropertiesService.getScriptProperties().getProperty('SHEETS_SHARED_SECRET') || '';
    if (!expected || !body._secret || !constantTimeEquals_(String(body._secret), expected)) {
      return json_({ ok: false, error: 'Unauthorized: shared secret mismatch.' });
    }
    if (body.test === true) return json_({ ok: true, message: 'Connection test passed. No row was added.' });
    if (!body.outlet_name || !String(body.outlet_name).trim()) {
      return json_({ ok: false, error: 'Outlet Name is required.' });
    }
    lock.waitLock(15000);
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheet = ss.getSheetByName(TARGET_SHEET_NAME);
    if (!sheet) return json_({ ok: false, error: 'Tab "' + TARGET_SHEET_NAME + '" not found.' });
    const lastCol = sheet.getLastColumn();
    if (lastCol < 1) return json_({ ok: false, error: 'The target tab has no header row.' });
    const headers = sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(h => String(h).trim());
    const norm = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const col = {};
    headers.forEach((h, i) => { col[norm(h)] = i; });
    const getCol = aliases => {
      for (const alias of aliases) if (Object.prototype.hasOwnProperty.call(col, norm(alias))) return col[norm(alias)];
      return -1;
    };
    const outletCol = getCol(['Outlet Name', 'Outlet', 'Restaurant Name']);
    if (outletCol < 0) return json_({ ok: false, error: 'Could not find an Outlet Name header in row 1.' });

    const storeIdCol = getCol(['Store ID', 'TMBill Store ID']);
    const emailCol = getCol(['Email', 'E-mail']);
    const contactCol = getCol(['Contact', 'Mobile', 'Phone']);
    const eventId = String(body.event_id || body.store_id || (body.outlet_name + '|' + body.email)).trim().toLowerCase();
    // Idempotency: if Store ID column exists, match it; otherwise match outlet + contact/email.
    const lastRow = sheet.getLastRow();
    if (lastRow >= 2) {
      const data = sheet.getRange(2, 1, lastRow - 1, lastCol).getDisplayValues();
      for (let r = 0; r < data.length; r++) {
        const existingOutlet = String(data[r][outletCol] || '').trim().toLowerCase();
        const existingStoreId = storeIdCol >= 0 ? String(data[r][storeIdCol] || '').trim() : '';
        const existingEmail = emailCol >= 0 ? String(data[r][emailCol] || '').trim().toLowerCase() : '';
        const existingContact = contactCol >= 0 ? String(data[r][contactCol] || '').replace(/\D/g, '') : '';
        if ((body.store_id && existingStoreId && existingStoreId === String(body.store_id)) ||
            (existingOutlet && existingOutlet === String(body.outlet_name).trim().toLowerCase() &&
             ((body.email && existingEmail === String(body.email).trim().toLowerCase()) ||
              (body.contact && existingContact === String(body.contact).replace(/\D/g, '')) ||
              (!body.email && !body.contact)))) {
          return json_({ ok: true, duplicate: true, row: r + 2, message: 'Matching client already exists; no duplicate row added.' });
        }
      }
    }

    const row = new Array(lastCol).fill('');
    const put = (aliases, value) => { const i = getCol(aliases); if (i >= 0 && value !== undefined && value !== null) row[i] = value; };
    put(['SR No', 'SR No.', 'Serial No', 'S No'], nextSerial_(sheet, getCol(['SR No', 'SR No.', 'Serial No', 'S No'])));
    put(['Outlet Name', 'Outlet', 'Restaurant Name'], body.outlet_name);
    put(['Tax Configuration', 'Tax Config', 'GST Configuration'], body.tax_configuration || '');
    put(['Email', 'E-mail'], body.email || '');
    put(['Contact', 'Mobile', 'Phone'], body.contact || '');
    put(['Package', 'Plan'], body.package || '');
    put(['Username', 'User Name', 'Login Username'], body.username || '');
    put(['Password', 'Login Password'], body.password || '');
    put(['Billing Status', 'Onboarding Status', 'Status'], body.billing_status || 'Onboarding complete');
    put(['Store ID', 'TMBill Store ID'], body.store_id || '');
    put(['Onboarding Completed At', 'Completed At', 'Timestamp'], body.completed_at || new Date().toISOString());
    sheet.appendRow(row);
    return json_({ ok: true, row: sheet.getLastRow(), message: 'Client added to INDIA Client.' });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}

function nextSerial_(sheet, srIndex) {
  if (srIndex < 0) return '';
  const last = sheet.getLastRow();
  if (last < 2) return 1;
  const vals = sheet.getRange(2, srIndex + 1, last - 1, 1).getValues().flat();
  let max = 0;
  vals.forEach(v => { const n = Number(v); if (Number.isFinite(n) && n > max) max = n; });
  return max + 1;
}

function constantTimeEquals_(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Anonymous lessons from the extension -> your PRIVATE GitHub repo (token stays here, never in the extension).
 * Script Properties: LEARN_KEY (required), GITHUB_TOKEN + GITHUB_REPO (e.g. saheel-word/tmbill-learning).
 * If GitHub is not set, lessons are appended to a "Learning" tab in the spreadsheet instead. */
function handleLearning_(body, props) {
  const key = props.getProperty('LEARN_KEY') || '';
  if (!key || !body._learnKey || !constantTimeEquals_(String(body._learnKey), key)) return json_({ ok: false, error: 'Unauthorized.' });
  const raw = JSON.stringify(body.payload || {});
  if (raw.length > 40000) return json_({ ok: false, error: 'Payload too large.' });
  const p = body.payload || {};
  const clean = { schema: 1, version: String(p.version || '').slice(0, 20), device: String(body.device || p.device || '').slice(0, 12), sentAt: new Date().toISOString(),
    corrections: Array.isArray(p.corrections) ? p.corrections.slice(0, 200) : [], errors: Array.isArray(p.errors) ? p.errors.slice(0, 60) : [], runSteps: Array.isArray(p.runSteps) ? p.runSteps.slice(0, 60) : [] };
  const token = props.getProperty('GITHUB_TOKEN'), repo = props.getProperty('GITHUB_REPO');
  if (token && repo) {
    const month = clean.sentAt.slice(0, 7);
    const path = 'learning/' + month + '/' + (clean.device || 'dev') + '-' + clean.sentAt.replace(/[:.]/g, '-') + '.json';
    const res = UrlFetchApp.fetch('https://api.github.com/repos/' + repo + '/contents/' + path, {
      method: 'put', contentType: 'application/json', muteHttpExceptions: true,
      headers: { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json' },
      payload: JSON.stringify({ message: 'learning ' + clean.version, content: Utilities.base64Encode(JSON.stringify(clean, null, 2), Utilities.Charset.UTF_8) })
    });
    const code = res.getResponseCode();
    if (code >= 200 && code < 300) return json_({ ok: true });
    return json_({ ok: false, error: 'GitHub ' + code });
  }
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sh = ss.getSheetByName('Learning') || ss.insertSheet('Learning');
  if (sh.getLastRow() === 0) sh.appendRow(['sentAt', 'version', 'device', 'json']);
  sh.appendRow([clean.sentAt, clean.version, clean.device, JSON.stringify(clean)]);
  return json_({ ok: true });
}
