// One-time developer setup (see SETUP_Learning_AutoShare.txt). Filled once; every colleague's extension
// then shares anonymous lessons automatically - nobody has to configure anything.
// The key below can only append small anonymised JSON; it cannot read or change any client data.
window.TMBILL_LEARN = {
  endpoint: "https://script.google.com/macros/s/AKfycbyFmW9FVKoyG9oXuGiPpVbhP6ijHEVl_WIhFY4AMoXxRvxE_IDkrUR0X_tJJkgIWR_r/exec",
  key: "tmb-learn-Xk29fQ7pLm41ZaR8"
};
